import random, math, json
from PIL import Image

def grid(w,h): return [['.']*w for _ in range(h)]
def put(g,x,y,c):
    if 0<=y<len(g) and 0<=x<len(g[0]): g[y][x]=c
def rows(g): return [''.join(r) for r in g]

# ---------- BOAT (top-down, bow to the right) 30x13 ----------
def boat():
    W,H=30,13
    g=grid(W,H)
    def half(x):
        if x<2: return 4
        if x<22: return 6
        t=(x-22)/7.0
        return max(0,int(round(6*math.sqrt(max(0,1-t*t)))))
    mask=[[False]*W for _ in range(H)]
    for x in range(W):
        hh=half(x)
        for y in range(H):
            if abs(y-6)<=hh and not (x>=29 and abs(y-6)>0): mask[y][x]=True
    def inside(x,y): return 0<=x<W and 0<=y<H and mask[y][x]
    for y in range(H):
        for x in range(W):
            if not mask[y][x]: continue
            edge=any(not inside(x+dx,y+dy) for dx,dy in((1,0),(-1,0),(0,1),(0,-1)))
            if edge: g[y][x]='o'
            else:
                # hull rim (2 px) vs deck
                near=any(not inside(x+dx,y+dy) or (inside(x+dx,y+dy) and any(not inside(x+dx+ex,y+dy+ey) for ex,ey in((1,0),(-1,0),(0,1),(0,-1)))) for dx,dy in((1,0),(-1,0),(0,1),(0,-1)))
                g[y][x]='H' if near else 'd'
    # planks
    for x in range(4,24,4):
        for y in range(H):
            if g[y][x]=='d': g[y][x]='p'
    # seats
    for sx in (8,16):
        for y in range(H):
            if g[y][sx] in 'dp' and g[y][sx+1] in 'dp': g[y][sx]='S'; g[y][sx+1]='S'
    # rope coil at stern + oar
    for (x,y) in ((4,5),(5,5),(4,7),(5,7),(5,6)): 
        if g[y][x] in 'dpS': g[y][x]='r'
    for x in range(11,20):
        if g[3][x] in 'dpS': g[3][x]='O'
    return rows(g)
BOAT_PAL={'o':'#3b2210','H':'#9a6430','d':'#e0b36e','p':'#c48f4e','S':'#8a5526','r':'#f1e6c8','O':'#6b4220'}

# ---------- FISH 11x6 (head to the right) ----------
FISH=[
"...oooo....",
".o.oBBBo...",
"ooooBBBBwo.",
"oooBBBBBBbo",
".o.oLLLo...",
"...oooo....",
]
# tidy: hand-made, mirror-safe
FISH=[
"....ooo....",
"oo.oBBBBo..",
"ooBBBBBwBo.",
"ooBBBBBBBoo",
"oo.oLLLLo..",
"....ooo....",
]
FISH_PALS={
 'orange':{'o':'#5a2208','B':'#ff8a2a','L':'#ffd49a','w':'#ffffff'},
 'silver':{'o':'#0c2c4a','B':'#9fc3e0','L':'#e8f4ff','w':'#ffffff'},
 'yellow':{'o':'#4a3a06','B':'#ffd23a','L':'#fff3b0','w':'#ffffff'},
}

# ---------- JELLYFISH 9x11, 2 frames ----------
def jelly(frame):
    g=grid(9,11)
    dome=[(2,0),(3,0),(4,0),(5,0),(6,0),
          (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),
          (0,2),(1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),
          (0,3),(1,3),(2,3),(3,3),(4,3),(5,3),(6,3),(7,3),(8,3),
          (1,4),(2,4),(3,4),(4,4),(5,4),(6,4),(7,4)]
    for x,y in dome: put(g,x,y,'J')
    for x in range(1,8): put(g,x,4,'K')
    for x,y in ((2,1),(3,1),(2,2)): put(g,x,y,'W')
    for x in (0,8): put(g,x,2,'o'); put(g,x,3,'o')
    # tentacles
    off=1 if frame else 0
    for i,x in enumerate((2,4,6)):
        for y in range(5,11):
            wob = ((y+i+off)//2)%2
            put(g,x+(1 if wob else 0)-0,y,'T' if y<9 else 't')
    return rows(g)
JELLY_PAL={'J':'#f3a6e8','K':'#c273d6','W':'#ffffff','o':'#7a3a96','T':'#e58bd9','t':'#f6c3ef'}

# ---------- TURTLE (top-down, head right) 15x13, 2 frames ----------
def turtle(frame):
    W,H=15,13
    g=grid(W,H)
    cx,cy=6.5,6.0
    def inshell(x,y): return ((x-cx)/5.2)**2+((y-cy)/5.2)**2<=1.0
    # flippers
    fl = [((10,1),(12,0)),((10,11),(12,12)),((2,1),(0,0)),((2,11),(0,12))]
    for (a,b) in fl:
        for t in range(0,6):
            x=int(round(a[0]+(b[0]-a[0])*t/5)); y=int(round(a[1]+(b[1]-a[1])*t/5))
            if frame: x+= (1 if a[0]>6 else -1)*0; y+= (-1 if a[1]<6 else 1)*(1 if t>2 else 0)
            put(g,x,y,'f'); put(g,x+1,y,'f')
    # head
    for x,y in ((11,5),(12,5),(13,5),(11,6),(12,6),(13,6),(14,6),(11,7),(12,7),(13,7)): put(g,x,y,'h')
    put(g,13,5,'w'); 
    # tail
    put(g,0,6,'f'); put(g,1,6,'f')
    for y in range(H):
        for x in range(W):
            if inshell(x,y): g[y][x]='s'
    for y in range(H):
        for x in range(W):
            if g[y][x]=='s':
                edge=not all(inshell(x+dx,y+dy) for dx,dy in((1,0),(-1,0),(0,1),(0,-1)))
                if edge: g[y][x]='O'
    # shell pattern
    for (x,y) in ((6,3),(5,4),(7,4),(6,5),(4,6),(8,6),(6,7),(5,8),(7,8),(6,9)):
        if g[y][x]=='s': g[y][x]='c'
    for (x,y) in ((4,3),(8,3)):
        if g[y][x]=='s': g[y][x]='l'
    # outline for flippers/head
    out=[row[:] for row in g]
    for y in range(H):
        for x in range(W):
            if g[y][x]=='.':
                if any(0<=x+dx<W and 0<=y+dy<H and g[y+dy][x+dx] in 'fhw' for dx,dy in((1,0),(-1,0),(0,1),(0,-1))):
                    out[y][x]='n'
    return rows(out)
TURTLE_PAL={'s':'#4fa86a','O':'#1d5a38','c':'#2f7d4c','l':'#7fd08e','f':'#6fbf7a','h':'#7fcf86','w':'#ffffff','n':'#17482d'}

# ---------- ROCKS ----------
def rock(w,h,seed,moss=False):
    rnd=random.Random(seed)
    g=grid(w,h)
    cx,cy=(w-1)/2,(h-1)/2
    ph=[rnd.random()*6.28 for _ in range(3)]
    def inside(x,y):
        a=math.atan2((y-cy)/(h/2),(x-cx)/(w/2))
        r=1.0+0.10*math.sin(3*a+ph[0])+0.06*math.sin(5*a+ph[1])
        return ((x-cx)/(w/2))**2+((y-cy)/(h/2))**2 <= r*r*0.96
    for y in range(h):
        for x in range(w):
            if inside(x,y): g[y][x]='m'
    for y in range(h):
        for x in range(w):
            if g[y][x]!='m': continue
            edge=any(not (0<=x+dx<w and 0<=y+dy<h and (g[y+dy][x+dx]!='.')) for dx,dy in((1,0),(-1,0),(0,1),(0,-1)))
            if edge: g[y][x]='o'
    for y in range(h):
        for x in range(w):
            if g[y][x]=='m':
                lit = (x-cx)/(w/2)*-0.7 + (y-cy)/(h/2)*-0.9
                if lit>0.45: g[y][x]='L'
                elif lit<-0.55: g[y][x]='D'
    # cracks
    for _ in range(2):
        x=rnd.randrange(2,w-3); y=rnd.randrange(2,h-3)
        for k in range(3):
            if g[y][x] in 'mLD': g[y][x]='D'
            x+=1; y+=rnd.choice((0,1))
            if not(0<=y<h and 0<=x<w): break
    if moss:
        for y in range(h):
            for x in range(w):
                if g[y][x] in 'mLD' and rnd.random()<0.30 and y<h*0.6: g[y][x]='G'
    return rows(g)
ROCK_PAL={'o':'#2b2e36','m':'#8d939e','L':'#b9bfc9','D':'#666c78','G':'#5fa04a'}

if __name__=='__main__':
    sheet={'boat':boat(),'fish':FISH,'jelly0':jelly(0),'jelly1':jelly(1),'turtle0':turtle(0),'turtle1':turtle(1),
           'rockA':rock(16,10,1),'rockB':rock(13,8,2),'rockC':rock(18,11,3,True),'rockD':rock(11,7,4)}
    json.dump(sheet,open('sheet.json','w'))
    def render(rs,pal):
        h=len(rs);w=len(rs[0]);im=Image.new('RGBA',(w,h),(0,0,0,0))
        for y,r in enumerate(rs):
            for x,ch in enumerate(r):
                if ch in pal:
                    c=pal[ch].lstrip('#');im.putpixel((x,y),(int(c[0:2],16),int(c[2:4],16),int(c[4:6],16),255))
        return im
    items=[('boat',BOAT_PAL),('fish',FISH_PALS['orange']),('fish',FISH_PALS['silver']),('fish',FISH_PALS['yellow']),
           ('jelly0',JELLY_PAL),('jelly1',JELLY_PAL),('turtle0',TURTLE_PAL),('turtle1',TURTLE_PAL),
           ('rockA',ROCK_PAL),('rockB',ROCK_PAL),('rockC',ROCK_PAL),('rockD',ROCK_PAL)]
    S=8
    sh=Image.new('RGBA',(560,230),(0,148,232,255))
    x=8;y=8;rowh=0
    for name,pal in items:
        im=render(sheet[name],pal).resize((len(sheet[name][0])*S,len(sheet[name])*S),Image.NEAREST)
        if x+im.width>550: x=8;y+=rowh+10;rowh=0
        sh.paste(im,(x,y),im);x+=im.width+12;rowh=max(rowh,im.height)
    sh.save('sheet.png')
    for k,v in sheet.items(): print(k,len(v[0]),'x',len(v))
