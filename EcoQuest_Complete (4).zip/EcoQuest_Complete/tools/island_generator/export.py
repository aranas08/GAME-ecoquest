import base64, struct, os, json
from PIL import Image
from core import *
import islands

PROJ = PROJECT
UIDS = {0: 'uid://bf365r80gpkxs', 1: 'uid://bmc48l8lxre8f', 2: 'uid://bp0ten37du2ku', 3: 'uid://b6bgt0e87d274',
        4: 'uid://bss4kkaw2art6', 5: 'uid://dblxin8bgcui6', 6: 'uid://lrkyna854pjr', 7: 'uid://bc43q8cob10kg'}
IDS = {0: '1_path', 1: '2_grass', 2: '3_watermid', 3: '4_water', 4: '5_beach', 5: '6_cliff', 6: '7_farm', 7: '8_pathmid'}

WATER_BLUE = {(0, 149, 233), (0, 109, 168)}
ROCK = {(109, 72, 59), (63, 40, 50), (156, 103, 84)}
BLOCK_COLORS = {2: WATER_BLUE, 3: WATER_BLUE | ROCK, 4: {(0, 149, 233)}, 5: ROCK}

# tiles defined per source (atlas coords)
def tiles_of(src):
    if src in (0, 3, 5):
        return [(x, y) for y in range(3) for x in range(3)] + [(0, 3), (1, 3), (0, 4), (1, 4), (0, 5), (1, 5), (2, 5)]
    if src == 4:
        return [(x, y) for y in range(3) for x in range(3)] + [(3, 0), (4, 0), (3, 1), (4, 1)]
    if src == 6:
        return [(x, y) for y in range(3) for x in range(3)]
    return [(0, 0)]

def hull(points):
    pts = sorted(set(points))
    if len(pts) <= 2:
        return pts
    def cross(o, a, b): return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])
    lo = []
    for p in pts:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0: lo.pop()
        lo.append(p)
    up = []
    for p in reversed(pts):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0: up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]

def area(poly):
    a = 0
    for i in range(len(poly)):
        x0, y0 = poly[i]; x1, y1 = poly[(i + 1) % len(poly)]
        a += x0 * y1 - x1 * y0
    return a / 2.0

def collision(src, ax, ay):
    """Convex polygon (tile-local, centred) covering the blocking pixels of a tile, or None."""
    if src == 2:
        return [(-8, -8), (8, -8), (8, 8), (-8, 8)]
    if src not in BLOCK_COLORS:
        return None
    im = atlas(src)
    pts = []
    for py in range(16):
        for px in range(16):
            r, g, b, a = im.getpixel((ax * 16 + px, ay * 16 + py))
            if a and (r, g, b) in BLOCK_COLORS[src]:
                for cx, cy in ((px, py), (px + 1, py), (px, py + 1), (px + 1, py + 1)):
                    pts.append((cx - 8, cy - 8))
    if not pts:
        return None
    h = hull(pts)
    if len(h) < 3:
        return None
    # match the winding of the original tileset (x-right, y-down: top-left -> top-right -> bottom-right)
    if area(h) < 0:
        h = h[::-1]
    return h

COLL = {}
for s in range(8):
    for (ax, ay) in tiles_of(s):
        COLL[(s, ax, ay)] = collision(s, ax, ay)

def tileset_tres():
    L = ['[gd_resource type="TileSet" format=3]', '']
    for s in range(8):
        L.append('[ext_resource type="Texture2D" uid="%s" path="res://assets/images/tileset/%s" id="%s"]' % (UIDS[s], FILES[s], IDS[s]))
    L.append('')
    for s in range(8):
        L.append('[sub_resource type="TileSetAtlasSource" id="atlas_%d"]' % s)
        L.append('texture = ExtResource("%s")' % IDS[s])
        for (ax, ay) in tiles_of(s):
            L.append('%d:%d/0 = 0' % (ax, ay))
            poly = COLL[(s, ax, ay)]
            if poly:
                L.append('%d:%d/0/physics_layer_0/polygon_0/points = PackedVector2Array(%s)' %
                         (ax, ay, ', '.join('%g, %g' % p for p in poly)))
        L.append('')
    L.append('[resource]')
    L.append('physics_layer_0/collision_layer = 1')
    for s in range(8):
        L.append('sources/%d = SubResource("atlas_%d")' % (s, s))
    return '\n'.join(L) + '\n'

def tile_data_b64(tiles):
    b = bytearray(b'\x00\x00')
    for (x, y) in sorted(tiles):
        s, ax, ay = tiles[(x, y)]
        b += struct.pack('<hhHHHH', x, y, s, ax, ay, 0)
    return base64.b64encode(bytes(b)).decode()

# --- gameplay checks (mirrors what base_level.gd does at runtime)
def cell_clear(tiles, x, y):
    t = tiles.get((x, y))
    return t is not None and COLL.get(t) is None

def cell_passable(tiles, x, y):
    t = tiles.get((x, y))
    if t is None: return False
    p = COLL.get(t)
    # only beach shoreline tiles (thin strip of sea in the tile) can be walked on while they have a collider
    return p is None or (t[0] == SRC['beach'] and area(p) < 0.55 * 256)

def reach(tiles, start):
    from collections import deque
    seen = {start}; q = deque([start])
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if n not in seen and 0 <= n[0] < W and 0 <= n[1] < H and cell_passable(tiles, *n):
                seen.add(n); q.append(n)
    return seen

META = [  # id, scene name
    ('beach', 'island_1_beach'), ('forest', 'island_2_forest'), ('river', 'island_3_river'),
    ('village', 'island_4_village'), ('mountain', 'island_5_mountain')]

def scene_text(tiles, start, maya, title):
    def pos(c): return '%g, %g' % ((c[0] + 0.5) * 64, (c[1] + 0.5) * 64)
    return f'''[gd_scene format=3]

[ext_resource type="TileSet" path="res://assets/tilesets/eco_tileset.tres" id="1_tileset"]

[node name="Island" type="Node2D"]

[node name="TileMapLayer" type="TileMapLayer" parent="."]
scale = Vector2(4, 4)
tile_map_data = PackedByteArray("{tile_data_b64(tiles)}")
tile_set = ExtResource("1_tileset")

[node name="PlayerStart" type="Marker2D" parent="."]
position = Vector2({pos(start)})

[node name="MayaSpot" type="Marker2D" parent="."]
position = Vector2({pos(maya)})
'''

if __name__ == '__main__':
    PREV = os.path.join(PROJ, 'island_previews'); os.makedirs(PREV, exist_ok=True)
    os.makedirs(PROJ + '/assets/tilesets', exist_ok=True)
    os.makedirs(PROJ + '/Scenes/levels/islands', exist_ok=True)
    open(PROJ + '/assets/tilesets/eco_tileset.tres', 'w').write(tileset_tres())
    builders = dict(islands.ALL)
    sheets = []
    report = {}
    for iid, name in META:
        d = builders[iid]()
        assert not d['errors'], (iid, d['errors'])
        tiles = build_tiles(d['grid'], d['deco'], d['seed'])
        st, my = d['start'], d['maya']
        assert cell_clear(tiles, *st), (iid, 'start not clear', tiles[st])
        assert cell_clear(tiles, *my), (iid, 'maya not clear', tiles[my])
        r = reach(tiles, st)
        assert my in r, (iid, 'maya unreachable')
        spawn = [c for c in r if cell_clear(tiles, *c)]
        allclear = [(x, y) for y in range(H) for x in range(W) if cell_clear(tiles, x, y)]
        report[iid] = dict(reachable_clear=len(spawn), clear_total=len(allclear))
        open(PROJ + '/Scenes/levels/islands/%s.tscn' % name, 'w').write(scene_text(tiles, st, my, iid))
        render(tiles, os.path.join(PREV, 'island_%s.png' % iid), 2,
               marks=[('P', st, (255, 255, 255, 255)), ('M', my, (255, 0, 255, 255))])
        render(tiles, os.path.join(PREV, 'spawn_check_%s.png' % iid), 2, spawn=spawn,
               marks=[('P', st, (255, 255, 255, 255)), ('M', my, (255, 0, 255, 255))])
    print(json.dumps(report, indent=1))
