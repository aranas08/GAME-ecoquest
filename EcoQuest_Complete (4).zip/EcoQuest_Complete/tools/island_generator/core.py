"""Core helpers: grid painting, autotile picking, validation/repair, preview rendering."""
import math, os, random
from PIL import Image, ImageDraw

W, H = 36, 26          # playable area in cells (matches Camera2D limits 2304x1664 at 64px/cell)
HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.abspath(os.path.join(HERE, '..', '..'))
UP = os.path.join(PROJECT, 'assets', 'images', 'tileset') + os.sep   # tile sheets live in the project

# tile source ids (0-3 kept identical to the original base_level.tscn tileset)
SRC = {'path': 0, 'grass': 1, 'water_mid': 2, 'water': 3, 'beach': 4, 'cliff': 5, 'farm': 6, 'path_mid': 7}
FILES = {0: 'Path_Tile.png', 1: 'Grass_Middle.png', 2: 'Water_Middle.png', 3: 'Water_Tile.png',
         4: 'Beach_Tile.png', 5: 'Cliff_Tile.png', 6: 'FarmLand_Tile.png', 7: 'Path_Middle.png'}

DIRS = {'N': (0, -1), 'E': (1, 0), 'S': (0, 1), 'W': (-1, 0),
        'NE': (1, -1), 'SE': (1, 1), 'SW': (-1, 1), 'NW': (-1, -1)}

INNER_STD = {'SE': (0, 3), 'SW': (1, 3), 'NE': (0, 4), 'NW': (1, 4)}
INNER_BEACH = {'SE': (3, 0), 'SW': (4, 0), 'NE': (3, 1), 'NW': (4, 1)}

# ------------------------------------------------------------------ grid
def new_grid(fill='w'):
    return [[fill] * W for _ in range(H)]

def get(g, x, y):
    if 0 <= x < W and 0 <= y < H:
        return g[y][x]
    return 'w'   # outside the playable area is open sea

def put(g, x, y, c):
    if 0 <= x < W and 0 <= y < H:
        g[y][x] = c

def blob(cx, cy, rx, ry, n=2.4, wobble=0.10, seed=1):
    """Irregular superellipse; returns set of (x,y) cells."""
    rnd = random.Random(seed)
    ph = [rnd.uniform(0, 6.283) for _ in range(4)]
    amps = [wobble * 0.6, wobble * 0.5, wobble * 0.35, wobble * 0.25]
    fr = [2, 3, 5, 7]
    cells = set()
    for y in range(H):
        for x in range(W):
            dx = (x + 0.5 - cx) / rx
            dy = (y + 0.5 - cy) / ry
            ang = math.atan2(dy, dx)
            k = 1 + sum(a * math.sin(f * ang + p) for a, f, p in zip(amps, fr, ph))
            d = (abs(dx) ** n + abs(dy) ** n) ** (1.0 / n)
            if d <= k:
                cells.add((x, y))
    return cells

def rect(x0, y0, x1, y1):
    return {(x, y) for x in range(x0, x1 + 1) for y in range(y0, y1 + 1)}

def route(points, width):
    """Thick rectilinear polyline; points are (x,y) cell coords, width in cells."""
    cells = set()
    for (ax, ay), (bx, by) in zip(points, points[1:]):
        x0, x1 = sorted((ax, bx)); y0, y1 = sorted((ay, by))
        cells |= rect(x0, y0, x1 + width - 1, y1 + width - 1)
    return cells

def water_dist(g):
    """Chebyshev distance (in cells) from every cell to the nearest water cell / map edge."""
    from collections import deque
    INF = 999
    d = [[INF] * W for _ in range(H)]
    q = deque()
    for y in range(H):
        for x in range(W):
            if g[y][x] == 'w' or x == 0 or y == 0 or x == W - 1 or y == H - 1:
                d[y][x] = 0; q.append((x, y))
    while q:
        x, y = q.popleft()
        for dx, dy in DIRS.values():
            nx, ny = x + dx, y + dy
            if 0 <= nx < W and 0 <= ny < H and d[ny][nx] > d[y][x] + 1:
                d[ny][nx] = d[y][x] + 1; q.append((nx, ny))
    return d

def paint(g, cells, cls, only=None, keep=0):
    """Paint cells with cls. only= restrict to cells currently of those classes.
    keep= don't paint cells closer than `keep` cells to the water (keeps a strip of grass on the coast)."""
    wd = water_dist(g) if keep else None
    for (x, y) in cells:
        if 0 <= x < W and 0 <= y < H and (only is None or g[y][x] in only):
            if wd is not None and wd[y][x] < keep:
                continue
            g[y][x] = cls

# ------------------------------------------------------------------ autotile
def pick(out, inner_map):
    """out = set of direction names that are 'outside'. Returns atlas coords or None if not representable
    with the 3x3 + 4 inner-corner layout."""
    orth = sorted(d for d in out if len(d) == 1)
    diag = sorted(d for d in out if len(d) == 2)
    k = len(orth)
    if k == 0:
        if not diag:
            return (1, 1)
        if len(diag) == 1:
            return inner_map.get(diag[0])
        return None
    if k == 1:
        d = orth[0]
        opp = {'N': ('SE', 'SW'), 'S': ('NE', 'NW'), 'W': ('NE', 'SE'), 'E': ('NW', 'SW')}[d]
        if any(x in diag for x in opp):
            return None
        return {'N': (1, 0), 'S': (1, 2), 'W': (0, 1), 'E': (2, 1)}[d]
    if k == 2:
        s = set(orth)
        table = {frozenset('NW'): ('SE', (0, 0)), frozenset('NE'): ('SW', (2, 0)),
                 frozenset('SW'): ('NE', (0, 2)), frozenset('SE'): ('NW', (2, 2))}
        if frozenset(s) not in table:
            return None            # opposite sides = 1-wide strip
        far, tile = table[frozenset(s)]
        if far in diag:
            return None
        return tile
    return None

def pick_safe(out, inner_map):
    """Like pick() but always returns a tile (drops the awkward flags) - used for the last few cells the
    repair pass cannot fix. Visually a tiny nick at worst."""
    t = pick(out, inner_map)
    if t:
        return t
    orth = sorted(d for d in out if len(d) == 1)
    t = pick(set(orth), inner_map)
    if t:
        return t
    if orth:
        return pick({orth[0]}, inner_map) or (1, 1)
    return (1, 1)

def nbrs(g, x, y):
    return {d: get(g, x + dx, y + dy) for d, (dx, dy) in DIRS.items()}

def sand_mode(g, x, y):
    """How a sand cell is drawn: 'beach' (only sea around it), 'path' (grass/pit around it, or grass AND sea),
    or 'mid' (fully surrounded by sand)."""
    wat = gra = False
    for dx, dy in DIRS.values():
        k = get(g, x + dx, y + dy)
        if k == 'w':
            wat = True
        elif k in ('g', 'c'):
            gra = True
    if gra:
        return 'path'
    return 'beach' if wat else 'mid'

def analyse(g, x, y):
    """Return dict(kind, tile, out, problem, fix)"""
    c = g[y][x]
    nb = nbrs(g, x, y)
    if c == 'g':
        return {'kind': 'grass'}
    if c == 'w':
        out = set()
        for d, k in nb.items():
            dx, dy = DIRS[d]
            if k in ('g', 'c', 'f') or (k == 's' and sand_mode(g, x + dx, y + dy) == 'path'):
                out.add(d)
        if not out:
            return {'kind': 'water_mid'}
        inner = INNER_STD
        src = 'water'
    elif c == 's':
        wat = {d for d, k in nb.items() if k == 'w'}
        gra = {d for d, k in nb.items() if k in ('g', 'c')}
        if gra:
            out, inner, src = wat | gra, INNER_STD, 'path'
        elif wat:
            out, inner, src = wat, INNER_BEACH, 'beach'
        else:
            return {'kind': 'path_mid'}
    elif c == 'f':
        out = {d for d, k in nb.items() if k != 'f'}
        if not out:
            return {'kind': 'farm', 'tile': (1, 1), 'out': out}
        inner, src = {}, 'farm'
        bad = [d for d, k in nb.items() if k not in ('f', 's')]
        if bad:
            return {'kind': 'farm', 'tile': pick_safe(out, inner), 'out': out, 'problem': 'farm_edge', 'bad': bad}
    elif c == 'c':
        out = {d for d, k in nb.items() if k != 'c'}
        if not out:
            return {'kind': 'cliff', 'tile': (1, 1), 'out': out}
        inner, src = INNER_STD, 'cliff'
    else:
        raise ValueError(c)
    tile = pick(out, inner)
    if tile is None:
        return {'kind': src, 'problem': 'shape', 'out': out, 'tile': pick_safe(out, inner)}
    return {'kind': src, 'tile': tile, 'out': out}

def validate(g):
    errs = []
    for y in range(H):
        for x in range(W):
            a = analyse(g, x, y)
            if 'problem' in a:
                errs.append((x, y, a))
    return errs

def repair(g, max_iter=40, verbose=False):
    log = []
    for it in range(max_iter):
        errs = validate(g)
        if verbose:
            print('repair pass', it, 'errors', len(errs))
        if not errs:
            return log
        touched = set()
        for (x, y, a) in errs:
            if (x, y) in touched:
                continue
            c = g[y][x]
            nb = nbrs(g, x, y)
            changed = []
            if a['problem'] == 'conflict':
                for d in a['gra']:
                    dx, dy = DIRS[d]
                    if get(g, x + dx, y + dy) in ('g', 'c'):
                        put(g, x + dx, y + dy, 's'); changed.append((x + dx, y + dy))
            elif a['problem'] == 'farm_edge':
                for d in sorted(a['bad']):
                    dx, dy = DIRS[d]
                    put(g, x + dx, y + dy, 's'); changed.append((x + dx, y + dy))
            else:
                out = a['out']
                orth = sorted(d for d in out if len(d) == 1)
                diag = sorted(d for d in out if len(d) == 2)
                k = len(orth)
                thin = k >= 3 or (k == 2 and frozenset(orth) not in
                                  (frozenset('NW'), frozenset('NE'), frozenset('SW'), frozenset('SE')))
                if a['kind'] == 'farm' or c == 'f':
                    # farms must be plain rectangles
                    put(g, x, y, 's'); changed.append((x, y))
                elif thin:
                    # erode: become whatever most of the outside neighbours are
                    cnt = {}
                    for d in orth:
                        cnt[nb[d]] = cnt.get(nb[d], 0) + 1
                    rep = max(cnt, key=cnt.get)
                    if c == 's' and rep in ('g', 'c') and any(v == 'w' for v in nb.values()):
                        rep = 'w'
                    put(g, x, y, rep); changed.append((x, y))
                else:
                    # pinch: fill the offending diagonal notch(es) with this cell's class
                    if k == 0:
                        targets = diag[:1]
                    elif k == 1:
                        opp = {'N': ('SE', 'SW'), 'S': ('NE', 'NW'), 'W': ('NE', 'SE'), 'E': ('NW', 'SW')}[orth[0]]
                        targets = [d for d in opp if d in diag][:1]
                    else:
                        far = {frozenset('NW'): 'SE', frozenset('NE'): 'SW', frozenset('SW'): 'NE', frozenset('SE'): 'NW'}[frozenset(orth)]
                        targets = [far]
                    for d in targets:
                        dx, dy = DIRS[d]
                        put(g, x + dx, y + dy, c); changed.append((x + dx, y + dy))
            for (cx, cy) in changed:
                log.append((cx, cy))
                for dx in (-2, -1, 0, 1, 2):
                    for dy in (-2, -1, 0, 1, 2):
                        touched.add((cx + dx, cy + dy))
    return log

# ------------------------------------------------------------------ tile grid
def hash01(x, y, salt=0):
    v = (x * 73856093) ^ (y * 19349663) ^ (salt * 83492791)
    v = (v ^ (v >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((v ^ (v >> 16)) & 0xFFFF) / 65535.0

def build_tiles(g, deco=None, seed=0):
    """deco = dict(grass=p, sand=p, water=p). Returns dict[(x,y)] -> (source_id, ax, ay)."""
    deco = deco or {}
    tiles = {}
    for y in range(-1, H + 1):
        for x in range(-1, W + 1):
            if not (0 <= x < W and 0 <= y < H):
                tiles[(x, y)] = (SRC['water_mid'], 0, 0)     # sea ring around the playable area
                continue
            a = analyse(g, x, y)
            k = a['kind']
            if k == 'grass':
                tiles[(x, y)] = (SRC['grass'], 0, 0)
            elif k == 'water_mid':
                tiles[(x, y)] = (SRC['water_mid'], 0, 0)
            elif k == 'path_mid':
                tiles[(x, y)] = (SRC['path_mid'], 0, 0)
            elif k in ('path', 'water', 'beach', 'cliff', 'farm'):
                ax, ay = a['tile']
                tiles[(x, y)] = (SRC[k], ax, ay)
            else:
                raise RuntimeError('unresolved %s at %s' % (k, (x, y)))
    # sprinkle decoration tiles (row 5 of the sheets) on plain interior cells
    def all8(cl, x, y):
        return all(get(g, x + dx, y + dy) in cl for dx, dy in DIRS.values())
    placed = set()
    for y in range(H):
        for x in range(W):
            kind = tiles[(x, y)][0]
            r = hash01(x, y, seed + 7)
            var = int(hash01(x, y, seed + 13) * 3) % 3
            if (x - 1, y) in placed or (x, y - 1) in placed:
                continue
            if kind == SRC['grass'] and r < deco.get('grass', 0) and all8('g', x, y):
                tiles[(x, y)] = (SRC['cliff'], var, 5); placed.add((x, y))
            elif kind == SRC['path_mid'] and r < deco.get('sand', 0) and all8('sf', x, y) and g[y][x] == 's':
                tiles[(x, y)] = (SRC['path'], var, 5); placed.add((x, y))
            elif kind == SRC['water_mid'] and r < deco.get('water', 0) and all8('w', x, y):
                tiles[(x, y)] = (SRC['water'], var, 5); placed.add((x, y))
    return tiles

# ------------------------------------------------------------------ preview
_atlas = {}
def atlas(src):
    if src not in _atlas:
        _atlas[src] = Image.open(UP + FILES[src]).convert('RGBA')
    return _atlas[src]

def render(tiles, path, scale=2, marks=None, spawn=None):
    im = Image.new('RGBA', ((W + 2) * 16, (H + 2) * 16), (0, 0, 0, 255))
    for (x, y), (s, ax, ay) in tiles.items():
        t = atlas(s).crop((ax * 16, ay * 16, ax * 16 + 16, ay * 16 + 16))
        im.alpha_composite(t, ((x + 1) * 16, (y + 1) * 16))
    # crop to the playable area (what the camera shows)
    im = im.crop((16, 16, 16 + W * 16, 16 + H * 16))
    im = im.resize((W * 16 * scale, H * 16 * scale), Image.NEAREST)
    d = ImageDraw.Draw(im, 'RGBA')
    cs = 16 * scale
    if spawn:
        for (x, y) in spawn:
            d.rectangle([x * cs + cs // 2 - 2, y * cs + cs // 2 - 2, x * cs + cs // 2 + 2, y * cs + cs // 2 + 2], fill=(255, 255, 0, 200))
    for label, (x, y), col in (marks or []):
        d.ellipse([x * cs + 4, y * cs + 4, x * cs + cs - 4, y * cs + cs - 4], outline=col, width=3)
        d.text((x * cs + cs + 2, y * cs), label, fill=col)
    im.save(path)
    return im

def ascii_grid(g):
    return '\n'.join(''.join(row) for row in g)

def touch_report(g):
    """Sand cells that touch the sea (fine for beaches/piers, worth a look elsewhere)."""
    out = []
    for y in range(H):
        for x in range(W):
            if g[y][x] in 'sf' and any(get(g, x + dx, y + dy) == 'w' for dx, dy in DIRS.values()):
                out.append((x, y))
    return out
