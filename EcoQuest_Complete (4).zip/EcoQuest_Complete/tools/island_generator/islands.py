import os
from core import *

def finish(g, start, maya, deco, seed):
    log = repair(g)
    # last resort for any stubborn cell: adopt the most common neighbouring class, then re-run the repair
    for _ in range(6):
        errs = validate(g)
        if not errs:
            break
        for (x, y, a) in errs:
            cnt = {}
            for k in nbrs(g, x, y).values():
                if k != g[y][x]:
                    cnt[k] = cnt.get(k, 0) + 1
            if cnt:
                g[y][x] = max(cnt, key=cnt.get)
        log += repair(g)
    errs = validate(g)
    return dict(grid=g, start=start, maya=maya, deco=deco, seed=seed, fixes=len(log), errors=errs)

# ---------------------------------------------------------------- 1. Plastic Beach
def beach():
    g = new_grid('w')
    land = blob(17, 12.6, 14.8, 9.8, n=2.7, wobble=0.09, seed=11) | blob(28.5, 19.2, 5.0, 3.2, n=2.4, wobble=0.10, seed=12)
    paint(g, land, 's')
    paint(g, blob(10.5, 10.0, 4.6, 3.3, n=2.4, wobble=0.12, seed=3), 'g', only='s', keep=3)     # dune-grass meadow
    paint(g, blob(15.0, 18.8, 3.0, 2.1, n=2.4, wobble=0.10, seed=4), 'g', only='s', keep=3)
    paint(g, blob(25.0, 12.8, 4.8, 3.2, n=2.3, wobble=0.10, seed=5), 'w', only='s')     # sheltered lagoon
    paint(g, blob(5.6, 18.6, 2.3, 1.8, n=2.3, wobble=0.10, seed=6), 'w', only='s')      # tide pool
    return finish(g, (6, 13), (8, 16), dict(grass=0.10, sand=0.10, water=0.05), 1)

# ---------------------------------------------------------------- 2. Deforested Woods
def forest():
    g = new_grid('w')
    paint(g, blob(18.5, 12.6, 14.2, 10.0, n=2.5, wobble=0.10, seed=21), 'g')
    # a sheltered bay cut into the southern coast
    paint(g, blob(24.5, 25.0, 5.6, 4.6, n=2.2, wobble=0.06, seed=30), 'w')
    # a fjord-like inlet from the north coast ending in an inland pond
    paint(g, rect(22, 0, 24, 6), 'w')
    paint(g, blob(23, 8.6, 4.4, 2.8, n=2.2, wobble=0.10, seed=22), 'w')
    # cleared (logged) ground and the tracks the loggers used
    paint(g, blob(8.5, 15.2, 5.0, 3.5, n=2.4, wobble=0.12, seed=23), 's', only='g', keep=2)
    paint(g, blob(27.5, 16.8, 4.4, 3.0, n=2.4, wobble=0.12, seed=24), 's', only='g', keep=2)
    paint(g, blob(13.5, 6.6, 3.6, 2.6, n=2.4, wobble=0.12, seed=25), 's', only='g', keep=2)
    paint(g, route([(13, 7), (13, 15), (9, 15)], 2), 's', only='g', keep=2)
    paint(g, route([(9, 18), (27, 18)], 2), 's', only='g', keep=2)
    paint(g, route([(17, 18), (17, 12), (21, 12)], 2), 's', only='g', keep=2)
    # ravines / gullies left behind by erosion
    paint(g, blob(6.3, 7.4, 2.9, 2.4, n=2.3, wobble=0.06, seed=26), 'c', only='g', keep=2)
    paint(g, blob(30.6, 10.6, 2.7, 2.4, n=2.3, wobble=0.06, seed=27), 'c', only='g', keep=2)
    paint(g, blob(17.5, 21.0, 3.0, 1.9, n=2.3, wobble=0.05, seed=28), 'c', only='g', keep=2)
    paint(g, blob(17.0, 4.8, 2.6, 1.9, n=2.3, wobble=0.05, seed=29), 'c', only='g', keep=2)
    return finish(g, (8, 15), (11, 16), dict(grass=0.20, sand=0.13, water=0.05), 2)

# ---------------------------------------------------------------- 3. Polluted River Delta
def rows(g, spans, cls):
    for y, (x0, x1) in spans.items():
        for x in range(x0, x1 + 1):
            put(g, x, y, cls)

def river():
    g = new_grid('w')
    # mainland, drawn row by row (x_left, x_right)
    rows(g, {2: (9, 26), 3: (6, 29), 4: (4, 31), 5: (3, 32), 6: (3, 32), 7: (2, 33), 8: (2, 33), 9: (2, 33),
             10: (2, 33), 11: (2, 33), 12: (2, 33), 13: (3, 33), 14: (3, 33), 15: (3, 32), 16: (3, 32),
             17: (3, 31), 18: (4, 31), 19: (4, 30), 20: (5, 29), 21: (6, 28), 22: (8, 26)}, 'g')
    # the lake, the trunk and the widening mouth (water)
    rows(g, {5: (14, 21), 6: (12, 23), 7: (11, 24), 8: (12, 23), 9: (14, 21),
             10: (16, 18), 11: (16, 18), 12: (16, 18), 13: (16, 18), 14: (16, 18),
             15: (15, 19), 16: (13, 21), 17: (12, 22), 18: (11, 23),
             19: (10, 24), 20: (10, 24), 21: (10, 24), 22: (10, 24), 23: (10, 24), 24: (10, 24), 25: (10, 24)}, 'w')
    # silty delta island in the mouth
    rows(g, {17: (15, 19), 18: (15, 19), 19: (15, 19), 20: (15, 19), 21: (15, 19), 22: (15, 19)}, 's')
    # crossings so the whole island can be walked
    rows(g, {18: (10, 14), 19: (10, 14)}, 's')                       # sandbar out to the delta island
    # polluted farm fields on both river banks
    paint(g, rect(4, 6, 9, 11), 's');    paint(g, rect(5, 7, 8, 10), 'f')
    paint(g, rect(26, 6, 31, 11), 's');  paint(g, rect(27, 7, 30, 10), 'f')
    # a collapsed bank and a stagnant pond on the far side of the river
    paint(g, blob(6.8, 16.4, 2.5, 1.9, n=2.3, wobble=0.05, seed=35), 'c', only='g', keep=2)
    paint(g, blob(27.6, 16.6, 3.0, 2.2, n=2.3, wobble=0.08, seed=36), 'w', only='g', keep=2)
    return finish(g, (12, 13), (10, 14), dict(grass=0.09, sand=0.09, water=0.05), 3)

# ---------------------------------------------------------------- 4. Abandoned Village
def village():
    g = new_grid('w')
    paint(g, blob(18, 12.8, 15.2, 10.2, n=2.6, wobble=0.09, seed=41), 'g')
    paint(g, blob(32.5, 13.0, 5.6, 3.7, n=2.2, wobble=0.06, seed=42), 'w')            # harbour bay
    paint(g, blob(8.6, 6.8, 2.9, 2.1, n=2.3, wobble=0.06, seed=43), 'w', only='g', keep=2)   # old reservoir
    # main street, market square and the pier
    paint(g, route([(5, 12), (30, 12)], 2), 's')
    paint(g, route([(17, 4), (17, 20)], 2), 's')
    paint(g, blob(17.5, 12.8, 4.6, 3.4, n=2.2, wobble=0.05, seed=44), 's')
    # abandoned farm plots (tilled soil inside a cleared yard)
    paint(g, rect(6, 15, 12, 19), 's');  paint(g, rect(7, 16, 11, 18), 'f')
    paint(g, rect(21, 5, 27, 9), 's');   paint(g, rect(22, 6, 26, 8), 'f')
    paint(g, rect(20, 15, 25, 19), 's'); paint(g, rect(21, 16, 24, 18), 'f')
    paint(g, route([(8, 14), (8, 14)], 2), 's')
    paint(g, route([(24, 10), (24, 10)], 2), 's')
    paint(g, route([(24, 14), (24, 14)], 2), 's')
    # foundations of collapsed houses
    paint(g, rect(12, 6, 15, 9), 's')
    paint(g, route([(13, 10), (13, 10)], 2), 's')
    # sinkholes
    paint(g, blob(14.2, 20.0, 2.4, 1.8, n=2.3, wobble=0.05, seed=45), 'c', only='g', keep=2)
    paint(g, blob(31.0, 6.4, 2.6, 2.0, n=2.3, wobble=0.05, seed=46), 'c', only='g', keep=2)
    paint(g, blob(6.5, 21.0, 2.0, 1.4, n=2.3, wobble=0.05, seed=47), 'c', only='g', keep=2)
    return finish(g, (6, 13), (9, 14), dict(grass=0.12, sand=0.10, water=0.05), 4)

# ---------------------------------------------------------------- 5. Barren Mountain
def mountain():
    g = new_grid('w')
    paint(g, blob(18, 13, 15.6, 10.8, n=2.8, wobble=0.10, seed=51), 'g')             # scrubby foothills
    paint(g, blob(18, 13, 14.6, 9.8, n=2.8, wobble=0.10, seed=52), 's', only='g', keep=2)    # bare rock and dirt
    # crater at the summit, ringed by a strip of scrub
    paint(g, blob(18, 11.4, 5.4, 3.9, n=2.2, wobble=0.05, seed=53), 'g', only='s')
    paint(g, blob(18, 11.4, 3.4, 2.2, n=2.2, wobble=0.04, seed=54), 'c')
    # oases: green pockets with a pond
    paint(g, blob(8.8, 9.4, 3.2, 2.7, n=2.3, wobble=0.06, seed=55), 'g', only='s')
    paint(g, blob(8.8, 9.4, 1.7, 1.5, n=2.2, wobble=0.03, seed=56), 'w', only='g')
    paint(g, blob(27.8, 17.4, 3.2, 2.7, n=2.3, wobble=0.06, seed=57), 'g', only='s')
    paint(g, blob(27.8, 17.4, 1.7, 1.5, n=2.2, wobble=0.03, seed=58), 'w', only='g')
    # broken ground: gullies on the slopes
    paint(g, blob(12.0, 18.4, 3.6, 2.3, n=2.3, wobble=0.06, seed=59), 'g', only='s')
    paint(g, blob(12.0, 18.4, 2.0, 1.2, n=2.2, wobble=0.03, seed=60), 'c', only='g')
    paint(g, blob(26.0, 7.6, 3.4, 2.2, n=2.3, wobble=0.06, seed=61), 'g', only='s')
    paint(g, blob(26.0, 7.6, 1.9, 1.1, n=2.2, wobble=0.03, seed=62), 'c', only='g')
    return finish(g, (6, 13), (9, 15), dict(grass=0.03, sand=0.18, water=0.05), 5)

ALL = [('beach', beach), ('forest', forest), ('river', river), ('village', village), ('mountain', mountain)]

if __name__ == '__main__':
    import sys
    which = sys.argv[1:] or [n for n, _ in ALL]
    for name, fn in ALL:
        if name not in which: continue
        d = fn()
        print(name, 'fixes', d['fixes'], 'errors', len(d['errors']))
        for e in d['errors'][:6]: print('   ', e[:2], e[2].get('problem'))
        t = build_tiles(d['grid'], d['deco'], d['seed'])
        render(t, os.path.join(HERE, 'prev_%s.png' % name), 2,
               marks=[('P', d['start'], (255, 255, 255, 255)), ('M', d['maya'], (255, 0, 255, 255))])
