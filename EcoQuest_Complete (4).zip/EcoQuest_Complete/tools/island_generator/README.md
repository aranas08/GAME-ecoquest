# Island generator

Python helpers that produced the five island maps (needs Pillow: `pip install pillow`).

- `core.py`    - grid painting, the autotile rules for the tile sheets, validation/repair, preview renderer
- `islands.py` - the five island designs (edit the shapes here). `python islands.py [name]` renders a quick preview PNG
- `export.py`  - writes `assets/tilesets/eco_tileset.tres`, `Scenes/levels/islands/*.tscn` and `island_previews/*.png`,
                 and checks that the player start and Maya are on walkable land

Run from this folder: `python export.py`. Re-run it after changing a design, then reopen the project in Godot.
Grid legend: w = water, g = grass, s = sand/path, f = farmland, c = cliff pit.
