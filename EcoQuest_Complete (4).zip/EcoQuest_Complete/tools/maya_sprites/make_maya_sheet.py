"""Generates assets/images/npc/Maya_Sheet.png (32x32 cells, 6 columns).

Rows (top to bottom):
  0 idle_down   1 idle_left   2 idle_right   3 idle_up
  4 walk_down   5 walk_left   6 walk_right   7 walk_up
  8 cook_up     9 talk_down  10 talk_left   11 talk_right
Same chibi proportions / outline style as Player.png so she fits the world.
Run:  python3 make_maya_sheet.py
"""
import math
from PIL import Image

OUT = (58, 42, 38, 255)
SKIN = (244, 200, 160, 255)
SKIN_S = (220, 160, 120, 255)
BLUSH = (238, 142, 130, 255)
HAIR = (240, 200, 96, 255)
HAIR_L = (253, 228, 142, 255)
HAIR_D = (200, 146, 58, 255)
VEST = (100, 72, 56, 255)
VEST_L = (128, 94, 70, 255)
DRESS = (234, 220, 186, 255)
DRESS_S = (200, 184, 148, 255)
BELT = (156, 100, 60, 255)
BOOT = (98, 72, 56, 255)
SOCK = (240, 230, 206, 255)
EYE = (46, 52, 96, 255)
MOUTH = (176, 82, 78, 255)
SHADOW = (60, 60, 70, 90)
WOOD = (150, 108, 70, 255)

CELL = 32
COLS = 6
ROWS = 12


class Cell:
    def __init__(self):
        self.p = {}

    def px(self, x, y, c):
        if 0 <= x < CELL and 0 <= y < CELL:
            self.p[(x, y)] = c

    def rect(self, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.px(x, y, c)

    def cut(self, pts):
        for p in pts:
            self.p.pop(p, None)

    def mirrored(self):
        m = Cell()
        for (x, y), c in self.p.items():
            m.p[(CELL - 1 - x, y)] = c
        return m

    def render(self):
        img = Image.new("RGBA", (CELL, CELL), (0, 0, 0, 0))
        body = set(self.p.keys())
        # outline pass
        for (x, y) in list(body):
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n = (x + dx, y + dy)
                if n not in body and 0 <= n[0] < CELL and 0 <= n[1] < CELL:
                    img.putpixel(n, OUT)
        # soft ground shadow (only on empty pixels)
        for y in range(26, 29):
            half = 8 if y == 27 else 6
            for x in range(16 - half, 16 + half):
                if img.getpixel((x, y))[3] == 0 and (x, y) not in body:
                    img.putpixel((x, y), SHADOW)
        for (x, y), c in self.p.items():
            img.putpixel((x, y), c)
        return img


def legs_front(c, ll, rl):
    # ll / rl: vertical lift (0 = on ground, 1 = raised by one pixel)
    for x0, lift in ((12, ll), (17, rl)):
        c.rect(x0, 24 - lift, x0 + 2, 24 - lift, SOCK)
        c.rect(x0, 25 - lift, x0 + 2, 25 - lift, BOOT)
        c.rect(x0, 26 - lift, x0 + 2, 26 - lift, BOOT)


def head_front(c, b, blink, mouth, tail):
    c.rect(10, 5 + b, 21, 8 + b, HAIR)
    c.rect(10, 9 + b, 11, 15 + b, HAIR)
    c.rect(20, 9 + b, 21, 15 + b, HAIR)
    c.rect(12, 9 + b, 19, 9 + b, HAIR)
    c.px(13, 9 + b, HAIR_D)
    c.px(17, 9 + b, HAIR_D)
    c.rect(12, 10 + b, 19, 14 + b, SKIN)
    c.px(12, 14 + b, SKIN_S)
    c.px(19, 14 + b, SKIN_S)
    c.px(12, 13 + b, BLUSH)
    c.px(19, 13 + b, BLUSH)
    c.rect(13, 5 + b, 15, 5 + b, HAIR_L)
    c.rect(12, 6 + b, 13, 6 + b, HAIR_L)
    if blink:
        c.px(13, 12 + b, EYE)
        c.px(14, 12 + b, EYE)
        c.px(17, 12 + b, EYE)
        c.px(18, 12 + b, EYE)
    else:
        c.rect(13, 11 + b, 13, 12 + b, EYE)
        c.rect(18, 11 + b, 18, 12 + b, EYE)
    if mouth:
        c.rect(15, 14 + b, 16, 14 + b, MOUTH)
    else:
        c.px(15, 14 + b, SKIN_S)
        c.px(16, 14 + b, SKIN_S)
    # round the head silhouette
    c.cut([(10, 5 + b), (21, 5 + b), (10, 6 + b), (21, 6 + b), (10, 15 + b), (21, 15 + b)])
    # side lock of hair that swings a little
    c.px(22 if tail else 21, 14 + b, HAIR_D)


def body_front(c, b, al, ar):
    # skirt + dress
    c.rect(10, 21 + b, 21, 22, DRESS) if b == 0 else c.rect(10, 22, 21, 22, DRESS)
    c.rect(10, 23, 21, 23, DRESS_S)
    # torso (dress) and vest
    c.rect(11, 15 + b, 20, 20 + b, DRESS)
    c.rect(11, 15 + b, 13, 20 + b, VEST)
    c.rect(18, 15 + b, 20, 20 + b, VEST)
    c.px(11, 15 + b, VEST_L)
    c.px(20, 15 + b, VEST_L)
    c.rect(11, 18 + b, 20, 18 + b, BELT)
    c.px(15, 18 + b, WOOD)
    c.px(16, 18 + b, WOOD)
    # arms: sleeves + hands (al/ar vertical offsets)
    for x0, off in ((9, al), (21, ar)):
        c.rect(x0, 16 + b + off, x0 + 1, 18 + b + off, DRESS)
        c.rect(x0, 19 + b + off, x0 + 1, 19 + b + off, SKIN)


def draw_down(b=0, ll=0, rl=0, al=0, ar=0, blink=False, mouth=False, tail=False):
    c = Cell()
    legs_front(c, ll, rl)
    body_front(c, b, al, ar)
    head_front(c, b, blink, mouth, tail)
    return c


def draw_up(b=0, ll=0, rl=0, al=0, ar=0, tail=False, spoon=None):
    c = Cell()
    legs_front(c, ll, rl)
    c.rect(10, 21 + b, 21, 22, DRESS) if b == 0 else c.rect(10, 22, 21, 22, DRESS)
    c.rect(10, 23, 21, 23, DRESS_S)
    c.rect(11, 15 + b, 20, 20 + b, VEST)
    c.rect(11, 15 + b, 20, 15 + b, VEST_L)
    c.rect(11, 18 + b, 20, 18 + b, BELT)
    c.rect(15, 18 + b, 16, 19 + b, VEST_L)
    for x0, off in ((9, al), (21, ar)):
        c.rect(x0, 16 + b + off, x0 + 1, 18 + b + off, DRESS)
        c.rect(x0, 19 + b + off, x0 + 1, 19 + b + off, SKIN)
    # head from behind: all hair
    c.rect(10, 5 + b, 21, 15 + b, HAIR)
    c.rect(12, 6 + b, 15, 6 + b, HAIR_L)
    c.rect(10, 12 + b, 21, 12 + b, HAIR)
    c.rect(11, 14 + b, 20, 15 + b, HAIR_D)
    c.rect(14, 8 + b, 17, 13 + b, HAIR)
    c.px(15, 9 + b, HAIR_L)
    c.cut([(10, 5 + b), (21, 5 + b), (10, 6 + b), (21, 6 + b), (10, 15 + b), (21, 15 + b)])
    # braid / side tail at the right (like Maya's artwork)
    c.rect(22, 13 + b, 23 if tail else 22, 17 + b, HAIR)
    c.px(22 if not tail else 23, 18 + b, HAIR_D)
    if spoon is not None:
        sx, sy = spoon
        c.px(sx, sy, WOOD)
        c.px(sx, sy - 1, WOOD)
        c.px(sx, sy - 2, HAIR_D)
    return c


def draw_right(b=0, st=0, al=0, blink=False, mouth=False, tail=False, gesture=0):
    """st: stride -1..1 (back leg / front leg split)."""
    c = Cell()
    # legs: two legs apart horizontally
    for x0, off in ((13, -st), (16, st)):
        x0 = x0 + off
        c.rect(x0, 24, x0 + 2, 24, SOCK)
        c.rect(x0, 25, x0 + 2, 26, BOOT)
    c.rect(11, 21 + b, 20, 22, DRESS) if b == 0 else c.rect(11, 22, 20, 22, DRESS)
    c.rect(11, 23, 20, 23, DRESS_S)
    # torso (side): vest over dress
    c.rect(12, 15 + b, 19, 20 + b, DRESS)
    c.rect(12, 15 + b, 19, 20 + b, VEST)
    c.rect(12, 15 + b, 19, 15 + b, VEST_L)
    c.rect(12, 18 + b, 19, 18 + b, BELT)
    # backpack-free; hair tail hangs behind
    c.rect(10, 14 + b, 11, 18 + b + (1 if tail else 0), HAIR)
    c.px(10, 19 + b, HAIR_D)
    # head
    c.rect(11, 5 + b, 20, 8 + b, HAIR)
    c.rect(11, 9 + b, 14, 15 + b, HAIR)
    c.rect(15, 9 + b, 19, 9 + b, HAIR)
    c.rect(15, 10 + b, 20, 14 + b, SKIN)
    c.px(21, 12 + b, SKIN)          # nose
    c.px(20, 14 + b, SKIN_S)
    c.px(16, 13 + b, BLUSH)
    c.px(14, 5 + b, HAIR_L)
    c.px(15, 5 + b, HAIR_L)
    c.px(13, 6 + b, HAIR_L)
    c.px(14, 11 + b, HAIR_D)
    if blink:
        c.px(18, 12 + b, EYE)
        c.px(19, 12 + b, EYE)
    else:
        c.rect(18, 11 + b, 18, 12 + b, EYE)
    if mouth:
        c.rect(19, 14 + b, 20, 14 + b, MOUTH)
    c.cut([(11, 5 + b), (20, 5 + b), (11, 6 + b), (20, 6 + b)])
    # near arm
    ay = 16 + b + al - gesture * 3
    c.rect(14, ay, 17, ay + 2, DRESS)
    c.rect(17, ay + 3 if not gesture else ay - 1, 18, ay + 3 if not gesture else ay, SKIN)
    return c


def sheet():
    img = Image.new("RGBA", (CELL * COLS, CELL * ROWS), (0, 0, 0, 0))

    def put(row, col, cell):
        img.paste(cell.render(), (col * CELL, row * CELL))

    bob = [0, 0, 1, 1, 0, 0]
    blink_f = 4
    tail = [0, 0, 1, 1, 1, 0]
    for i in range(COLS):
        # ---- idle ----
        put(0, i, draw_down(b=bob[i], blink=(i == blink_f), tail=bool(tail[i]),
                            al=(1 if bob[i] else 0), ar=(1 if bob[i] else 0)))
        r = draw_right(b=bob[i], blink=(i == blink_f), tail=bool(tail[i]))
        put(2, i, r)
        put(1, i, r.mirrored())
        put(3, i, draw_up(b=bob[i], tail=bool(tail[i]),
                          al=(1 if bob[i] else 0), ar=(1 if bob[i] else 0)))
        # ---- walk ----
        s = round(math.sin(2 * math.pi * i / COLS) * 1.0)
        c = math.cos(2 * math.pi * i / COLS)
        wb = 1 if abs(math.sin(2 * math.pi * i / COLS)) < 0.3 else 0
        ll = 1 if s > 0 else 0
        rl = 1 if s < 0 else 0
        put(4, i, draw_down(b=wb, ll=ll, rl=rl, al=-s, ar=s, tail=(i % 2 == 0)))
        wr = draw_right(b=wb, st=s * 2, al=-s, tail=(i % 2 == 0))
        put(6, i, wr)
        put(5, i, wr.mirrored())
        put(7, i, draw_up(b=wb, ll=ll, rl=rl, al=-s, ar=s, tail=(i % 2 == 0)))
        # ---- cook (back to camera, stirring a pot on the stove) ----
        sx = 18 + round(math.sin(2 * math.pi * i / COLS) * 2)
        sy = 12 + round(math.cos(2 * math.pi * i / COLS) * 1)
        cook = draw_up(b=(1 if i in (2, 3) else 0), tail=bool(tail[i]), al=0, ar=-3, spoon=(sx, sy))
        # raised stirring arm: hand follows the spoon
        cook.rect(sx - 1, sy + 1, sx, sy + 2, SKIN)
        put(8, i, cook)
        # ---- talk ----
        mouth = i in (1, 2, 4, 5)
        gest = 1 if i in (2, 3) else 0
        put(9, i, draw_down(b=bob[i], mouth=mouth, tail=bool(tail[i]), ar=(-2 if gest else 0)))
        tr = draw_right(b=bob[i], mouth=mouth, tail=bool(tail[i]), gesture=gest)
        put(11, i, tr)
        put(10, i, tr.mirrored())
    return img


if __name__ == "__main__":
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    out = os.path.join(here, "..", "..", "assets", "images", "npc", "Maya_Sheet.png")
    im = sheet()
    im.save(out)
    im.resize((im.width * 4, im.height * 4), Image.NEAREST).save("/home/claude/maya_sheet_x4.png")
    print("saved", out, im.size)
