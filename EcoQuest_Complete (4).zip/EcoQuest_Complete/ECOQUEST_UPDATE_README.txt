ECOQUEST UPDATE — ISLAND BOAT TRAVEL + LAND WILDLIFE

WHAT CHANGED
- Existing five-island progression remains in place. The next island unlocks after completing the island's required environmental challenges.
- Press N only after moving close to a shoreline boat. If you are too far away, the game explains that you must find the boat.
- Added land snakes and scorpions on open island cells. A yellow triangle with an exclamation mark identifies each harmful animal.
- Touching/stepping on a marked animal removes exactly 10 HP. Move away and re-enter to trigger another separate mistake.
- Existing water wildlife (fish, turtles, jellyfish), water hazards, collectible trash, quests, and save system are retained.

HOW TO OPEN
1. Extract this ZIP file to a normal folder.
2. Open Godot 4.x.
3. Click Import and choose the extracted eco-quest-build/project.godot file.
4. Open the project and press F6/F5 to test.
5. Finish the required challenges on an island, go to a boat at the shore, then press N.

IMPORTANT
- Make a backup before replacing your existing project.
- If a harmful animal appears too close to your starting position, or an island has no boat near accessible shore, report which island and what happened so the spawn positions can be adjusted.
- The project targets Godot 4.x; test it in the same Godot 4 version used by your original project.
