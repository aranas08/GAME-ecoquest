# EcoQuest — Godot Project Update

This build extends your original `eco-quest` project (your real tileset, player
spritesheet, and level layout are untouched/reused) into a much fuller slice of
the game design doc: HP, crafting, multiple hazards, a quest log, an NPC guide,
multi-island progression, a death state, and sound — on top of the original
Flood Warning Challenge (Storyboard Panels 1–10).

## Islands now have their own maps (Update 10)

Each of the 5 islands has its own tilemap built from your tileset - see
**Update 10** at the bottom of this file. (Earlier builds reused one map with a
colour tint, which is what this replaces.)

Sound effects are also **synthesized tones** (sine/square wave beeps generated
in Python), not produced sound design — placeholders so the audio hooks exist
and are easy to swap for real SFX later.

## New systems

### 1. Multiple hazards (flood / storm / heat)
`base_level.gd` now runs a generalized version of the original Flood Warning
state machine (`HAZARD_DEFS` dictionary) that covers all three hazards from the
doc:

| Hazard | Collect | Base time | Base damage |
|---|---|---|---|
| Flood | Plastic | 20s | 30 |
| Storm | Wood | 18s | 25 |
| Heat | Plastic (shade cover) | 22s | 20 |

Which hazard fires is determined by the current island (see below). Numbers
scale with island difficulty automatically.

### 2. Multiple islands / progression (`scripts/island_manager.gd`, autoload)
5 islands, each with a hazard, tint, and difficulty: **Plastic Beach** (flood) →
**Deforested Woods** (storm) → **Polluted River Delta** (flood) → **Abandoned
Village** (storm) → **Barren Mountain** (heat). Survive `quests_to_unlock`
hazard challenges (2–3 depending on island) and you'll see "Press N to move on
to the next island" — pressing **N** saves your HP/Max HP/materials/crafted
upgrades and reloads the scene re-themed as the next island.

### 3. Quest log / concurrent quests (`scripts/quest_manager.gd`, autoload)
Every hazard warning now registers as a quest; Maya's intro also grants one.
Press **Q** to open the log and see active + completed quests side by side.

### 4. Maya, the environmental guide (`Scenes/maya.tscn`, `scripts/maya.gd`)
Standing on the beach — walk up and press **E** to talk. First conversation
grants the "Learn the Ropes" quest (auto-completes on your first successful
hazard challenge); later conversations cycle through gameplay tips.

### 5. Rising water / heat haze / storm shake (`scripts/environment_fx.gd`)
Full-screen effect layer that reacts to `hazard_resolved`:
- **Flood failure** → translucent water overlay actually rises up the screen
  and recedes (Storyboard Panel 8).
- **Heat** → pulsing orange haze.
- **Storm** → screen darkens + camera shake (stronger on failure).

### 6. Death / failure state
HP hitting 0 now plays the sprite sheet's existing `"dying"` animation, freezes
the player, and shows a Game Over screen with a **Retry Island** button
(`scripts/game_over.gd`).

### 7. Sound effects (`assets/audio/*.wav`)
Collect blip, craft confirm, warning alarm, success chime, fail thud, NPC talk
blip, game-over drone, island-unlocked fanfare. Wired into pickups, the
crafting menu, and `base_level.gd`'s hazard state machine.

### 8. Crafting (unchanged from last update, still here)
Press **C**. Recipes are plain dictionaries in `crafting_menu.gd` — Water
Filter (heal), Beach Shelter (+Max HP), Flood Barrier (flood resistance).

## Design-doc alignment pass (latest update)

Audited the build against `BARD-EcoQuest.pdf` and closed the gaps where the
document specifies something the game didn't have.

### Main menu + loading handoff
`Scenes/loading_screen.tscn` now fades into `Scenes/main_menu.tscn` instead of
dropping straight into the game. The loading screen still preloads `main.tscn`
in the background and hands it to the new `GameBoot` autoload, so **New Game**
starts instantly. Buttons: Continue / New Game / How to Play / Settings / Quit
(Quit auto-hides on web builds). Escape backs out of any panel.

### Player customized name (doc 5A: "Name: Player Customized Name")
The doc names the protagonist as player-chosen, but nothing in the build asked
for a name. **New Game** now opens a name prompt (16 chars max, blank falls
back to "Survivor"). The chosen name appears on the HUD, in Maya's greeting and
rewards, in the game-over message, and in the ending screen.
Stored on `GameBoot.player_name`; sanitising lives in `GameBoot.set_player_name()`.

### Ending / Resolution (doc Story Beat 6)
Stabilizing the **last** island previously just printed one line of dialogue.
There is now a proper ending: `Scenes/victory.tscn` + `scripts/victory.gd`,
instanced in `main.tscn`. It pauses the game and shows a run summary — islands
stabilized, hazards survived, hazards failed, lifetime plastic and wood, gear
crafted — with **Main Menu** and **Keep Exploring** (dismiss and carry on).

New counters on `IslandManager`: `total_hazards_survived`, `total_hazards_failed`,
`islands_stabilized`, plus `register_failure()` and `is_final_island_complete()`.
New counters on the player: `lifetime_plastic` / `lifetime_wood`, which persist
across islands and are *not* reduced by crafting, so the summary reflects
everything ever cleaned up.

### Maya as quest-giver and rewarder (doc 5B)
The doc lists her core verbs as Guide / Explain / Give quests / Provide
information / **Reward**, and gives her an escalating arc. She previously only
handed out one intro quest and cycled fixed tips. Now talking to her:
1. **First talk** — greets you by name and grants the intro quest.
2. **Owes a reward** — one supply drop per hazard you've survived since you last
   checked in (8 plastic, 5 wood, 15 HP). Not farmable by re-talking.
3. **Otherwise** — advice matched to the current island's hazard
   (flood / storm / heat), falling back to general tips.

### Bugs found and fixed along the way
- `collectible_item.gd` used a ternary as a statement (`$Sprite2D.hide() if ...
  else null`). `hide()` returns void, so this threw a runtime error the moment
  the player touched *any* collectible. Replaced with a plain `if`.
- `main.gd` called `hud.connect_to_level(level_root)` a second time on the final
  island ("no-op, keeps HUD alive"). It is not a no-op — it threw four
  "Signal is already connected" errors. Removed; that path now shows the ending.
- `island_manager.gd` declared `island_unlocked_next` but never emitted it.
  It is now emitted when an island is stabilized.

### Climax escalation (doc Story Beat 5, "Climax")
The doc describes the final challenge on an island as distinctly harder than
the ones before it: *"the environmental challenges become more difficult... a
major disaster warning appears."* Previously every hazard challenge on an
island used the same numbers — there was no distinct climax. Now the specific
challenge that stabilizes the island (the last one needed to hit
`quests_to_unlock`) is scaled further on top of the island's normal
difficulty: 1.6x the required materials, 0.75x the time, 1.5x the damage on
failure, a "MAJOR DISASTER WARNING!" banner instead of the normal one, and a
stronger environment-FX response (higher floodwater, hotter haze, harder
storm shake/darkening). `base_level.gd`'s `_is_climax_challenge()` /
`_get_hazard_def()` decide this; the flag rides along on `hazard_resolved`'s
new third argument into `environment_fx.gd`.

### "Almost there!" (doc Storyboard Panel 6, "Final Collection")
The storyboard specifically calls for this bark as the player closes in on a
timed challenge's target: *"Player attempts to reach the required 50 pieces
... Dialogue: 'Almost there!'"* It wasn't in the game at all before. Now
`base_level.gd` shows it once per challenge, the first time collected
progress crosses 75% of the requirement, for any hazard type (not just
flood). Resets cleanly for the next challenge.

### Maya actually gives quests now (doc 5B: "Give quests", Character Arc)
Previously she only ever granted a single quest in the entire game (the intro,
on the very first conversation) and every other conversation just cycled
fixed advice — which doesn't match her documented arc: *"begins by providing
basic guidance... as the player progresses, she provides more challenging
quests."* She now grants an explicit **"Stabilize <Island Name>"** quest once
per island, worded from that island's own hazard and difficulty so the text
itself escalates (e.g. Barren Mountain's asks for 3 heat-wave survivals
instead of 2 floods on Plastic Beach). It auto-completes the moment the
island is stabilized, whether or not the player talks to her again first.
On island 1 this comes on her *second* conversation (after the intro); on
every later island — where there's no intro to repeat — it comes on the
*first*, with different, less-first-timer dialogue. Priority order per talk
is now: intro (island 1, once) → this island's quest (once per island) →
reward if one's owed → general advice.

## Latest update: persistent save/load

Closed the biggest item from "Known gaps" below: progress used to live only
in the `GameBoot`/`IslandManager`/`QuestManager` autoloads, so it survived
island changes and trips to the menu but was gone the moment the game process
closed — there was no real "Continue" across separate sessions.

### `scripts/save_manager.gd` (new autoload: `SaveManager`)
Writes a single JSON file to `user://ecoquest_save.json` containing the
player's name, current island index + progress toward unlocking the next one,
run-wide totals (hazards survived/failed, islands stabilized), the full
player state (HP, max HP, materials, flood resistance, crafted items,
lifetime totals), and the quest log (active + completed, in order).

- `SaveManager.save_game(player)` — snapshots everything to disk. Autosaves
  fire after every hazard survived, on island advance, and when the final
  island is stabilized (see `main.gd`).
- `SaveManager.load_into_autoloads()` — reads the file back into the
  `GameBoot`/`IslandManager`/`QuestManager` autoloads *before* the game scene
  loads, so the level/player pick it up the same way they already did for
  in-session island transitions (`player.gd`'s existing
  `IslandManager.apply_saved_state()` call needed no changes).
- `SaveManager.has_save()` / `clear_save()` — the main menu now offers
  **Continue** on a fresh launch if a save file exists on disk, not just
  when a run is already active in memory (`GameBoot.has_continuable_run()`).
  **New Game** clears any old save first so it can't bleed into a fresh run.

This is a flat JSON file, not Godot's `ConfigFile`/resource save format, so
it's easy to inspect or hand-edit while testing — open
`%APPDATA%/Godot/app_userdata/EcoQuest/ecoquest_save.json` (Windows) or the
equivalent `user://` path on other platforms.

### Known gaps still open (deliberately not done)
- ~~Islands still share one tilemap~~ - fixed in Update 10.
- The doc's storyboard Panels 8-9 describe the player physically moving to high
  ground during a flood; the flood is currently a full-screen effect plus HP
  damage, not terrain the player navigates.

## Controls

| Key | Action |
|---|---|
| WASD / Arrows | Move |
| C | Toggle Crafting menu |
| Q | Toggle Quest Log |
| E | Talk to Maya (when nearby) |
| N | Advance to the next island (once unlocked) |
| Esc | Close an open menu panel |

## Key files map

| File | Purpose |
|---|---|
| `scripts/island_manager.gd` (autoload) | Island list, hazard/tint/difficulty + `terrain_scene` per island, cross-island player-state persistence |
| `Scenes/levels/islands/island_N_*.tscn` | One map per island (TileMapLayer + `PlayerStart` / `MayaSpot` markers) |
| `assets/tilesets/eco_tileset.tres` | Shared TileSet: all 8 tile sheets + collision |
| `scripts/quest_manager.gd` (autoload) | Active/completed quest tracking |
| `scripts/base_level.gd` | Generalized hazard state machine, spawning, quest hookups, SFX triggers |
| `scripts/player.gd` | HP/materials/crafting, dying animation, state restore on island change |
| `scripts/maya.gd` + `Scenes/maya.tscn` | NPC dialogue + intro quest |
| `scripts/environment_fx.gd` + `Scenes/environment_fx.tscn` | Flood/heat/storm full-screen effects |
| `scripts/game_over.gd` + `Scenes/game_over.tscn` | Death screen + retry |
| `scripts/quest_log.gd` + `Scenes/quest_log.tscn` | Quest log UI |
| `scripts/crafting_menu.gd` + `Scenes/crafting_menu.tscn` | Crafting UI |
| `scripts/hud.gd` + `Scenes/hud.tscn` | HP bar, resource counters, banners, island name |
| `scripts/main.gd` | Wires everything together, handles island-advance input |

## How to open

1. Open Godot **4.3+**, **Import** this folder's `project.godot`.
2. Press **F5** — `Scenes/loading_screen.tscn` is the entry scene; it shows the loading bar, then hands off to `main.tscn`.
3. Explore for ~10s to trigger the first hazard warning. Talk to Maya (E) any
   time. Craft (C) once you've got materials. Check quests (Q).

## Suggested next steps
- Add tree / building sprites on top of the new island maps (the tileset has none yet).
- Replace the synthesized `.wav` files with real sound design.
- Add more recipes / hazard types (the dictionary-driven design makes this a
  copy-paste-and-tweak job in `HAZARD_DEFS` and `crafting_menu.gd`'s `RECIPES`).
- Add manual save slots / multiple save files if you want more than one run
  saved at once (currently there's a single save file, overwritten on autosave).

## Menu music

`assets/audio/menu_theme.wav` (the island-exploration theme track) now plays
on the main menu — looped via the `.wav.import` (`edit/loop_mode=1`), faded
in on `%MusicPlayer` as the menu itself fades in, faded down and stopped when
the player leaves for the name prompt/game so it never bleeds under gameplay
music/SFX. It shares the `Master` bus, so the Settings volume slider affects
it the same as everything else.

## Loading screen

Pressing Play now opens `Scenes/loading_screen.tscn` (`scripts/loading_screen.gd`):
`assets/images/UI/loading_screen.jpg` fills the screen, a progress bar fills while `main.tscn` loads
on a background thread, then it fades into the game.

Tweak the constants at the top of `loading_screen.gd`:
- `MIN_DISPLAY_TIME` — minimum seconds the screen stays up (default 3.0). The game
  loads fast, so this keeps the bar visible; on a slow machine the bar just follows
  the real load progress.
- `STATUS_MESSAGES` — the text shown as the bar fills.
- `GAME_SCENE_PATH` — the scene to load next.

Island changes and *Retry Island* reload `main.tscn` directly, so they skip the
loading screen.

Also fixed in this update: two `var x := ...` lines in `base_level.gd`
(`shortfall`, `shortfall2`) that failed to parse in Godot 4.7 ("Cannot infer the
type") and stopped the game from starting; they now have explicit `int` types.

---

## Update 9 — quest fixes

- **Duplicate "Flood Warning!" quests fixed.** Failed warnings used to stay "active" forever, and a new one was added each time. Now a failed warning is removed from the log, only one timed warning exists at a time, and old duplicates in existing saves are cleaned up on load.
- **Warnings are winnable.** Flood: 20 plastic / 45 s, Storm: 12 wood / 40 s, Heat: 18 plastic / 45 s (still scaled per island). Materials you're already carrying count. The HUD shows `have/needed` next to the timer.
- **New side quests** (max 3 active, more unlock as you finish them, each gives a reward): collect 25 bottles, collect 25 bags, craft a Water Filter, collect wood, build a Beach Shelter, build a Flood Barrier. They show progress bars in the Quest Log (Q).
- **Island travel:** hazards stop once an island is stabilized, the HUD shows "Hazards survived x/y", and a permanent "Press N to sail" prompt appears. Continuing a save on a stabilized island restores the prompt, and the autosave now includes the latest survived hazard.

---

## Update 10 - a different map for every island

Moving to the next island (N) used to reload the same tilemap with a colour
tint. Now `base_level.gd` loads the island's own map from
`IslandManager.ISLANDS[i].terrain_scene`.

### The five maps (all built only from the tiles you supplied)

| # | Island | Layout |
|---|---|---|
| 1 | **Plastic Beach** | Sand island in open sea with a foam shoreline (`Beach_Tile`), an inland lagoon, a tide pool and two grassy dune patches. |
| 2 | **Deforested Woods** | Grassy island with a rocky coast, a fjord-like inlet into an inland pond, bare logged clearings joined by dirt tracks, and erosion ravines (`Cliff_Tile`). |
| 3 | **Polluted River Delta** | A lake feeds a river that runs to the sea and widens around a silty delta island (reached by a sandbar). Tilled fields (`FarmLand_Tile`) on both banks, a stagnant pond and a collapsed bank. You cross the river at its headwaters. |
| 4 | **Abandoned Village** | Main street, market square, side roads and a pier into a harbour inlet; three overgrown farm plots in cleared yards, house foundations, an old reservoir and sinkholes. |
| 5 | **Barren Mountain** | Mostly bare dirt with rocks, a summit crater (`Cliff_Tile` pit), green oases with ponds and gullies, ringed by scrubby foothills. |

Previews of all five are in `island_previews/`.

### What changed in the project

- **`assets/tilesets/eco_tileset.tres`** (new) - one shared TileSet with all 8
  tile sheets. Sources 0-3 keep the ids the old level used (0 = Path_Tile,
  1 = Grass_Middle, 2 = Water_Middle, 3 = Water_Tile); new: 4 = Beach_Tile,
  5 = Cliff_Tile, 6 = FarmLand_Tile, 7 = Path_Middle. Water and cliff-wall
  tiles have proper (solid) colliders now, so the player can no longer walk
  into the sea. The old one-way water colliders are gone.
- **`Scenes/levels/islands/island_1..5_*.tscn`** (new) - each has a
  `TileMapLayer`, a `PlayerStart` marker and a `MayaSpot` marker. Open one in
  the editor and repaint it with the normal TileMap tool if you want to tweak it.
- **`scripts/island_manager.gd`** - every island entry has a `terrain_scene`.
  The colour tints are now only a very subtle mood shift.
- **`scripts/base_level.gd`** - `_load_island_terrain()` swaps in the island's
  TileMapLayer, moves the player and Maya to the markers, then
  `_build_spawn_cells()` flood-fills from the player's start so plastic and
  wood only spawn on land that can actually be walked to (not in the sea,
  inside cliff pits or on unreachable sandbars). `spawn_top_left/bottom_right`
  remain only as a fallback.
- **`Scenes/levels/base_level.tscn`** - now uses the shared TileSet and holds
  island 1's map as the default, so the level still looks right in the editor.

### Editing tips
- Camera limits are unchanged (36 x 26 tiles), so keep maps inside that area.
  Leave 2+ tiles of sea at the edges.
- The tile sheets are "blob" sets (3x3 edges + 4 inner corners): keep land/water
  shapes at least 2 tiles wide, and farm plots as plain rectangles surrounded by
  a ring of sand (`Path_Middle`).
- Keep corridors at least 2 tiles wide - the player collider is one tile.
- `tools/island_generator/` contains the Python scripts that generated the maps
  (with the autotile rules), in case you want to regenerate or design more islands.

---

## Update 11 - boats, stepping-stone rocks and water wildlife

The sea used to be empty water that only hurt. Now it has things to stand on and
things that live in it. All of it is added by one new script, `scripts/water_life.gd`,
which `base_level.gd` creates right after the water hazard (`_setup_water_life()`).

- **Boats** - up to 3 rowing boats are moored along each island's shore. Step onto the
  deck and the polluted water can't hurt you while you stand on it. They bob gently,
  dip when you board, and have a foam ring and a mooring rope.
- **Stepping-stone rocks** - each boat has a short trail of 3-4 rocks leading out to sea,
  and a few small rock islets sit in the open water. Rocks are safe to stand on too,
  so you can hop out across the water without taking damage.
- **Wildlife** - schools of fish (orange / silver / yellow), sea turtles and drifting
  jellyfish. They only swim in open water, and the fish and turtles swim away when you
  get close. They are decoration: they don't hurt you and can't be collected.

### How "safe" works
`water_hazard.gd` now asks every node in the `water_safe` group `covers(world_pos)` for the
player's feet before it applies damage. `water_life.gd` joins that group and answers true
for boat decks and rock ellipses. There is also a short `ENTER_DELAY` (0.08 s) so hopping
between rocks doesn't flash the warning banner or play the alarm.

### Tweaking it (constants at the top of `water_life.gd`)
| Constant | What it does |
|---|---|
| `MAX_BOATS` | boats per island |
| `TRAIL_STONES` | min / max rocks in each boat's trail |
| `BOAT_MIN_SEPARATION` | cells between boats |
| `FLEE_RADIUS` | how close you can get before fish swim away |
| `_spawn_wildlife()` | how many schools / turtles / jellyfish (scaled by water area) |

The sprites are pixel-art string tables at the bottom of `water_life.gd` (no image files to
import); `tools/water_life_art.py` is the script they were generated from. Boats are placed
by looking for open water next to a shore tile, so they follow whatever map you paint.
