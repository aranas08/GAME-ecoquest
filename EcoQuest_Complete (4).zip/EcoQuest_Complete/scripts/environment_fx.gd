extends CanvasLayer
## environment_fx.gd
## Full-screen hazard visuals:
##  - "flood"  -> rising blue water overlay (Storyboard Panel 8: "Water
##                begins rising around the island")
##  - "heat"   -> pulsing orange haze overlay
##  - "storm"  -> darkening overlay + camera shake (relayed to whichever
##                Camera2D is current)

@onready var water_rect: ColorRect = %WaterRect
@onready var heat_rect: ColorRect = %HeatRect
@onready var storm_rect: ColorRect = %StormRect

var _tween: Tween


func _ready() -> void:
	water_rect.color.a = 0.6
	water_rect.anchor_top = 1.0  # starts fully receded (zero height) at the bottom
	heat_rect.color.a = 0.0
	storm_rect.color.a = 0.0


func play_effect(hazard_type: String, success: bool, is_climax: bool = false) -> void:
	clear_effects()
	match hazard_type:
		"flood":
			_play_flood(success, is_climax)
		"heat":
			_play_heat(success, is_climax)
		"storm":
			_play_storm(success, is_climax)


func clear_effects() -> void:
	if _tween:
		_tween.kill()
	water_rect.anchor_top = 1.0
	heat_rect.color.a = 0.0
	storm_rect.color.a = 0.0


func _play_flood(_success: bool, _is_climax: bool = false) -> void:
	# The flood is now a real wave that sweeps across the island and kills on
	# touch (see disaster_director.gd), so the old screen-space water overlay
	# no longer plays.
	pass


func _play_heat(success: bool, is_climax: bool = false) -> void:
	var peak: float = 0.15 if success else (0.55 if is_climax else 0.4)
	_tween = create_tween()
	_tween.set_loops(4 if is_climax else 3)
	_tween.tween_property(heat_rect, "color:a", peak, 0.4)
	_tween.tween_property(heat_rect, "color:a", peak * 0.4, 0.4)
	_tween.tween_property(heat_rect, "color:a", 0.0, 0.6)


func _play_storm(success: bool, is_climax: bool = false) -> void:
	if not success:
		var peak: float = 0.7 if is_climax else 0.5
		_tween = create_tween()
		_tween.tween_property(storm_rect, "color:a", peak, 0.6)
		_tween.tween_interval(1.1 if is_climax else 0.8)
		_tween.tween_property(storm_rect, "color:a", 0.0, 1.2)
	var shake_duration: float = 0.2 if success else (0.8 if is_climax else 0.5)
	shake_camera(shake_duration)


func shake_camera(duration: float) -> void:
	var camera := get_viewport().get_camera_2d()
	if camera == null:
		return
	var original_offset: Vector2 = camera.offset
	var t := create_tween()
	var steps := 10
	for i in steps:
		var strength: float = 8.0 * (1.0 - float(i) / steps)
		t.tween_property(camera, "offset", original_offset + Vector2(
			randf_range(-strength, strength), randf_range(-strength, strength)
		), duration / steps)
	t.tween_property(camera, "offset", original_offset, 0.05)
