extends Node2D
## water_hazard.gd
## Added to the level by base_level.gd. Makes the sea / ponds walkable but
## harmful: while the player's feet are on water, health drains every tick and
## a warning plays (floating sign, red screen edges, banner, ripples, splashes,
## damage numbers) until they step back onto land.
##
## Water is detected by sampling the tile art under the player's feet, so the
## ragged shoreline counts exactly as it looks on screen.

var WARNING_TEX: Texture2D = load("res://assets/images/decor/warning_sign.png") as Texture2D  # runtime load: a missing file no longer stops the game from starting
var ALARM_SFX: AudioStream = load("res://assets/audio/warning_alarm.wav") as AudioStream  # runtime load: a missing file no longer stops the game from starting
var HURT_SFX: AudioStream = load("res://assets/audio/fail_thud.wav") as AudioStream  # runtime load: a missing file no longer stops the game from starting

## Tile sources whose colliders are removed so the player can wade in:
## water middle (2), water edge (3) and beach (4, which carries a sea strip).
const WALKABLE_WATER_SOURCES := [2, 3, 4]
const TILE_PX := 16

const GRACE_TIME := 0.5          # seconds in water before the first hit
const TICK_TIME := 0.7           # seconds between hits afterwards
const DAMAGE_PER_TICK := 5
const HEAL_DELAY := 1.0          # seconds on dry land before recovery starts
const HEAL_TICK := 0.4           # seconds between heals
const HEAL_PER_TICK := 2
const FEET_OFFSET := Vector2(0, 24)   # from the collision shape's centre
const SIGN_OFFSET_Y := 150.0
const SIGN_SCALE := 5.0
const WATER_TINT := Color(0.72, 0.9, 1.0)
const HIT_TINT := Color(1.0, 0.35, 0.35)
const BOUNDS_MARGIN := 1.0       # tiles kept inside the map edge
const ENTER_DELAY := 0.08        # seconds over water before it counts (lets you hop between stepping stones)

# Swimming: the sprite is cut off below SWIM_CUT_Y (in sprite pixels) so the
# character sinks to the chest, with a water ring around the waterline.
const SWIM_CUT_Y := 2.5
const SWIM_DRY_CUT_Y := 14.0     # cut line when fully above water
const SWIM_RING_RX := 46.0
const SWIM_RING_RY := 15.0
const WATER_DEEP := Color(0.0, 0.43, 0.66)
const WATER_MID := Color(0.0, 0.58, 0.91)
const WATER_FOAM := Color(0.0, 0.8, 0.98)
const SWIM_SHADER_CODE := """
shader_type canvas_item;
uniform float cut_y = 14.0;
varying float local_y;
void vertex() {
	local_y = VERTEX.y;
}
void fragment() {
	if (local_y > cut_y) {
		discard;
	}
}
"""

var _level: Node2D
var _tilemap: TileMapLayer
var _player: CharacterBody2D
var _sprite: AnimatedSprite2D
var _shape: CollisionShape2D
var _camera: Camera2D

var _bounds: Rect2
var _images: Dictionary = {}     # source id -> Image

var _in_water := false
var _wet_time := 0.0             # how long the feet have been over water without a boat/rock under them
var _grace_left := 0.0
var _tick_left := 0.0
var _ripple_clock := 0.0
var _recovering := false
var _heal_delay_left := 0.0
var _heal_tick_left := 0.0
var _time := 0.0
var _warned_once := false
var _ripples: Array[Dictionary] = []
var _swim_amount := 0.0          # 0 = on land, 1 = fully swimming (animated)
var _swim_mat: ShaderMaterial
var _swim_back: Node2D           # water disk drawn under the character
var _swim_front: Node2D          # foam band drawn over the waterline
var _swim_burst: CPUParticles2D
var _swim_tween: Tween

var _sign: Sprite2D
var _splash: CPUParticles2D
var _overlay: CanvasLayer
var _vignette: TextureRect
var _banner: PanelContainer
var _alarm: AudioStreamPlayer
var _hurt: AudioStreamPlayer

var _sign_tween: Tween
var _sign_pulse: Tween
var _fx_tween: Tween
var _vignette_tween: Tween
var _sprite_tween: Tween
var _camera_tween: Tween


func setup(level: Node2D, tilemap: TileMapLayer, player: CharacterBody2D) -> void:
	_level = level
	_tilemap = tilemap
	_player = player
	_sprite = player.get_node_or_null("AnimatedSprite2D") as AnimatedSprite2D
	_shape = player.get_node_or_null("CollisionShape2D") as CollisionShape2D
	_camera = player.get_node_or_null("Camera2D") as Camera2D
	z_index = -1   # ripples sit above the ground but under the player

	_make_water_walkable()
	_compute_bounds()
	_build_effects()


# --- Terrain -------------------------------------------------------------------

## Works on a private copy of the tile set so the shared resource (used by the
## next island's reachability / item placement) keeps its water colliders.
func _make_water_walkable() -> void:
	var ts: TileSet = _tilemap.tile_set.duplicate(true)
	for sid in WALKABLE_WATER_SOURCES:
		if not ts.has_source(sid):
			continue
		var src := ts.get_source(sid) as TileSetAtlasSource
		if src == null:
			continue
		for i in src.get_tiles_count():
			var coords: Vector2i = src.get_tile_id(i)
			for a in src.get_alternative_tiles_count(coords):
				var data: TileData = src.get_tile_data(coords, src.get_alternative_tile_id(coords, a))
				data.set_collision_polygons_count(0, 0)
	_tilemap.tile_set = ts


## Keeps the player inside the drawn map so they can't wade off into the void.
func _compute_bounds() -> void:
	var used: Rect2i = _tilemap.get_used_rect()
	var half := Vector2(TILE_PX, TILE_PX) * 0.5
	var top_left: Vector2 = _tilemap.to_global(_tilemap.map_to_local(used.position) - half)
	var bottom_right: Vector2 = _tilemap.to_global(_tilemap.map_to_local(used.position + used.size - Vector2i.ONE) + half)
	var margin: float = BOUNDS_MARGIN * TILE_PX * _tilemap.global_scale.x
	_bounds = Rect2(top_left + Vector2(margin, margin), bottom_right - top_left - Vector2(margin, margin) * 2.0)


# --- Effects setup ---------------------------------------------------------------

func _build_effects() -> void:
	# Floating warning sign above the player's head.
	_sign = Sprite2D.new()
	_sign.texture = WARNING_TEX
	_sign.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_sign.top_level = true
	_sign.z_index = 60
	_sign.visible = false
	add_child(_sign)

	# Splash droplets at the feet.
	_splash = CPUParticles2D.new()
	_splash.top_level = true
	_splash.z_index = 55
	_splash.emitting = false
	_splash.amount = 18
	_splash.lifetime = 0.55
	_splash.direction = Vector2(0, -1)
	_splash.spread = 60.0
	_splash.gravity = Vector2(0, 560)
	_splash.initial_velocity_min = 150.0
	_splash.initial_velocity_max = 280.0
	_splash.scale_amount_min = 3.0
	_splash.scale_amount_max = 6.0
	var ramp := Gradient.new()
	ramp.offsets = PackedFloat32Array([0.0, 1.0])
	ramp.colors = PackedColorArray([Color(0.85, 0.96, 1.0, 0.95), Color(0.4, 0.8, 1.0, 0.0)])
	_splash.color_ramp = ramp
	add_child(_splash)

	# Swimming visuals: water disk behind the character, foam band in front.
	var shader := Shader.new()
	shader.code = SWIM_SHADER_CODE
	_swim_mat = ShaderMaterial.new()
	_swim_mat.shader = shader
	_swim_mat.set_shader_parameter("cut_y", SWIM_DRY_CUT_Y)
	_swim_back = _make_swim_layer(-1)
	_swim_back.draw.connect(_draw_swim_back)
	_swim_front = _make_swim_layer(2)
	_swim_front.draw.connect(_draw_swim_front)

	# Big splash when diving in / climbing out.
	_swim_burst = CPUParticles2D.new()
	_swim_burst.top_level = true
	_swim_burst.z_index = 56
	_swim_burst.emitting = false
	_swim_burst.one_shot = true
	_swim_burst.explosiveness = 1.0
	_swim_burst.amount = 28
	_swim_burst.lifetime = 0.7
	_swim_burst.direction = Vector2(0, -1)
	_swim_burst.spread = 75.0
	_swim_burst.gravity = Vector2(0, 700)
	_swim_burst.initial_velocity_min = 220.0
	_swim_burst.initial_velocity_max = 420.0
	_swim_burst.scale_amount_min = 4.0
	_swim_burst.scale_amount_max = 8.0
	_swim_burst.color_ramp = _splash.color_ramp
	add_child(_swim_burst)

	# Sounds.
	_alarm = AudioStreamPlayer.new()
	_alarm.stream = ALARM_SFX
	_alarm.volume_db = -8.0
	add_child(_alarm)
	_hurt = AudioStreamPlayer.new()
	_hurt.stream = HURT_SFX
	_hurt.volume_db = -6.0
	add_child(_hurt)

	# Screen-space warning: red pulsing vignette + banner.
	_overlay = CanvasLayer.new()
	_overlay.layer = 12
	add_child(_overlay)

	var grad := Gradient.new()
	grad.offsets = PackedFloat32Array([0.5, 1.0])
	grad.colors = PackedColorArray([Color(0.9, 0.05, 0.05, 0.0), Color(0.9, 0.05, 0.05, 0.7)])
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = 256
	tex.height = 256
	_vignette = TextureRect.new()
	_vignette.texture = tex
	_vignette.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_vignette.stretch_mode = TextureRect.STRETCH_SCALE
	_vignette.set_anchors_preset(Control.PRESET_FULL_RECT)
	_vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_vignette.modulate.a = 0.0
	_vignette.visible = false
	_overlay.add_child(_vignette)

	_banner = PanelContainer.new()
	_banner.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_banner.offset_left = -270.0
	_banner.offset_right = 270.0
	_banner.offset_top = 90.0
	_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.5, 0.06, 0.06, 0.93)
	style.border_color = Color(1.0, 0.82, 0.15, 1.0)
	style.set_border_width_all(3)
	style.set_corner_radius_all(10)
	style.content_margin_left = 22.0
	style.content_margin_right = 22.0
	style.content_margin_top = 10.0
	style.content_margin_bottom = 12.0
	style.shadow_color = Color(0, 0, 0, 0.5)
	style.shadow_size = 8
	_banner.add_theme_stylebox_override("panel", style)
	var box := VBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_banner.add_child(box)
	box.add_child(_make_label("WARNING! POLLUTED WATER!", 26, Color(1.0, 0.9, 0.3)))
	box.add_child(_make_label("Step back onto land to stop losing health", 16, Color(1, 1, 1)))
	_banner.modulate.a = 0.0
	_banner.visible = false
	_overlay.add_child(_banner)


func _make_label(text: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0.1, 0.0, 0.0))
	l.add_theme_constant_override("outline_size", 5)
	return l


# --- Per-frame logic -------------------------------------------------------------

func _physics_process(delta: float) -> void:
	if _player == null or _tilemap == null:
		return
	_time += delta
	if _player.is_defeated:
		if _in_water:
			_leave_water()
		return

	# Inside Maya's house the player is far outside the island map: no map-edge
	# clamp (it snapped the player back every frame) and no water checks.
	if _player.indoors:
		if _in_water:
			_leave_water()
		_wet_time = 0.0
		_update_ripples(delta)
		_update_swim_visuals()
		return

	# Never let the player wade off the edge of the map.
	var p: Vector2 = _player.global_position
	var clamped := Vector2(
		clampf(p.x, _bounds.position.x, _bounds.end.x),
		clampf(p.y, _bounds.position.y, _bounds.end.y))
	if clamped != p:
		_player.global_position = clamped

	# Boats and stepping-stone rocks (water_life.gd) are safe to stand on.
	var feet: Vector2 = _feet()
	var over_water: bool = _is_in_water(feet) and not _on_safe_platform(feet)
	_wet_time = _wet_time + delta if over_water else 0.0
	var now_in_water: bool = over_water and (_in_water or _wet_time >= ENTER_DELAY)
	if now_in_water and not _in_water:
		_enter_water()
	elif not now_in_water and _in_water:
		_leave_water()

	if _in_water:
		_update_in_water(delta)
	elif _recovering:
		_update_recovery(delta)
	_update_ripples(delta)
	_update_swim_visuals()


## True when `world_pos` is on a boat deck or a stepping stone placed by water_life.gd.
func _on_safe_platform(world_pos: Vector2) -> bool:
	for node in get_tree().get_nodes_in_group("water_safe"):
		if node.has_method("covers") and node.covers(world_pos):
			return true
	return false


func _feet() -> Vector2:
	if _shape:
		return _shape.global_position + FEET_OFFSET
	return _player.global_position + Vector2(0, 40)


func _update_in_water(delta: float) -> void:
	# Damage ticks.
	if _grace_left > 0.0:
		_grace_left -= delta
		if _grace_left <= 0.0:
			_apply_damage()
			_tick_left = TICK_TIME
	else:
		_tick_left -= delta
		if _tick_left <= 0.0:
			_apply_damage()
			_tick_left = TICK_TIME

	# Warning sign follows the head and bobs.
	_sign.global_position = _player.global_position + Vector2(0, -SIGN_OFFSET_Y + sin(_time * 7.0) * 6.0)

	# Swimming: treading water bob when still, quicker paddle bob when moving.
	var moving: bool = _player.velocity.length() > 1.0
	if _sprite:
		var bob_speed: float = 8.0 if moving else 2.6
		var bob_amp: float = 1.0 if moving else 1.8
		_sprite.offset = Vector2(0.0 if moving else sin(_time * 1.7) * 0.5, sin(_time * bob_speed) * bob_amp - 0.3)
	var waterline := _waterline()
	_splash.global_position = waterline
	_splash.emitting = moving

	_ripple_clock -= delta
	if _ripple_clock <= 0.0:
		_ripple_clock = 0.18 if moving else 0.55
		_ripples.append({"pos": to_local(waterline), "age": 0.0})


# --- Enter / leave ---------------------------------------------------------------

func _enter_water() -> void:
	_in_water = true
	_recovering = false
	_grace_left = GRACE_TIME
	_tick_left = TICK_TIME
	_ripple_clock = 0.0
	_alarm.play()
	_show_warning()
	_start_swim()
	_tint_sprite(WATER_TINT, 0.2)
	if not _warned_once:
		_warned_once = true
		if _level and _level.has_signal("dialogue_shown"):
			_level.dialogue_shown.emit("The water is polluted! I need to get out before it hurts me.")


func _leave_water() -> void:
	_in_water = false
	_splash.emitting = false
	_hide_warning()
	_tint_sprite(Color.WHITE, 0.25)
	_stop_swim()
	# Out of the water: start recovering lost health.
	if not _player.is_defeated and _player.hp < _player.max_hp:
		_recovering = true
		_heal_delay_left = HEAL_DELAY
		_heal_tick_left = 0.0


## On dry land after wading: health climbs back up until it's full (or the
## player steps into the water again).
func _update_recovery(delta: float) -> void:
	if _player.is_defeated or _player.hp >= _player.max_hp:
		_recovering = false
		return
	if _heal_delay_left > 0.0:
		_heal_delay_left -= delta
		return
	_heal_tick_left -= delta
	if _heal_tick_left <= 0.0:
		_heal_tick_left = HEAL_TICK
		var amount: int = mini(HEAL_PER_TICK, _player.max_hp - _player.hp)
		_player.heal(amount)
		_floating_text("+%d" % amount, Color(0.4, 1.0, 0.5))
		_flash_heal()


func _apply_damage() -> void:
	# Added on top of flood_resistance so crafted gear can't make water harmless.
	_player.take_damage(DAMAGE_PER_TICK + _player.flood_resistance)
	_hurt.play()
	_floating_text("-%d" % DAMAGE_PER_TICK, Color(1.0, 0.3, 0.3))
	_flash_hit()
	_shake_camera()
	_shake_sign()


# --- Warning animations ----------------------------------------------------------

func _show_warning() -> void:
	_kill(_sign_tween)
	_kill(_sign_pulse)
	_kill(_vignette_tween)
	_sign.visible = true
	_sign.scale = Vector2.ZERO
	_sign.modulate = Color.WHITE
	_sign.rotation = 0.0
	_sign_tween = create_tween()
	_sign_tween.tween_property(_sign, "scale", Vector2(SIGN_SCALE, SIGN_SCALE) * 1.25, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_sign_tween.tween_callback(_start_sign_pulse)

	_vignette.visible = true
	_banner.visible = true
	_vignette_tween = create_tween().set_parallel(true)
	_vignette_tween.tween_property(_vignette, "modulate:a", 1.0, 0.25)
	_vignette_tween.tween_property(_banner, "modulate:a", 1.0, 0.25)
	_vignette_tween.chain().tween_callback(_start_vignette_pulse)


func _start_sign_pulse() -> void:
	var big := Vector2(SIGN_SCALE, SIGN_SCALE) * 1.15
	var small := Vector2(SIGN_SCALE, SIGN_SCALE) * 0.92
	_sign_pulse = create_tween().set_loops()
	_sign_pulse.tween_property(_sign, "scale", big, 0.3).set_trans(Tween.TRANS_SINE)
	_sign_pulse.parallel().tween_property(_sign, "modulate", Color(1.0, 0.75, 0.75), 0.3)
	_sign_pulse.tween_property(_sign, "scale", small, 0.3).set_trans(Tween.TRANS_SINE)
	_sign_pulse.parallel().tween_property(_sign, "modulate", Color.WHITE, 0.3)


func _start_vignette_pulse() -> void:
	_vignette_tween = create_tween().set_loops()
	_vignette_tween.tween_property(_vignette, "modulate:a", 0.55, 0.45).set_trans(Tween.TRANS_SINE)
	_vignette_tween.tween_property(_vignette, "modulate:a", 1.0, 0.45).set_trans(Tween.TRANS_SINE)


func _hide_warning() -> void:
	_kill(_sign_tween)
	_kill(_sign_pulse)
	_kill(_vignette_tween)
	_sign_tween = create_tween()
	_sign_tween.tween_property(_sign, "scale", Vector2.ZERO, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
	_sign_tween.tween_callback(func(): _sign.visible = false)
	_vignette_tween = create_tween().set_parallel(true)
	_vignette_tween.tween_property(_vignette, "modulate:a", 0.0, 0.3)
	_vignette_tween.tween_property(_banner, "modulate:a", 0.0, 0.3)
	_vignette_tween.chain().tween_callback(func():
		_vignette.visible = false
		_banner.visible = false)


func _shake_sign() -> void:
	_kill(_fx_tween)
	_fx_tween = create_tween()
	_fx_tween.tween_property(_sign, "rotation", 0.28, 0.05)
	_fx_tween.tween_property(_sign, "rotation", -0.28, 0.08)
	_fx_tween.tween_property(_sign, "rotation", 0.0, 0.06)


func _tint_sprite(color: Color, time: float) -> void:
	if _sprite == null:
		return
	_kill(_sprite_tween)
	_sprite_tween = create_tween()
	_sprite_tween.tween_property(_sprite, "modulate", color, time)


func _flash_hit() -> void:
	if _sprite == null:
		return
	_kill(_sprite_tween)
	_sprite.modulate = HIT_TINT
	_sprite_tween = create_tween()
	_sprite_tween.tween_property(_sprite, "modulate", WATER_TINT if _in_water else Color.WHITE, 0.3)


func _flash_heal() -> void:
	if _sprite == null:
		return
	_kill(_sprite_tween)
	_sprite.modulate = Color(0.6, 1.0, 0.7)
	_sprite_tween = create_tween()
	_sprite_tween.tween_property(_sprite, "modulate", Color.WHITE, 0.35)


func _shake_camera() -> void:
	if _camera == null:
		return
	_kill(_camera_tween)
	_camera.offset = Vector2.ZERO
	_camera_tween = create_tween()
	for i in 4:
		_camera_tween.tween_property(_camera, "offset", Vector2(randf_range(-6, 6), randf_range(-6, 6)), 0.04)
	_camera_tween.tween_property(_camera, "offset", Vector2.ZERO, 0.05)


func _floating_text(text: String, color: Color) -> void:
	var l := Label.new()
	l.text = text
	l.top_level = true
	l.z_index = 70
	l.add_theme_font_size_override("font_size", 34)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0.1, 0.0, 0.0))
	l.add_theme_constant_override("outline_size", 8)
	add_child(l)
	var start: Vector2 = _player.global_position + Vector2(randf_range(-30, 30) - 20, -110)
	l.global_position = start
	var t := create_tween().set_parallel(true)
	t.tween_property(l, "global_position", start + Vector2(0, -80), 0.9).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	t.tween_property(l, "modulate:a", 0.0, 0.9).set_delay(0.3)
	t.chain().tween_callback(l.queue_free)


func _kill(t: Tween) -> void:
	if t and t.is_valid():
		t.kill()


# --- Swimming ---------------------------------------------------------------------

## World position of the waterline (where the sprite is cut off).
func _waterline() -> Vector2:
	return _player.global_position + Vector2(0, SWIM_CUT_Y * _player.scale.y)


func _make_swim_layer(z: int) -> Node2D:
	var n := Node2D.new()
	n.top_level = true
	n.z_as_relative = false
	n.z_index = z
	n.visible = false
	add_child(n)
	return n


func _start_swim() -> void:
	if _sprite == null:
		return
	_kill(_swim_tween)
	_sprite.material = _swim_mat
	_swim_back.visible = true
	_swim_front.visible = true
	_swim_burst.global_position = _waterline()
	_swim_burst.restart()
	_swim_burst.emitting = true
	# Sink into the water and grow the ring.
	_swim_tween = create_tween().set_parallel(true)
	_swim_tween.tween_method(func(v: float): _swim_mat.set_shader_parameter("cut_y", v), SWIM_DRY_CUT_Y, SWIM_CUT_Y, 0.28).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	_swim_tween.tween_property(self, "_swim_amount", 1.0, 0.28).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _stop_swim() -> void:
	if _sprite == null:
		return
	_kill(_swim_tween)
	_sprite.offset = Vector2.ZERO
	_swim_burst.global_position = _waterline()
	_swim_burst.restart()
	_swim_burst.emitting = true
	# Climb back out.
	_swim_tween = create_tween().set_parallel(true)
	_swim_tween.tween_method(func(v: float): _swim_mat.set_shader_parameter("cut_y", v), SWIM_CUT_Y, SWIM_DRY_CUT_Y, 0.22).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	_swim_tween.tween_property(self, "_swim_amount", 0.0, 0.22)
	_swim_tween.chain().tween_callback(_finish_swim_exit)


func _finish_swim_exit() -> void:
	if _in_water:
		return
	if _sprite:
		_sprite.material = null
	_swim_back.visible = false
	_swim_front.visible = false


func _update_swim_visuals() -> void:
	if _swim_amount <= 0.0 and not _in_water:
		return
	var waterline := _waterline()
	_swim_back.global_position = waterline
	_swim_front.global_position = waterline
	_swim_back.queue_redraw()
	_swim_front.queue_redraw()


func _ellipse_points(rx: float, ry: float, n: int = 30) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in n:
		var a: float = TAU * float(i) / float(n)
		pts.append(Vector2(cos(a) * rx, sin(a) * ry))
	return pts


func _ellipse_arc(rx: float, ry: float, a0: float, a1: float, steps: int = 8) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in steps + 1:
		var a: float = lerpf(a0, a1, float(i) / float(steps))
		pts.append(Vector2(cos(a) * rx, sin(a) * ry))
	return pts


## Water disk around the character (behind the sprite): halo, body of water,
## darker centre and slowly circling sparkles.
func _draw_swim_back() -> void:
	var k: float = clampf(_swim_amount, 0.0, 1.0)
	if k <= 0.01:
		return
	var breathe: float = sin(_time * 3.0) * 1.6
	var scale_k: float = 0.55 + 0.45 * k
	var rx: float = SWIM_RING_RX * scale_k + breathe
	var ry: float = SWIM_RING_RY * scale_k + breathe * 0.4
	_swim_back.draw_colored_polygon(_ellipse_points(rx + 8.0, ry + 5.0), Color(WATER_FOAM, 0.45 * k))
	_swim_back.draw_colored_polygon(_ellipse_points(rx, ry), Color(WATER_MID, 0.96 * k))
	_swim_back.draw_colored_polygon(_ellipse_points(rx * 0.72, ry * 0.62), Color(WATER_DEEP, 0.55 * k))
	for i in 3:
		var a0: float = _time * 1.5 + float(i) * TAU / 3.0
		_swim_back.draw_polyline(_ellipse_arc(rx * 0.9, ry * 0.9, a0, a0 + 0.7), Color(1, 1, 1, 0.7 * k), 3.0)


## Wavy foam band across the waterline (in front of the sprite). It hides the
## hard cut edge and ripples faster while swimming than while treading water.
func _draw_swim_front() -> void:
	var k: float = clampf(_swim_amount, 0.0, 1.0)
	if k <= 0.01:
		return
	var moving: bool = _in_water and _player.velocity.length() > 1.0
	var amp: float = 3.5 if moving else 2.5
	var speed: float = 11.0 if moving else 5.0
	var half: float = 38.0 * k + 4.0
	var band := PackedVector2Array()
	var crest := PackedVector2Array()
	var x: float = -half
	while x <= half:
		var y: float = 3.0 + sin(x * 0.14 + _time * speed) * amp
		band.append(Vector2(x, y))
		crest.append(Vector2(x, y - 3.0))
		x += 5.0
	_swim_front.draw_polyline(band, Color(WATER_MID, k), 11.0)
	_swim_front.draw_polyline(band, Color(WATER_FOAM, k), 6.0)
	_swim_front.draw_polyline(crest, Color(1, 1, 1, 0.85 * k), 2.0)
	if moving:
		# Little V-shaped wake trailing behind the swimmer.
		var back: Vector2 = -_player.velocity.normalized()
		var side := Vector2(-back.y, back.x)
		for sgn in [-1.0, 1.0]:
			var wake := PackedVector2Array([Vector2(0, 8), back * 34.0 + side * sgn * 16.0 + Vector2(0, 8), back * 62.0 + side * sgn * 34.0 + Vector2(0, 8)])
			_swim_front.draw_polyline(wake, Color(1, 1, 1, 0.55 * k), 3.0)


# --- Ripples ---------------------------------------------------------------------

func _update_ripples(delta: float) -> void:
	if _ripples.is_empty():
		return
	for r in _ripples:
		r.age += delta
	var alive: Array[Dictionary] = []
	for r in _ripples:
		if r.age < 0.9:
			alive.append(r)
	_ripples = alive
	queue_redraw()


func _draw() -> void:
	for r in _ripples:
		var t: float = r.age / 0.9
		var alpha: float = (1.0 - t) * 0.85
		draw_set_transform(r.pos, 0.0, Vector2(1.0, 0.45))
		draw_arc(Vector2.ZERO, lerpf(8.0, 56.0, t), 0.0, TAU, 32, Color(0.9, 0.97, 1.0, alpha), 4.0)
		draw_arc(Vector2.ZERO, lerpf(2.0, 34.0, t), 0.0, TAU, 28, Color(0.6, 0.85, 1.0, alpha * 0.8), 3.0)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# --- Water detection -------------------------------------------------------------

## True when the pixel of tile art under `world_pos` is water-blue. Off-map
## positions count as open sea.
func _is_in_water(world_pos: Vector2) -> bool:
	var local: Vector2 = _tilemap.to_local(world_pos)
	var cell: Vector2i = _tilemap.local_to_map(local)
	var sid: int = _tilemap.get_cell_source_id(cell)
	if sid == -1:
		return true
	var src := _tilemap.tile_set.get_source(sid) as TileSetAtlasSource
	if src == null:
		return false
	var img: Image = _image_for(sid, src)
	if img == null:
		return sid == 2 or sid == 3
	var region: Rect2i = src.get_tile_texture_region(_tilemap.get_cell_atlas_coords(cell), 0)
	var off: Vector2 = local - _tilemap.map_to_local(cell) + Vector2(TILE_PX, TILE_PX) * 0.5
	var px: int = region.position.x + clampi(int(floor(off.x)), 0, TILE_PX - 1)
	var py: int = region.position.y + clampi(int(floor(off.y)), 0, TILE_PX - 1)
	if px < 0 or py < 0 or px >= img.get_width() or py >= img.get_height():
		return false
	var c: Color = img.get_pixel(px, py)
	return c.a > 0.5 and c.b > 0.55 and c.r < 0.2


func _image_for(sid: int, src: TileSetAtlasSource) -> Image:
	if _images.has(sid):
		return _images[sid]
	var img: Image = null
	if src.texture:
		img = src.texture.get_image()
		if img and img.is_compressed():
			img.decompress()
	_images[sid] = img
	return img
