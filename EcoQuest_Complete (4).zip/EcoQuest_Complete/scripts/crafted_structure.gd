extends Node2D
## crafted_structure.gd
## The thing you actually BUILD when you craft the Beach Shelter or the Flood
## Barrier. It appears in front of the character and assembles itself piece by
## piece with hammer sparks and dust, then finishes with a sparkle ring.
##
##  beach_shelter - posts rise, a ridge beam goes on, a recycled-plastic tarp
##                  roof unfolds, palm fronds and a lantern finish it. It also
##                  gives shade against the heat wave.
##  flood_barrier - stakes go in, then sandbags stack up one by one. It is solid.
##
## Set `kind` (and optionally `target`) before adding to the scene tree.

const BUILD_TIME := 2.6

var kind: String = "beach_shelter"
var target: Node2D = null          # the player (used for draw order)
var _t := 0.0
var _done := false
var _puffs: Array[Dictionary] = []
var _sparks: Array[Dictionary] = []
var _label_alpha := 1.0


func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST


func _process(delta: float) -> void:
	_t += delta
	var p: float = clampf(_t / BUILD_TIME, 0.0, 1.0)
	# Dust at the base and sparks near the work while building.
	if p < 1.0:
		if randf() < delta * 14.0:
			_puffs.append({"pos": Vector2(randf_range(-110.0, 110.0), randf_range(-6.0, 10.0)), "life": 0.0})
		if randf() < delta * 22.0:
			var top: float = -40.0 - 90.0 * p if kind == "beach_shelter" else -20.0 - 40.0 * p
			_sparks.append({"pos": Vector2(randf_range(-80.0, 80.0), top), "vel": Vector2(randf_range(-60.0, 60.0), randf_range(-120.0, -30.0)), "life": 0.0})
	for pf in _puffs:
		pf.life = float(pf.life) + delta
	for sp in _sparks:
		sp.life = float(sp.life) + delta
		sp.pos = Vector2(sp.pos) + Vector2(sp.vel) * delta
		sp.vel = Vector2(sp.vel) + Vector2(0.0, 380.0) * delta
	var live_puffs: Array[Dictionary] = []
	for pf in _puffs:
		if float(pf.life) < 0.9:
			live_puffs.append(pf)
	_puffs = live_puffs
	var live_sparks: Array[Dictionary] = []
	for sp in _sparks:
		if float(sp.life) < 0.6:
			live_sparks.append(sp)
	_sparks = live_sparks
	if p >= 1.0 and not _done:
		_done = true
		_finish()
	if _done:
		_label_alpha = clampf(1.0 - (_t - BUILD_TIME - 1.4) / 0.8, 0.0, 1.0)
	# Draw order: behind the player when the player is lower on screen.
	if target != null and is_instance_valid(target):
		z_index = 1 if target.global_position.y + 24.0 < global_position.y else -1
	queue_redraw()


func _finish() -> void:
	if kind == "flood_barrier":
		var body := StaticBody2D.new()
		body.collision_layer = 1
		body.collision_mask = 0
		var shape := CollisionShape2D.new()
		var rect := RectangleShape2D.new()
		rect.size = Vector2(220.0, 34.0)
		shape.shape = rect
		shape.position = Vector2(0.0, -14.0)
		body.add_child(shape)
		add_child(body)
	else:
		add_to_group("shade")
		set_meta("shade_radius", 170.0)


func _ease_out_back(x: float) -> float:
	var c1 := 1.70158
	var c3 := c1 + 1.0
	return 1.0 + c3 * pow(x - 1.0, 3.0) + c1 * pow(x - 1.0, 2.0)


## Progress of one build step: 0 before `start`, 1 after `start + length`.
func _step(p: float, start: float, length: float) -> float:
	return clampf((p - start) / length, 0.0, 1.0)


func _draw() -> void:
	var p: float = clampf(_t / BUILD_TIME, 0.0, 1.0)
	# Ground shadow / sand patch.
	draw_set_transform(Vector2(0, 6), 0.0, Vector2(1.0, 0.28))
	draw_circle(Vector2.ZERO, 130.0, Color(0, 0, 0, 0.22 * minf(p * 3.0, 1.0)))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if kind == "flood_barrier":
		_draw_barrier(p)
	else:
		_draw_shelter(p)
	for pf in _puffs:
		var k: float = float(pf.life) / 0.9
		draw_circle(Vector2(pf.pos) + Vector2(0.0, -k * 26.0), 8.0 + 16.0 * k, Color(0.9, 0.84, 0.7, 0.5 * (1.0 - k)))
	for sp in _sparks:
		var k2: float = float(sp.life) / 0.6
		draw_rect(Rect2(Vector2(sp.pos) - Vector2(2, 2), Vector2(4, 4)), Color(1.0, 0.9, 0.4, 1.0 - k2))
	# Finishing sparkle ring + label.
	if _done:
		var r: float = clampf((_t - BUILD_TIME) / 0.7, 0.0, 1.0)
		if r < 1.0:
			draw_set_transform(Vector2(0, -50), 0.0, Vector2(1.0, 0.6))
			draw_arc(Vector2.ZERO, 40.0 + 150.0 * r, 0.0, TAU, 48, Color(1.0, 0.95, 0.5, 1.0 - r), 6.0)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		var title: String = "Beach Shelter built!" if kind == "beach_shelter" else "Flood Barrier built!"
		var font: Font = ThemeDB.fallback_font
		var ty: float = -215.0 if kind == "beach_shelter" else -120.0
		draw_string(font, Vector2(-121, ty + 1), title, HORIZONTAL_ALIGNMENT_CENTER, 240.0, 24, Color(0, 0, 0, 0.7 * _label_alpha))
		draw_string(font, Vector2(-122, ty), title, HORIZONTAL_ALIGNMENT_CENTER, 240.0, 24, Color(0.75, 1.0, 0.6, _label_alpha))


func _draw_shelter(p: float) -> void:
	var wood := Color("#8a5a34")
	var wood_dark := Color("#4d3019")
	# 1) Posts rise out of the sand.
	var post_h: float = 108.0 * _ease_out_back(_step(p, 0.0, 0.3))
	for x in [-82.0, 82.0]:
		draw_rect(Rect2(Vector2(x - 6.0, -post_h), Vector2(12.0, post_h)), wood)
		draw_rect(Rect2(Vector2(x - 6.0, -post_h), Vector2(12.0, post_h)), wood_dark, false, 2.0)
	# 2) Ridge beam slides across.
	var beam: float = _step(p, 0.3, 0.15)
	if beam > 0.0:
		draw_rect(Rect2(Vector2(-96.0, -114.0), Vector2(192.0 * beam, 10.0)), wood)
		draw_rect(Rect2(Vector2(-96.0, -114.0), Vector2(192.0 * beam, 10.0)), wood_dark, false, 2.0)
	# 3) Recycled-plastic tarp roof unfolds from the ridge.
	var roof: float = _ease_out_back(_step(p, 0.45, 0.3))
	if roof > 0.0:
		draw_set_transform(Vector2(0, -110), 0.0, Vector2(1.0, roof))
		var tarp := PackedVector2Array([Vector2(-108, 0), Vector2(0, -44), Vector2(108, 0), Vector2(120, 62), Vector2(-120, 62)])
		draw_colored_polygon(tarp, Color("#3d8fcf"))
		draw_colored_polygon(PackedVector2Array([Vector2(0, -44), Vector2(108, 0), Vector2(120, 62), Vector2(0, 62)]), Color("#2f78b4"))
		draw_polyline(PackedVector2Array([Vector2(-108, 0), Vector2(0, -44), Vector2(108, 0), Vector2(120, 62), Vector2(-120, 62), Vector2(-108, 0)]), Color("#1d4c78"), 4.0)
		for sx in [-60.0, -20.0, 20.0, 60.0]:
			draw_line(Vector2(sx * 0.5, -22.0 + absf(sx) * 0.1), Vector2(sx * 1.9, 60.0), Color(1, 1, 1, 0.25), 3.0)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	# 4) Woven mat on the sand under the roof.
	var mat: float = _step(p, 0.7, 0.12)
	if mat > 0.0:
		draw_set_transform(Vector2(0, -2), 0.0, Vector2(1.0, 0.3))
		draw_circle(Vector2.ZERO, 70.0 * mat, Color("#d9b46a"))
		draw_arc(Vector2.ZERO, 70.0 * mat, 0.0, TAU, 32, Color("#9c7a3a"), 4.0)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	# 5) Palm fronds on top and a glowing lantern.
	var fronds: float = _ease_out_back(_step(p, 0.82, 0.14))
	if fronds > 0.0:
		for i in 5:
			var ang: float = -PI * 0.5 + (float(i) - 2.0) * 0.5
			var base := Vector2(0, -150)
			var tip: Vector2 = base + Vector2(cos(ang), sin(ang)) * 58.0 * fronds + Vector2(0, 14.0 * fronds)
			draw_line(base, tip, Color("#2f8f3a"), 8.0 * fronds)
			draw_line(base, tip, Color("#52b44a"), 3.0 * fronds)
	var lamp: float = _step(p, 0.9, 0.1)
	if lamp > 0.0:
		var glow: float = 0.75 + 0.25 * sin(_t * 6.0)
		draw_line(Vector2(0, -104), Vector2(0, -88), wood_dark, 2.0)
		draw_circle(Vector2(0, -80), 22.0 * lamp, Color(1.0, 0.8, 0.35, 0.25 * glow))
		draw_circle(Vector2(0, -80), 8.0 * lamp, Color(1.0, 0.88, 0.5, glow))


func _draw_barrier(p: float) -> void:
	var wood := Color("#8a5a34")
	var wood_dark := Color("#4d3019")
	# 1) Stakes hammered in at both ends.
	var stake_h: float = 70.0 * _ease_out_back(_step(p, 0.0, 0.22))
	for x in [-104.0, 104.0]:
		draw_rect(Rect2(Vector2(x - 6.0, -stake_h), Vector2(12.0, stake_h)), wood)
		draw_rect(Rect2(Vector2(x - 6.0, -stake_h), Vector2(12.0, stake_h)), wood_dark, false, 2.0)
	# 2) Sandbags stack up one at a time, bottom row first.
	var rows := [6, 5, 4]
	var index := 0
	var total := 15
	for r in rows.size():
		var count: int = rows[r]
		var row_w: float = float(count) * 36.0
		for c in count:
			var start: float = 0.2 + 0.74 * float(index) / float(total)
			var k: float = _ease_out_back(_step(p, start, 0.1))
			index += 1
			if k <= 0.0:
				continue
			var cx: float = -row_w * 0.5 + 18.0 + float(c) * 36.0
			var cy: float = -12.0 - float(r) * 20.0
			# Drops in from above.
			var drop: float = (1.0 - minf(k, 1.0)) * -50.0
			var bag := Rect2(Vector2(cx - 17.0, cy - 10.0 + drop), Vector2(34.0, 20.0))
			var shade: float = 0.0 if (c + r) % 2 == 0 else 0.07
			draw_rect(bag, Color(0.80 - shade, 0.68 - shade, 0.44 - shade))
			draw_rect(bag, Color("#6b5530"), false, 2.0)
			draw_line(Vector2(cx - 8.0, cy + drop), Vector2(cx + 8.0, cy + drop), Color("#6b5530"), 2.0)
	# 3) Top plank and little warning flag once finished.
	var top: float = _step(p, 0.95, 0.05)
	if top > 0.0:
		draw_rect(Rect2(Vector2(-112.0, -72.0), Vector2(224.0 * top, 8.0)), wood)
		draw_rect(Rect2(Vector2(-112.0, -72.0), Vector2(224.0 * top, 8.0)), wood_dark, false, 2.0)
		var wave: float = sin(_t * 6.0) * 4.0
		draw_line(Vector2(104, -72), Vector2(104, -104), wood_dark, 3.0)
		draw_colored_polygon(PackedVector2Array([Vector2(104, -104), Vector2(128, -96 + wave), Vector2(104, -88)]), Color("#e84a3a"))
