extends Node2D
## Maya's island home.
##
## OUTSIDE: walk across the cobbled forecourt (the "lobby") and straight into the
## doorway. The door swings open as you approach and you walk in with a quick
## fade - no button needed (pressing E at the door still works).
##
## INSIDE: the whole cottage is one open, walkable room. Your FEET are what
## collide with the world (the player's collision box is moved down to the
## shoes while indoors), so the character really stands on the floorboards and
## walks around the furniture instead of floating on top of it.
##   * Maya is busy cooking at her stove. You can walk straight through her; press
##     E next to her and she turns to face you and the conversation starts.
##   * Walk up to the bed, bookshelf, stove, table... -> "Press E" for a note.
##   * Walk back out through the front door at the bottom to leave.
## The camera follows you and re-fits itself when the window is resized.

const INTERIOR_OFFSET := Vector2(12000, 12000) # isolated room, away from ocean/island hazards
const ROOM_SCALE := 0.9
const ART_SIZE := Vector2(1536, 1024)
const ART_PATH := "res://assets/images/interiors/maya_house_interior_open.png"
const ART_FALLBACK_PATH := "res://assets/images/interiors/maya_house_interior.png"
## Layout numbers below ("ref" coordinates) were measured on a 1344x896 preview
## of the artwork, so they are easy to tweak by eye.
const REF_TO_ART := 1536.0 / 1344.0
const ROOM_REF := Rect2(36, 0, 1272, 866)   # the cottage part of the artwork

const ENTRY_DISTANCE := 150.0     # outdoors: "near the door" for prompts / E
const DOOR_TRIGGER := Rect2(-34, 26, 68, 38)  # house-local: walk in here = enter
const DOOR_OPEN_DISTANCE := 130.0 # the door swings open when you get this close
const TALK_DISTANCE := 130.0      # indoors: how close (feet to feet) E works on Maya
const HOTSPOT_REACH := 55.0       # ref units around a piece of furniture where E works
const INDOOR_SPEED_SCALE := 0.8
const INDOOR_PLAYER_SCALE := 3.0  # the player is drawn 4x outdoors; slightly smaller fits the room
const CAMERA_CLOSENESS := 1.0     # 1.0 = whole room fits on screen and the camera stays perfectly still
## Outside sprite of Maya's house. Change HOUSE_DRAW_SCALE / HOUSE_DRAW_POS to resize or move it.
const HOUSE_TEXTURE: Texture2D = preload("res://assets/images/house/maya_house.png")
const HOUSE_DRAW_SCALE := 0.8
const HOUSE_DRAW_POS := Vector2(-212.0, -236.0)   # house-local top-left corner of the sprite
## Solid footprint of the cabin sprite (house-local px), a doorway gap at x -38..38.
const HOUSE_SOLIDS: Array[Rect2] = [
	Rect2(51, -222, 15, 12),
	Rect2(29, -210, 40, 12),
	Rect2(8, -198, 69, 12),
	Rect2(-12, -186, 98, 12),
	Rect2(-41, -174, 130, 12),
	Rect2(-67, -162, 163, 12),
	Rect2(-74, -150, 179, 12),
	Rect2(-101, -138, 218, 12),
	Rect2(-120, -126, 238, 12),
	Rect2(-133, -114, 258, 12),
	Rect2(-121, -102, 254, 12),
	Rect2(-119, -90, 246, 12),
	Rect2(-117, -78, 240, 12),
	Rect2(-117, -66, 239, 12),
	Rect2(-119, -54, 241, 12),
	Rect2(-121, -42, 243, 12),
	Rect2(-121, -30, 243, 12),
	Rect2(-126, -18, 250, 12),
	Rect2(-114, -6, 76, 12),
	Rect2(38, -6, 87, 12),
	Rect2(-92, 6, 54, 12),
	Rect2(38, 6, 69, 12),
	Rect2(-90, 18, 52, 12),
	Rect2(38, 18, 57, 12),
	Rect2(-95, 30, 57, 12),
	Rect2(38, 30, 23, 12),
	Rect2(-68, 42, 30, 12),
	Rect2(-61, 54, 23, 8)
]
const BACKDROP_COLOR := Color("#1b110c")

## The player sprite is 32x32 and the shoes sit at local (-0.5, +8). The
## collision box used indoors / near the house is a small box under the feet.
const FEET_LOCAL := Vector2(-0.5, 5.5)
const FEET_SIZE := Vector2(11, 5)
const MAYA_FEET_Y := 46.0         # Maya's origin is mid-body; her feet are this far below it

const SPAWN_REF := Vector2(672, 706)           # where you appear (just inside the door)
const EXIT_TRIGGER_REF := Rect2(598, 772, 150, 60)  # feet here + walking down = leave
const EXIT_E_REF := Rect2(598, 690, 150, 142)       # feet here + E = leave too

## Where Maya's boots are while she cooks (just below her stove), and where the
## kettle steam rises from (ref units).
const MAYA_COOK_REF := Vector2(838, 308)
const STEAM_REF := Vector2(852, 200)
## Ground-level feet depth ordering: the player is always drawn at this z while indoors.
const INDOOR_PLAYER_Z := 1

## Solid parts of the room as [x0, y0, x1, y1] in ref units. These stop your
## FEET (not your head), so the character stands ON the floorboards and walks
## around the furniture. Boxes follow the footprint of each piece of furniture
## in the artwork; the floor itself runs x 140..1203, y 228..752.
const SOLIDS_REF := [
	# Outer walls: left, right, back (bookshelf wall) and the front wall with a
	# doorway gap between x=598 and x=750.
	[-300, -300, 140, 1200],
	[1203, -300, 1650, 1200],
	[-300, -300, 1650, 228],
	[-300, 752, 598, 1200],
	[750, 752, 1650, 1200],
	[598, 834, 750, 1200],
	# Tall wooden room divider (its lower end is open: walk between the halves).
	[528, 228, 604, 468],
	# Bedroom side: bed, nightstand, bookcase, ivy ladder, plant stool, lamp, sofa.
	[197, 228, 368, 336],
	[420, 228, 512, 285],
	[165, 298, 312, 530],
	[318, 368, 372, 562],
	[158, 470, 224, 590],
	[172, 602, 216, 742],
	[230, 654, 454, 744],
	# Kitchen side: stove, log pile, cooker, counter, plant.
	[652, 228, 756, 285],
	[606, 262, 704, 356],
	[808, 228, 914, 290],
	[918, 228, 1090, 292],
	[1116, 228, 1186, 268],
	# Dining table and chairs.
	[858, 318, 1058, 520],
	[766, 335, 836, 455],
	[1076, 335, 1146, 455],
	[962, 506, 1030, 582],
	# Plant shelf and floor lamp.
	[980, 640, 1104, 750],
	[1140, 602, 1192, 745],
]

## Things you can look at: rect = the furniture [x0, y0, x1, y1] in ref units.
const HOTSPOTS := [
	{"name": "the bed", "rect": [195, 205, 368, 336],
		"text": "Maya's quilt is stitched from scraps of old cloth and fishing net. Nothing gets thrown away on this island."},
	{"name": "the bookcase", "rect": [163, 298, 312, 528],
		"text": "Field notes: \"A single plastic bottle can last hundreds of years in nature. Pick them up before the tide takes them out to sea.\""},
	{"name": "the wood stove", "rect": [650, 150, 758, 285],
		"text": "It burns only driftwood and fallen branches, never living trees. Warm for the family, kind to the forest."},
	{"name": "the kitchen", "rect": [808, 150, 1090, 292],
		"text": "A kettle of boiled rainwater. Maya filters and boils every drop before anyone drinks it."},
	{"name": "the dining table", "rect": [858, 318, 1058, 520],
		"text": "An open journal reads: \"Reduce. Reuse. Recycle. In that order.\" The first step is the best one."},
	{"name": "the plant shelf", "rect": [980, 640, 1104, 750],
		"text": "Herbs grown from seeds Maya saved. Plants clean the air and feed the pollinators."},
	{"name": "the sofa", "rect": [228, 652, 454, 744],
		"text": "A cosy sofa made from reclaimed wood. You rest for a moment and feel ready for more beach cleanups."},
]

## Warm light spots drawn on top of the artwork: [ref x, ref y, radius px, strength].
const GLOWS_REF := [
	[704, 232, 150.0, 1.0],   # wood stove fire
	[468, 175, 95.0, 0.8],    # nightstand lamp
	[190, 625, 90.0, 0.7],    # left floor lamp
	[1163, 625, 90.0, 0.7],   # right floor lamp
]

var _player: CharacterBody2D
var _maya: Node2D
var _inside := false
var _busy := false              # true during the fade between outside and inside
var _enter_cooldown := 0.0
var _time := 0.0
var _door_open := 0.0
var _entering := false          # door is swinging open before the fade
var _prompt: Label
var _interior: Node2D
var _marks: Node2D
var _fade: ColorRect
var _glow_sprites: Array[Sprite2D] = []

# Saved player / camera state so leaving the house restores everything.
var _player_camera: Camera2D
var _saved_camera_limits := Vector4(0, 0, 2304, 1664)
var _saved_camera_smoothing := true
var _saved_camera_zoom := Vector2(1.3, 1.3)
var _saved_camera_scale := Vector2(0.25, 0.25)
var _saved_player_scale := Vector2(4, 4)
var _player_shape_node: CollisionShape2D
var _orig_shape: Shape2D
var _orig_shape_pos := Vector2.ZERO
var _feet_shape: RectangleShape2D
var _feet_mode := false

# Indoor UI.
var _ui: CanvasLayer
var _indoor_prompt_panel: PanelContainer
var _indoor_prompt: Label
var _note_panel: PanelContainer
var _note_title: Label
var _note_body: Label
var _note_tween: Tween

# Maya cooking.
var _maya_sprite: Sprite2D
var _steam: CPUParticles2D
var _last_safe_feet := Vector2.ZERO
var _has_safe_feet := false


func _ready() -> void:
	z_as_relative = false
	z_index = 0
	add_to_group("maya_home")   # the tidal wave's arrow points here
	add_to_group("shade")       # the house also shades you from the heat wave
	set_meta("shade_radius", 230.0)
	_player = get_tree().get_first_node_in_group("player") as CharacterBody2D
	if _player:
		_player_camera = _player.get_node_or_null("Camera2D") as Camera2D
	_maya = get_tree().get_first_node_in_group("maya") as Node2D
	if _maya == null:
		_maya = get_parent().get_node_or_null("Maya") as Node2D

	# Solid exterior: roof, back wall and two wall blocks that leave a real
	# doorway (x = -38 .. 38) so the player can walk through the lobby to the door.
	var house_collision := StaticBody2D.new()
	house_collision.name = "HouseExteriorCollision"
	house_collision.collision_layer = 1
	house_collision.collision_mask = 0
	for r in HOUSE_SOLIDS:
		_add_house_wall(house_collision, r.get_center(), r.size)
	add_child(house_collision)

	_prompt = Label.new()
	_prompt.position = Vector2(-150, 92)
	_prompt.add_theme_font_size_override("font_size", 16)
	_prompt.add_theme_color_override("font_color", Color("#fff4c8"))
	_prompt.add_theme_color_override("font_outline_color", Color("#493126"))
	_prompt.add_theme_constant_override("outline_size", 5)
	_prompt.visible = false
	add_child(_prompt)

	_build_interior()
	_build_ui()

	# Maya lives inside the house. Hide her on the island; reveal her indoors.
	if _maya:
		_maya.visible = false
		if _maya is CollisionObject2D:
			_maya.collision_layer = 0
			_maya.collision_mask = 0
		var maya_prompt := _maya.get_node_or_null("InteractPrompt")
		if maya_prompt is CanvasItem:
			maya_prompt.visible = false
		_maya_sprite = _maya.get_node_or_null("Sprite2D") as Sprite2D
		# Indoors you can walk straight through Maya (she is busy cooking), so her
		# solid body is switched off. Press E next to her to talk.
		var solid_body := _maya.get_node_or_null("SolidBody") as CollisionObject2D
		if solid_body:
			solid_body.collision_layer = 0
			solid_body.collision_mask = 0
		if _maya.has_method("set_activity"):
			_maya.set("home_activity", "cook")
			_maya.call("face_direction", "up")
			_maya.call("set_activity", "cook")
		_place_maya_feet(_art_point(MAYA_COOK_REF))

	get_viewport().size_changed.connect(_on_viewport_resized)
	queue_redraw()


# --- Building the room ---------------------------------------------------------------

func _build_interior() -> void:
	_interior = Node2D.new()
	_interior.name = "MayaHouseInterior"
	_interior.position = INTERIOR_OFFSET
	_interior.visible = false
	add_child(_interior)

	var backdrop := Polygon2D.new()
	backdrop.name = "RoomBackdrop"
	backdrop.color = BACKDROP_COLOR
	backdrop.polygon = PackedVector2Array([
		Vector2(-5000, -5000), Vector2(5000, -5000), Vector2(5000, 5000), Vector2(-5000, 5000)])
	backdrop.z_index = -2
	_interior.add_child(backdrop)

	var art := Sprite2D.new()
	art.name = "MayaHouseInteriorArtwork"
	var path: String = ART_PATH if ResourceLoader.exists(ART_PATH) else ART_FALLBACK_PATH
	art.texture = load(path)
	art.centered = true
	art.scale = Vector2.ONE * ROOM_SCALE
	art.z_index = -1
	_interior.add_child(art)

	# Flickering warm light on the stove and lamps.
	var glow_tex := _make_glow_texture()
	var add_mat := CanvasItemMaterial.new()
	add_mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	for g in GLOWS_REF:
		var s := Sprite2D.new()
		s.texture = glow_tex
		s.material = add_mat
		s.position = _art_point(Vector2(g[0], g[1]))
		s.scale = Vector2.ONE * (float(g[2]) * 2.0 / 256.0)
		s.set_meta("strength", float(g[3]))
		s.set_meta("phase", randf() * TAU)
		_interior.add_child(s)
		_glow_sprites.append(s)

	# Real collision for walls and furniture (it stops the player's FEET).
	var solid := StaticBody2D.new()
	solid.name = "InteriorCollision"
	solid.collision_layer = 1
	solid.collision_mask = 0
	for r in SOLIDS_REF:
		var a: Vector2 = _art_point(Vector2(r[0], r[1]))
		var b: Vector2 = _art_point(Vector2(r[2], r[3]))
		var node := CollisionShape2D.new()
		var rect := RectangleShape2D.new()
		rect.size = (b - a).abs()
		node.shape = rect
		node.position = (a + b) * 0.5
		solid.add_child(node)
	_interior.add_child(solid)

	# Steam curling up from the pot / kettle Maya is cooking.
	_steam = CPUParticles2D.new()
	_steam.name = "KettleSteam"
	_steam.texture = glow_tex
	_steam.position = _art_point(STEAM_REF)
	_steam.amount = 14
	_steam.lifetime = 2.2
	_steam.direction = Vector2(0.15, -1.0)
	_steam.spread = 18.0
	_steam.gravity = Vector2.ZERO
	_steam.initial_velocity_min = 16.0
	_steam.initial_velocity_max = 28.0
	_steam.scale_amount_min = 0.06
	_steam.scale_amount_max = 0.12
	_steam.color = Color(1.0, 1.0, 1.0, 0.55)
	var steam_fade := Gradient.new()
	steam_fade.set_color(0, Color(1, 1, 1, 0.0))
	steam_fade.add_point(0.25, Color(1, 1, 1, 0.6))
	steam_fade.set_color(steam_fade.get_point_count() - 1, Color(1, 1, 1, 0.0))
	_steam.color_ramp = steam_fade
	_steam.z_index = 3
	_steam.emitting = true
	_interior.add_child(_steam)

	# Little bobbing sparkles over things you can look at.
	_marks = Node2D.new()
	_marks.name = "HotspotMarks"
	_marks.z_index = 5
	_marks.draw.connect(_draw_marks)
	_interior.add_child(_marks)


func _make_glow_texture() -> GradientTexture2D:
	var grad := Gradient.new()
	grad.set_color(0, Color(1.0, 0.72, 0.35, 0.5))
	grad.set_color(1, Color(1.0, 0.72, 0.35, 0.0))
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = 256
	tex.height = 256
	return tex


func _build_ui() -> void:
	_ui = CanvasLayer.new()
	_ui.layer = 15
	add_child(_ui)

	# Bottom hint panel.
	_indoor_prompt_panel = PanelContainer.new()
	_indoor_prompt_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_indoor_prompt_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_indoor_prompt_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_indoor_prompt_panel.offset_top = -56.0
	_indoor_prompt_panel.offset_bottom = -56.0
	_indoor_prompt_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_indoor_prompt_panel.add_theme_stylebox_override("panel", _panel_style())
	_indoor_prompt = Label.new()
	_indoor_prompt.add_theme_font_size_override("font_size", 24)
	_indoor_prompt.add_theme_color_override("font_color", Color("#fff4d6"))
	_indoor_prompt.add_theme_color_override("font_outline_color", Color("#493126"))
	_indoor_prompt.add_theme_constant_override("outline_size", 5)
	_indoor_prompt.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_indoor_prompt_panel.add_child(_indoor_prompt)
	_indoor_prompt_panel.visible = false
	_ui.add_child(_indoor_prompt_panel)

	# Top note panel for the things you inspect.
	_note_panel = PanelContainer.new()
	_note_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_note_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_note_panel.offset_top = 36.0
	_note_panel.custom_minimum_size = Vector2(640, 0)
	_note_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_note_panel.add_theme_stylebox_override("panel", _panel_style())
	var box := VBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_note_title = Label.new()
	_note_title.add_theme_font_size_override("font_size", 22)
	_note_title.add_theme_color_override("font_color", Color("#ffd98a"))
	_note_title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_note_body = Label.new()
	_note_body.add_theme_font_size_override("font_size", 20)
	_note_body.add_theme_color_override("font_color", Color("#fff4d6"))
	_note_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_note_body.custom_minimum_size = Vector2(600, 0)
	_note_body.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(_note_title)
	box.add_child(_note_body)
	_note_panel.add_child(box)
	_note_panel.visible = false
	_ui.add_child(_note_panel)

	# Black fade used when walking through the door.
	var fade_layer := CanvasLayer.new()
	fade_layer.layer = 60
	add_child(fade_layer)
	_fade = ColorRect.new()
	_fade.color = Color(0, 0, 0, 0)
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fade_layer.add_child(_fade)


func _panel_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#30251f", 0.92)
	style.border_color = Color("#e5bd76")
	style.set_border_width_all(2)
	style.set_corner_radius_all(12)
	style.content_margin_left = 22.0
	style.content_margin_right = 22.0
	style.content_margin_top = 10.0
	style.content_margin_bottom = 10.0
	return style


func _add_house_wall(parent: StaticBody2D, wall_position: Vector2, wall_size: Vector2) -> void:
	var shape_node := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = wall_size
	shape_node.shape = shape
	shape_node.position = wall_position
	parent.add_child(shape_node)


# --- Coordinate helpers --------------------------------------------------------------

## Ref coordinates (1344x896 preview) -> position local to the interior.
func _art_point(ref: Vector2) -> Vector2:
	return (ref * REF_TO_ART - ART_SIZE * 0.5) * ROOM_SCALE


## Position local to the interior -> ref coordinates.
func _to_ref(local_pos: Vector2) -> Vector2:
	return (local_pos / ROOM_SCALE + ART_SIZE * 0.5) / REF_TO_ART


## Where the player's shoes touch the ground, in world space.
func _feet_pos() -> Vector2:
	return _player.global_position + FEET_LOCAL * _player.scale


func _feet_ref() -> Vector2:
	return _to_ref(_interior.to_local(_feet_pos()))


func _place_player_feet_at(world_pos: Vector2) -> void:
	_player.global_position = world_pos - FEET_LOCAL * _player.scale
	_player.velocity = Vector2.ZERO


func _place_maya_feet(local_pos: Vector2) -> void:
	if _maya:
		_maya.global_position = _interior.to_global(local_pos) - Vector2(0, MAYA_FEET_Y)


func _maya_feet() -> Vector2:
	return _maya.global_position + Vector2(0, MAYA_FEET_Y)


func _room_rect_world() -> Rect2:
	var a: Vector2 = _interior.to_global(_art_point(ROOM_REF.position))
	var b: Vector2 = _interior.to_global(_art_point(ROOM_REF.end))
	return Rect2(a, b - a)


## Swap the player's collision box between the original torso box and a small
## box under the shoes, so the CHARACTER'S FEET collide with the world.
func _set_feet_collision(on: bool) -> void:
	if _player == null:
		return
	if _player_shape_node == null:
		_player_shape_node = _player.get_node_or_null("CollisionShape2D") as CollisionShape2D
		if _player_shape_node == null:
			return
		_orig_shape = _player_shape_node.shape
		_orig_shape_pos = _player_shape_node.position
		_feet_shape = RectangleShape2D.new()
		_feet_shape.size = FEET_SIZE
	if on == _feet_mode:
		return
	_feet_mode = on
	_player_shape_node.shape = _feet_shape if on else _orig_shape
	_player_shape_node.position = FEET_LOCAL if on else _orig_shape_pos


# --- Maya ----------------------------------------------------------------------------

func _near_maya() -> bool:
	return _inside and _player != null and _maya != null \
		and _feet_pos().distance_to(_maya_feet()) <= TALK_DISTANCE


func _maya_is_chatting() -> bool:
	return _maya != null and (bool(_maya.get("_chatting")) or bool(_maya.get("_turning")))


## Maya stays at her stove, cooking. Only the draw order changes: whoever is
## lower on the screen is drawn in front, so you can walk past (or through) her
## and still look right.
func _update_maya(_delta: float) -> void:
	if _maya == null or _player == null:
		return
	var maya_in_front: bool = _maya_feet().y > _feet_pos().y
	_maya.z_index = 2 if maya_in_front else 0
	_player.z_index = INDOOR_PLAYER_Z


# --- Hotspots ------------------------------------------------------------------------

## Index of the furniture the player is standing close to, or -1.
func _active_hotspot() -> int:
	if not _inside or _player == null:
		return -1
	var f: Vector2 = _feet_ref()
	var best := -1
	var best_dist := INF
	for i in HOTSPOTS.size():
		var r: Array = HOTSPOTS[i]["rect"]
		var area := Rect2(r[0] - HOTSPOT_REACH, r[1] - HOTSPOT_REACH,
			(r[2] - r[0]) + HOTSPOT_REACH * 2.0, (r[3] - r[1]) + HOTSPOT_REACH * 2.0)
		if area.has_point(f):
			var center := Vector2((r[0] + r[2]) * 0.5, (r[1] + r[3]) * 0.5)
			var d: float = f.distance_to(center)
			if d < best_dist:
				best_dist = d
				best = i
	return best


func _use_hotspot(index: int) -> void:
	var h: Dictionary = HOTSPOTS[index]
	_note_title.text = "Look at %s" % String(h["name"])
	_note_body.text = String(h["text"])
	_note_panel.visible = true
	_note_panel.modulate.a = 0.0
	if _note_tween != null and _note_tween.is_valid():
		_note_tween.kill()
	_note_tween = create_tween()
	_note_tween.tween_property(_note_panel, "modulate:a", 1.0, 0.15)
	_note_tween.tween_interval(5.0)
	_note_tween.tween_property(_note_panel, "modulate:a", 0.0, 0.4)
	_note_tween.tween_callback(func() -> void: _note_panel.visible = false)


func _draw_marks() -> void:
	for h in HOTSPOTS:
		var r: Array = h["rect"]
		var top: Vector2 = _art_point(Vector2((r[0] + r[2]) * 0.5, minf(float(r[1]) + 30.0, float(r[3]) - 10.0)))
		var bob: float = sin(_time * 3.0 + top.x * 0.01) * 4.0
		var c := top + Vector2(0, -6.0 + bob)
		var pts := PackedVector2Array([c + Vector2(0, -9), c + Vector2(6, 0), c + Vector2(0, 9), c + Vector2(-6, 0)])
		_marks.draw_colored_polygon(pts, Color("#ffe9a0", 0.9))
		_marks.draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), Color("#7a5a2a"), 1.5)


# --- Input -----------------------------------------------------------------------------

func _unhandled_input(event: InputEvent) -> void:
	if _busy or _entering or _player == null or not event.is_action_pressed("interact"):
		return
	if _inside:
		if _maya_is_chatting():
			return
		var handled := false
		if _near_maya():
			if _maya != null and _maya.has_method("start_conversation"):
				_maya.call("start_conversation", _player)
			handled = true
		else:
			var h := _active_hotspot()
			if h >= 0:
				_use_hotspot(h)
				handled = true
			elif EXIT_E_REF.has_point(_feet_ref()):
				_begin_exit()
				handled = true
		if handled:
			get_viewport().set_input_as_handled()
	elif _enter_cooldown <= 0.0 and _feet_pos().distance_to(global_position + Vector2(0, 50)) <= ENTRY_DISTANCE:
		_begin_enter()
		get_viewport().set_input_as_handled()


# --- Enter / leave ----------------------------------------------------------------------

func _begin_enter() -> void:
	if _busy or _entering or _player == null:
		return
	_entering = true
	_prompt.visible = false
	_player.velocity = Vector2.ZERO
	_player.set_physics_process(false)
	# Let the door swing fully open, then walk in.
	await get_tree().create_timer(0.45).timeout
	_entering = false
	_player.set_physics_process(true)
	_transition(_do_enter)


func _begin_exit() -> void:
	_transition(_do_exit)


## Fade to black, run the switch, fade back in. The player is frozen meanwhile.
func _transition(action: Callable) -> void:
	if _busy or _player == null:
		return
	_busy = true
	_player.velocity = Vector2.ZERO
	_player.set_physics_process(false)
	var tw := create_tween()
	tw.tween_property(_fade, "color:a", 1.0, 0.2)
	tw.tween_callback(action)
	tw.tween_property(_fade, "color:a", 0.0, 0.25)
	tw.tween_callback(_finish_transition)


func _finish_transition() -> void:
	_busy = false
	if _player:
		_player.set_physics_process(true)


func _do_enter() -> void:
	_inside = true
	_prompt.visible = false
	_player.indoors = true   # the water hazard ignores the player while indoors
	_player.speed_scale = INDOOR_SPEED_SCALE
	_saved_player_scale = _player.scale
	_player.scale = Vector2.ONE * INDOOR_PLAYER_SCALE
	_set_feet_collision(true)
	_player.z_index = INDOOR_PLAYER_Z
	_has_safe_feet = false
	if _player_camera == null:
		_player_camera = _player.get_node_or_null("Camera2D") as Camera2D
	if _player_camera:
		_saved_camera_limits = Vector4(_player_camera.limit_left, _player_camera.limit_top,
			_player_camera.limit_right, _player_camera.limit_bottom)
		_saved_camera_smoothing = _player_camera.position_smoothing_enabled
		_saved_camera_zoom = _player_camera.zoom
		_saved_camera_scale = _player_camera.scale
		# Keep the camera's overall scale at 1x even though the player scale changed.
		_player_camera.scale = _saved_camera_scale * (_saved_player_scale.x / INDOOR_PLAYER_SCALE)
	_interior.visible = true
	_place_player_feet_at(_interior.to_global(_art_point(SPAWN_REF)))
	_frame_room_camera()
	if _player_camera:
		_player_camera.reset_smoothing()
	if _maya:
		_maya.visible = true
		var maya_prompt := _maya.get_node_or_null("InteractPrompt")
		if maya_prompt is CanvasItem:
			maya_prompt.visible = false
		_place_maya_feet(_art_point(MAYA_COOK_REF))
		if _maya.has_method("set_activity"):
			_maya.call("face_direction", "up")
			_maya.call("set_activity", "cook")
	_update_indoor_prompt()
	_indoor_prompt_panel.visible = true
	queue_redraw()


func _do_exit() -> void:
	_inside = false
	_indoor_prompt_panel.visible = false
	_note_panel.visible = false
	_player.indoors = false
	_player.speed_scale = 1.0
	_player.z_index = 0
	_player.scale = _saved_player_scale
	_place_player_feet_at(global_position + Vector2(0, 84))
	if _player_camera:
		_player_camera.limit_left = int(_saved_camera_limits.x)
		_player_camera.limit_top = int(_saved_camera_limits.y)
		_player_camera.limit_right = int(_saved_camera_limits.z)
		_player_camera.limit_bottom = int(_saved_camera_limits.w)
		_player_camera.position_smoothing_enabled = _saved_camera_smoothing
		_player_camera.zoom = _saved_camera_zoom
		_player_camera.scale = _saved_camera_scale
		_player_camera.reset_smoothing()
	if _maya:
		_maya.visible = false
	_interior.visible = false
	_enter_cooldown = 0.8
	_door_open = 1.0
	queue_redraw()


## Fit the room to the window: zoom so the whole cottage nearly fills the
## screen, follow the player, and stay inside the room. Re-run on resize.
func _frame_room_camera() -> void:
	if _player_camera == null or _interior == null:
		return
	var view: Vector2 = get_viewport().get_visible_rect().size
	var room: Rect2 = _room_rect_world()
	var fit: float = minf(view.x / room.size.x, view.y / room.size.y)
	var z: float = clampf(fit * CAMERA_CLOSENESS, 0.5, 1.8)
	_player_camera.zoom = Vector2.ONE * z
	var half: Vector2 = view / (2.0 * z)
	var c: Vector2 = room.get_center()
	var hx: float = maxf(room.size.x * 0.5, half.x)
	var hy: float = maxf(room.size.y * 0.5, half.y)
	_player_camera.limit_left = int(floor(c.x - hx))
	_player_camera.limit_right = int(ceil(c.x + hx))
	_player_camera.limit_top = int(floor(c.y - hy))
	_player_camera.limit_bottom = int(ceil(c.y + hy))
	# No smoothing: with the whole room on screen the camera never moves, so
	# nothing shimmers or jitters while you walk on the floorboards.
	_player_camera.position_smoothing_enabled = false


func _on_viewport_resized() -> void:
	if _inside:
		_frame_room_camera()


# --- Per-frame ---------------------------------------------------------------------------

func _process(delta: float) -> void:
	_time += delta
	if _player == null:
		_player = get_tree().get_first_node_in_group("player") as CharacterBody2D
		return
	if _player_camera == null:
		_player_camera = _player.get_node_or_null("Camera2D") as Camera2D
	_enter_cooldown = maxf(_enter_cooldown - delta, 0.0)
	# Depth: indoors the room sits behind the player; outdoors the cabin is drawn
	# behind you when you stand in front of it and in front of you when you are behind it.
	if _inside:
		z_index = 0
	else:
		z_index = -5 if _feet_pos().y > global_position.y + 30.0 else 1

	if _inside:
		_update_indoor(delta)
		return

	# Outside: feet-sized collision near the house so walking into the doorway
	# lines up with what you see; the door swings open as you approach.
	var door_point: Vector2 = global_position + Vector2(0, 50)
	var dist: float = _feet_pos().distance_to(door_point)
	_set_feet_collision(dist < 320.0 and not _busy)
	var target: float = 1.0 if (dist < DOOR_OPEN_DISTANCE or _entering) else 0.0
	_door_open = move_toward(_door_open, target, delta * 5.0)
	var near_door: bool = dist <= ENTRY_DISTANCE
	_prompt.visible = near_door
	_prompt.text = "Walk into the doorway to go inside  (or press E)"
	if dist < 900.0:
		queue_redraw()   # chimney smoke + window glow animate
	# Walking up into the doorway enters the house.
	if not _busy and not _entering and _enter_cooldown <= 0.0 and Input.is_action_pressed("up"):
		var f: Vector2 = _feet_pos() - global_position
		if DOOR_TRIGGER.has_point(f):
			_begin_enter()


func _update_indoor(delta: float) -> void:
	# Flicker the lamplight and stove fire.
	for s in _glow_sprites:
		var k: float = float(s.get_meta("strength"))
		var ph: float = float(s.get_meta("phase"))
		var flick: float = 0.85 + 0.15 * sin(_time * 7.0 + ph) + 0.06 * sin(_time * 17.0 + ph * 2.0)
		s.modulate.a = clampf(k * flick, 0.0, 1.0)
	_marks.queue_redraw()
	_update_maya(delta)
	_update_indoor_prompt()
	if _busy:
		return
	# Walking down through the front door leaves the house.
	var f: Vector2 = _feet_ref()
	if EXIT_TRIGGER_REF.has_point(f) and Input.is_action_pressed("down"):
		_begin_exit()
		return
	# Safety net: if the player ever ends up outside the room, put them at the door.
	if not ROOM_REF.grow(60.0).has_point(f):
		_place_player_feet_at(_interior.to_global(_art_point(SPAWN_REF)))
		return
	# If the feet ever end up inside a wall / furniture box (a physics hiccup),
	# step back to the last place that was clear instead of getting stuck.
	if _feet_in_solid(f):
		if _has_safe_feet:
			_place_player_feet_at(_last_safe_feet)
		else:
			_place_player_feet_at(_interior.to_global(_art_point(SPAWN_REF)))
	else:
		_last_safe_feet = _feet_pos()
		_has_safe_feet = true


## True when a point (ref units) sits well inside one of the solid boxes.
func _feet_in_solid(f: Vector2) -> bool:
	for r in SOLIDS_REF:
		var box := Rect2(r[0], r[1], r[2] - r[0], r[3] - r[1]).grow(-3.0)
		if box.has_point(f):
			return true
	return false


func _update_indoor_prompt() -> void:
	if _indoor_prompt == null:
		return
	if _maya_is_chatting():
		_indoor_prompt.text = "Chatting with Maya..."
		return
	var h := _active_hotspot()
	if _near_maya():
		_indoor_prompt.text = "Press E to talk to Maya"
	elif h >= 0:
		_indoor_prompt.text = "Press E to look at %s" % String(HOTSPOTS[h]["name"])
	elif EXIT_E_REF.has_point(_feet_ref()):
		_indoor_prompt.text = "Walk down through the door to go outside"
	else:
		_indoor_prompt.text = "Explore the cottage  \u2022  Walk up to Maya to talk  \u2022  The front door is at the bottom"


# --- Drawing the outside of the cottage ----------------------------------------------------

func _draw() -> void:
	# Maya's cottage: a storybook stone-and-timber home with terracotta roof,
	# paved forecourt, timber fence, crates and a barrel.
	draw_set_transform(Vector2(0, 38), 0.0, Vector2(2.15, 0.52))
	draw_circle(Vector2.ZERO, 86.0, Color(0, 0, 0, 0.22))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	# Cream cobblestone forecourt (the lobby you walk across to the door).
	draw_rect(Rect2(Vector2(-75, 45), Vector2(150, 44)), Color("#bca17d"))
	draw_rect(Rect2(Vector2(-75, 45), Vector2(150, 44)), Color("#82664c"), false, 4.0)
	for yy in [60.0, 75.0]:
		draw_line(Vector2(-71, yy), Vector2(71, yy), Color("#d7c09b"), 2.0)
	for xx in range(-54, 75, 36):
		draw_line(Vector2(float(xx), 47), Vector2(float(xx), 87), Color("#d7c09b"), 2.0)
	# Maya's cabin: the wooden house with the red tiled roof (sprite).
	draw_texture_rect(HOUSE_TEXTURE, Rect2(HOUSE_DRAW_POS, HOUSE_TEXTURE.get_size() * HOUSE_DRAW_SCALE), false)
	# Front doorway: warm lit room behind, door leaf swings open as you approach.
	draw_rect(Rect2(Vector2(-22, -6), Vector2(44, 63)), Color("#6d432d"))
	var open_amt: float = ease(_door_open, -1.6) if _door_open > 0.0 else 0.0
	draw_rect(Rect2(Vector2(-17, -1), Vector2(34, 56)), Color("#2b1a10"))
	if open_amt > 0.01:
		draw_rect(Rect2(Vector2(-17, 30), Vector2(34, 25)), Color(0.95, 0.7, 0.35, 0.85 * open_amt))
		draw_rect(Rect2(Vector2(-17, -1), Vector2(34, 56)), Color(1.0, 0.8, 0.45, 0.18 * open_amt))
	var leaf_w: float = 32.0 * (1.0 - 0.8 * open_amt)
	draw_rect(Rect2(Vector2(-16, 0), Vector2(leaf_w, 55)), Color("#4f7a3a"))
	draw_line(Vector2(-16 + leaf_w * 0.3, 8), Vector2(-16 + leaf_w * 0.3, 48), Color("#7fae5a"), 2.0)
	draw_circle(Vector2(-16 + leaf_w - 5.0, 29), 3.0, Color("#f4d98b"))
	draw_rect(Rect2(Vector2(-32, 54), Vector2(64, 12)), Color("#dfcfad"))
	draw_rect(Rect2(Vector2(-40, 64), Vector2(80, 18)), Color("#805036"))
	draw_rect(Rect2(Vector2(-40, 64), Vector2(80, 18)), Color("#ead6a7"), false, 2.0)
	draw_string(ThemeDB.fallback_font, Vector2(-32, 77), "MAYA'S HOME", HORIZONTAL_ALIGNMENT_LEFT, 64, 9, Color("#4b3827"))
