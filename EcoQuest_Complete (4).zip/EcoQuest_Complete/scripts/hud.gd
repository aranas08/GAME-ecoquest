extends CanvasLayer
## hud.gd
## Connects to the Player (stats) and LevelRoot (quest/warning events)
## and reflects them on screen.

@onready var healthbar: Node2D = %Healthbar
@onready var plastic_label: Label = %PlasticLabel
@onready var wood_label: Label = %WoodLabel
@onready var timer_label: Label = %TimerLabel
@onready var banner_panel: Panel = %BannerPanel
@onready var banner_label: Label = %BannerLabel
@onready var dialogue_label: Label = %DialogueLabel
@onready var island_label: Label = %IslandLabel
@onready var name_label: Label = %NameLabel

var advance_label: Label
var quest_button: Button
var _progress_text: String = ""


func _ready() -> void:
	banner_panel.visible = false
	dialogue_label.visible = false
	name_label.text = GameBoot.player_name
	refresh_island_progress()

	# Persistent "how do I leave?" prompt, shown once the island is stabilized.
	advance_label = Label.new()
	advance_label.text = "Island stabilized!  Press N to board the boat and sail to the next island"
	advance_label.visible = false
	advance_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	advance_label.anchor_left = 0.0
	advance_label.anchor_right = 1.0
	advance_label.anchor_top = 1.0
	advance_label.anchor_bottom = 1.0
	advance_label.offset_left = 20.0
	advance_label.offset_right = -20.0
	advance_label.offset_top = -92.0
	advance_label.offset_bottom = -56.0
	advance_label.add_theme_font_size_override("font_size", 24)
	advance_label.add_theme_color_override("font_color", Color(1.0, 0.86, 0.35))
	advance_label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	advance_label.add_theme_constant_override("outline_size", 6)
	add_child(advance_label)

	# Always-visible shortcut so players can open the quest log without
	# needing to remember the keyboard shortcut.
	quest_button = Button.new()
	quest_button.text = "📜 QUEST LOG  [Q]"
	quest_button.tooltip_text = "View active and completed quests"
	quest_button.anchor_left = 1.0
	quest_button.anchor_right = 1.0
	quest_button.anchor_top = 0.0
	quest_button.anchor_bottom = 0.0
	quest_button.offset_left = -232.0
	quest_button.offset_right = -18.0
	quest_button.offset_top = 92.0
	quest_button.offset_bottom = 136.0
	quest_button.add_theme_font_size_override("font_size", 18)
	quest_button.add_theme_color_override("font_color", Color(1.0, 0.96, 0.86))
	quest_button.add_theme_color_override("font_hover_color", Color(1.0, 0.82, 0.35))
	var quest_style := StyleBoxFlat.new()
	quest_style.bg_color = Color(0.36, 0.20, 0.10, 0.96)
	quest_style.border_color = Color(0.16, 0.08, 0.03, 1.0)
	quest_style.set_border_width_all(3)
	quest_style.set_corner_radius_all(8)
	quest_style.content_margin_left = 12.0
	quest_style.content_margin_right = 12.0
	quest_style.content_margin_top = 7.0
	quest_style.content_margin_bottom = 7.0
	quest_button.add_theme_stylebox_override("normal", quest_style)
	var quest_hover := quest_style.duplicate() as StyleBoxFlat
	quest_hover.bg_color = Color(0.49, 0.29, 0.13, 1.0)
	quest_button.add_theme_stylebox_override("hover", quest_hover)
	quest_button.pressed.connect(_open_quest_log)
	add_child(quest_button)


func connect_to_player(player: Node) -> void:
	player.hp_changed.connect(_on_hp_changed)
	player.plastic_changed.connect(_on_plastic_changed)
	player.wood_changed.connect(_on_wood_changed)
	player.item_crafted.connect(_on_item_crafted)
	# Sync immediately in case signals already fired before HUD connected.
	_on_hp_changed(player.hp, player.max_hp)
	_on_plastic_changed(player.plastic_count)
	_on_wood_changed(player.wood_count)


func connect_to_level(level: Node) -> void:
	level.banner_shown.connect(_on_banner_shown)
	level.banner_hidden.connect(_on_banner_hidden)
	level.dialogue_shown.connect(_on_dialogue_shown)
	level.timer_updated.connect(_on_timer_updated)
	level.challenge_progress.connect(_on_challenge_progress)


func _on_hp_changed(hp: int, max_hp: int) -> void:
	healthbar.set_hp(hp, max_hp)


func _on_plastic_changed(count: int) -> void:
	plastic_label.text = "Plastic: %d" % count


func _on_wood_changed(count: int) -> void:
	wood_label.text = "Wood: %d" % count


func _on_item_crafted(_recipe_id: String, recipe_name: String) -> void:
	_on_dialogue_shown("Crafted: %s" % recipe_name)


func _on_banner_shown(text: String) -> void:
	banner_label.text = text
	banner_panel.visible = true


func _on_banner_hidden() -> void:
	banner_panel.visible = false


func _on_dialogue_shown(text: String) -> void:
	dialogue_label.text = text
	dialogue_label.visible = text != ""


func _on_challenge_progress(collected: int, required: int) -> void:
	_progress_text = "%d/%d" % [mini(collected, required), required]


func _on_timer_updated(seconds_left: float) -> void:
	if seconds_left < 0:
		timer_label.text = ""
		_progress_text = ""
	elif _progress_text != "":
		timer_label.text = "%s   Time Left: %d s" % [_progress_text, ceili(seconds_left)]
	else:
		timer_label.text = "Time Left: %d s" % ceili(seconds_left)


## "Plastic Beach - Hazards survived 1/2"
func refresh_island_progress() -> void:
	var island: Dictionary = IslandManager.current_island()
	island_label.text = "%s - Hazards survived %d/%d" % [
		island.name,
		mini(IslandManager.quests_completed_this_island, int(island.quests_to_unlock)),
		int(island.quests_to_unlock),
	]


func set_advance_hint(show_hint: bool) -> void:
	if advance_label:
		advance_label.visible = show_hint


func _open_quest_log() -> void:
	var quest_log := get_tree().current_scene.get_node_or_null("QuestLog")
	if quest_log and quest_log.has_method("open_log"):
		quest_log.open_log()
