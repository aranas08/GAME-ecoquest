extends Node
## game_boot.gd (Autoload: GameBoot)
## Holds onto the PackedScene that loading_screen.gd loaded on a background
## thread, so the main menu can start the game instantly instead of loading
## main.tscn a second time when the player presses "New Game".

const GAME_SCENE_PATH := "res://main.tscn"

## Set by loading_screen.gd once the threaded load finishes.
var game_scene: PackedScene = null

## True after the player has started a run at least once this session, so the
## main menu knows whether to offer "Continue".
var run_in_progress: bool = false

## The survivor's name (design doc 5A: "Name: Player Customized Name").
## Chosen on the main menu when starting a new game.
const DEFAULT_PLAYER_NAME := "Survivor"
var player_name: String = DEFAULT_PLAYER_NAME


## Cleans up whatever the player typed into the name box: collapses runs of
## whitespace, trims, caps the length, and falls back to the default if they
## left it blank or typed only spaces.
func set_player_name(raw: String) -> String:
	var cleaned: String = " ".join(raw.strip_edges().split(" ", false))
	if cleaned.length() > 16:
		cleaned = cleaned.substr(0, 16).strip_edges()
	player_name = cleaned if cleaned != "" else DEFAULT_PLAYER_NAME
	return player_name


## Starts (or restarts) a run from the beginning: island 1, no quests, no
## carried-over inventory.
func start_new_game() -> Error:
	SaveManager.clear_save()
	QuestManager.reset()
	IslandManager.reset()
	run_in_progress = true
	return _change_to_game()


## Returns to the run already in progress, keeping the current island and the
## player state saved by IslandManager. If nothing has been played this
## session (a fresh launch of the game), pulls the last session's progress
## in from disk first.
func continue_game() -> Error:
	if not run_in_progress and SaveManager.has_save():
		SaveManager.load_into_autoloads()
	run_in_progress = true
	return _change_to_game()


## True when there's a run to offer "Continue" for — either one already
## played this session, or a save file left over from a previous session.
func has_continuable_run() -> bool:
	return run_in_progress or SaveManager.has_save()


func return_to_menu() -> Error:
	get_tree().paused = false
	return get_tree().change_scene_to_file("res://Scenes/main_menu.tscn")


func _change_to_game() -> Error:
	get_tree().paused = false
	if game_scene != null:
		return get_tree().change_scene_to_packed(game_scene)
	# Fallback: the preload failed or was freed, so load it the slow way.
	return get_tree().change_scene_to_file(GAME_SCENE_PATH)
