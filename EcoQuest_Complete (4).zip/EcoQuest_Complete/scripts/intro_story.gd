extends Control
## intro_story.gd
## A 60-second story clip that plays when the player presses "Begin" on the
## New Game panel, right before the game starts. It is built entirely from the
## game's own art and audio (loading_screen.jpg, maya.png, menu_theme.wav ...)
## and is assembled in code, so the .tscn is just an empty Control.
##
## Flow:  Main Menu > New Game > (name) > THIS CLIP > GameBoot.start_new_game()
## The Skip button (top-right), or Esc / Enter / Space, skips it at any time.

const BG_PATHS: Array = [
	"res://assets/images/UI/loading_screen.jpg",  # 0
	"res://assets/images/UI/mainmenu.jpg",  # 1
]
const MAYA_PATH := "res://assets/images/npc/maya.png"
## Original 60-second score for this clip (calm > storm > despair > hope > triumph).
const MUSIC_PATH := "res://assets/audio/intro_story.wav"
const MUSIC_FALLBACK_PATH := "res://assets/audio/menu_theme.wav"
const THUNDER_PATH := "res://assets/audio/fail_thud.wav"
const ALARM_PATH := "res://assets/audio/warning_alarm.wav"
const CHIME_PATH := "res://assets/audio/success_chime.wav"
const MENU_SCENE_PATH := "res://Scenes/main_menu.tscn"

## Total running time of the clip, in seconds.
const TOTAL_TIME := 60.0
const FADE_IN := 0.6
const FADE_OUT := 0.8
const SKIP_FADE := 0.35
const MUSIC_DB := -5.0

## When the lightning flashes (seconds) and when the hopeful chime plays.
const LIGHTNING_TIMES: Array = [28.0, 29.4]
const ALARM_TIME := 26.6
const CHIME_TIME := 52.6

## Maya slides in at MAYA_IN and leaves again at MAYA_OUT.
const MAYA_IN := 39.8
const MAYA_OUT := 52.2

## Shots: "bg" (0 = loading screen, 1 = main menu art), start/dur in seconds, zoom (z0 -> z1), camera centre in image
## coordinates 0..1 (c0 -> c1), colour tint (t0 -> t1) and the caption text.
## "{name}" is replaced with the player's survivor name.
## The camera stays in the lower part of the painting on purpose, so the logo
## only shows up in the final reveal.
var _shots: Array = []

var _elapsed: float = 0.0
var _finishing: bool = false
var _skipping: bool = false
var _skip_t: float = 0.0
var _lightning_fired: Array = []
var _chime_fired: bool = false
var _alarm_fired: bool = false

var _textures: Array = []
var _bg: TextureRect
var _maya: TextureRect
var _caption_bar: ColorRect
var _caption: Label
var _flash: ColorRect
var _fade: ColorRect
var _skip_button: Button
var _music: AudioStreamPlayer
var _sfx: AudioStreamPlayer
var _current_shot: int = -1


func _ready() -> void:
	clip_contents = true
	_build_shots()
	for path in BG_PATHS:
		var tex := load(path) as Texture2D
		if tex == null:
			push_error("intro_story.gd: could not load %s, skipping the intro." % path)
			call_deferred("_finish")
			return
		_textures.append(tex)

	# Black backdrop, so any gap while the camera moves is never see-through.
	var backdrop := _make_rect(Color(0, 0, 0, 1))
	add_child(backdrop)

	_bg = TextureRect.new()
	_bg.texture = _textures[0]
	_bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_bg.stretch_mode = TextureRect.STRETCH_SCALE
	_bg.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_bg)

	var maya_tex := load(MAYA_PATH) as Texture2D
	_maya = TextureRect.new()
	_maya.texture = maya_tex
	_maya.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_maya.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_maya.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	_maya.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_maya.modulate.a = 0.0
	_maya.visible = maya_tex != null
	add_child(_maya)

	_flash = _make_rect(Color(0.85, 0.92, 1.0, 1.0))
	_flash.modulate.a = 0.0
	add_child(_flash)

	_caption_bar = ColorRect.new()
	_caption_bar.color = Color(0, 0, 0, 0.5)
	_caption_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_caption_bar)
	_caption_bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_caption_bar.offset_top = -170.0

	_caption = Label.new()
	_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_caption.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_caption.add_theme_font_size_override("font_size", 44)
	_caption.add_theme_color_override("font_color", Color(1, 1, 1, 1))
	_caption.add_theme_color_override("font_outline_color", Color(0.12, 0.06, 0.02, 1))
	_caption.add_theme_constant_override("outline_size", 8)
	_caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_caption_bar.add_child(_caption)
	_caption.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_caption.offset_left = 80.0
	_caption.offset_right = -80.0
	_caption.modulate.a = 0.0

	_fade = _make_rect(Color(0, 0, 0, 1))
	add_child(_fade)
	_build_skip_button()

	_music = AudioStreamPlayer.new()
	add_child(_music)
	_sfx = AudioStreamPlayer.new()
	add_child(_sfx)
	var music_path: String = MUSIC_PATH
	if not ResourceLoader.exists(music_path):
		music_path = MUSIC_FALLBACK_PATH
	if ResourceLoader.exists(music_path):
		_music.stream = load(music_path) as AudioStream
		_music.volume_db = -40.0
		_music.play()

	_lightning_fired.resize(LIGHTNING_TIMES.size())
	_lightning_fired.fill(false)

	resized.connect(_layout_maya)
	_layout_maya()
	_apply_frame()


## The Skip button sits on top of everything (even the fades) in the corner.
func _build_skip_button() -> void:
	_skip_button = Button.new()
	_skip_button.text = "Skip >>"
	_skip_button.focus_mode = Control.FOCUS_NONE
	_skip_button.add_theme_font_size_override("font_size", 26)
	_skip_button.add_theme_color_override("font_color", Color(1, 1, 1, 1))
	_skip_button.add_theme_color_override("font_hover_color", Color(1, 1, 1, 1))
	_skip_button.add_theme_color_override("font_pressed_color", Color(1, 1, 1, 1))
	_skip_button.add_theme_stylebox_override("normal", _button_style(Color(0.29, 0.17, 0.08, 0.88), Color(0.62, 0.42, 0.2, 1)))
	_skip_button.add_theme_stylebox_override("hover", _button_style(Color(0.22, 0.47, 0.13, 0.95), Color(0.68, 0.96, 0.42, 1)))
	_skip_button.add_theme_stylebox_override("pressed", _button_style(Color(0.15, 0.33, 0.09, 0.97), Color(0.5, 0.78, 0.3, 1)))
	_skip_button.pressed.connect(_begin_skip)
	add_child(_skip_button)
	_skip_button.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_skip_button.offset_left = -190.0
	_skip_button.offset_right = -24.0
	_skip_button.offset_top = 20.0
	_skip_button.offset_bottom = 78.0


func _button_style(fill: Color, border: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = fill
	sb.border_color = border
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(12)
	sb.content_margin_left = 18.0
	sb.content_margin_right = 18.0
	sb.content_margin_top = 8.0
	sb.content_margin_bottom = 8.0
	return sb


func _build_shots() -> void:
	var warm := Color(1.0, 0.98, 0.92)
	_shots = [
		# ACT 1: paradise
		{"bg": 0, "start": 0.0, "dur": 4.5, "z0": 1.85, "z1": 2.15,
			"c0": Vector2(0.80, 0.72), "c1": Vector2(0.84, 0.70),
			"t0": Color(1, 1, 1), "t1": warm,
			"text": "Far out in the ocean lies a chain of five islands."},
		{"bg": 1, "start": 4.5, "dur": 4.5, "z0": 1.9, "z1": 2.1,
			"c0": Vector2(0.50, 0.70), "c1": Vector2(0.56, 0.68),
			"t0": Color(1, 1, 1), "t1": warm,
			"text": "Their beaches were clean, their forests thick, their rivers clear."},
		{"bg": 1, "start": 9.0, "dur": 4.0, "z0": 2.0, "z1": 2.2,
			"c0": Vector2(0.12, 0.72), "c1": Vector2(0.10, 0.70),
			"t0": Color(1, 1, 1), "t1": warm,
			"text": "For generations, the people lived in balance with nature."},
		# ACT 2: decline
		{"bg": 1, "start": 13.0, "dur": 4.5, "z0": 2.3, "z1": 2.0,
			"c0": Vector2(0.10, 0.90), "c1": Vector2(0.18, 0.84),
			"t0": Color(0.85, 0.82, 0.76), "t1": Color(0.74, 0.70, 0.64),
			"text": "But the world changed. Factories grew, and the waste followed."},
		{"bg": 0, "start": 17.5, "dur": 4.5, "z0": 2.2, "z1": 1.9,
			"c0": Vector2(0.10, 0.88), "c1": Vector2(0.20, 0.80),
			"t0": Color(0.80, 0.76, 0.70), "t1": Color(0.68, 0.64, 0.58),
			"text": "Plastic drifted in with every tide and buried the shores."},
		{"bg": 0, "start": 22.0, "dur": 4.5, "z0": 2.2, "z1": 2.0,
			"c0": Vector2(0.92, 0.70), "c1": Vector2(0.86, 0.70),
			"t0": Color(0.62, 0.62, 0.62), "t1": Color(0.52, 0.52, 0.54),
			"text": "Forests withered. Rivers ran dark. The villages fell silent."},
		{"bg": 0, "start": 26.5, "dur": 4.5, "z0": 1.85, "z1": 2.0,
			"c0": Vector2(0.33, 0.72), "c1": Vector2(0.22, 0.70),
			"t0": Color(0.50, 0.55, 0.68), "t1": Color(0.40, 0.44, 0.56),
			"text": "Then the storms came. Floods, one after another."},
		# ACT 3: despair
		{"bg": 0, "start": 31.0, "dur": 4.0, "z0": 1.9, "z1": 2.1,
			"c0": Vector2(0.80, 0.70), "c1": Vector2(0.84, 0.70),
			"t0": Color(1.0, 0.72, 0.45), "t1": Color(1.0, 0.62, 0.35),
			"text": "And the sun grew harsh, scorching whatever was left."},
		{"bg": 0, "start": 35.0, "dur": 4.0, "z0": 2.4, "z1": 2.1,
			"c0": Vector2(0.50, 0.85), "c1": Vector2(0.45, 0.80),
			"t0": Color(0.32, 0.35, 0.45), "t1": Color(0.28, 0.31, 0.40),
			"text": "The islands were fading. Almost no one was left to help."},
		# ACT 4: hope
		{"bg": 0, "start": 39.0, "dur": 5.0, "z0": 1.8, "z1": 1.7,
			"c0": Vector2(0.45, 0.75), "c1": Vector2(0.45, 0.74),
			"t0": Color(0.55, 0.60, 0.72), "t1": Color(0.90, 0.92, 0.92),
			"text": "Almost no one. On the shore, a guide named Maya kept watch."},
		{"bg": 1, "start": 44.0, "dur": 5.0, "z0": 1.9, "z1": 1.8,
			"c0": Vector2(0.45, 0.78), "c1": Vector2(0.47, 0.76),
			"t0": Color(0.95, 0.92, 0.85), "t1": Color(1.0, 0.98, 0.92),
			"text": "{name}, the islands need someone like you."},
		{"bg": 1, "start": 49.0, "dur": 3.5, "z0": 2.0, "z1": 1.9,
			"c0": Vector2(0.55, 0.70), "c1": Vector2(0.55, 0.68),
			"t0": Color(1.0, 0.96, 0.86), "t1": Color(1.0, 1.0, 1.0),
			"text": "Clean the shores. Craft your defenses. Restore every island."},
		# ACT 5: title reveal
		{"bg": 0, "start": 52.5, "dur": 7.5, "z0": 1.8, "z1": 1.0,
			"c0": Vector2(0.45, 0.74), "c1": Vector2(0.50, 0.50),
			"t0": Color(1, 1, 1), "t1": Color(1, 1, 1),
			"text": "Five islands. One survivor. Your quest begins now."},
	]
	for shot in _shots:
		shot["text"] = String(shot["text"]).replace("{name}", GameBoot.player_name)


func _process(delta: float) -> void:
	if _bg == null or _finishing:
		return
	_elapsed += delta
	if _skipping:
		_skip_t += delta
		if _skip_t >= SKIP_FADE:
			_finish()
			return
	elif _elapsed >= TOTAL_TIME:
		_finish()
		return
	_fire_cues()
	_apply_frame()


## Positions the camera, tint, caption, fades and flashes for the current time.
func _apply_frame() -> void:
	if _bg == null or _textures.is_empty():
		return
	var idx := _shot_index(_elapsed)
	var shot: Dictionary = _shots[idx]
	var local: float = _elapsed - float(shot["start"])
	var dur: float = float(shot["dur"])
	var t: float = clampf(local / dur, 0.0, 1.0)

	# Camera: zoom + centre drift, clamped so the picture never shows edges.
	var vs: Vector2 = get_viewport_rect().size
	var tex: Texture2D = _textures[int(shot["bg"])]
	if _bg.texture != tex:
		_bg.texture = tex
	var tex_size: Vector2 = tex.get_size()
	var base: float = maxf(vs.x / tex_size.x, vs.y / tex_size.y)
	var zoom: float = lerpf(float(shot["z0"]), float(shot["z1"]), t)
	var centre: Vector2 = (shot["c0"] as Vector2).lerp(shot["c1"] as Vector2, t)
	var scaled: Vector2 = tex_size * base * zoom
	var pos: Vector2 = vs * 0.5 - centre * scaled
	pos.x = clampf(pos.x, vs.x - scaled.x, 0.0)
	pos.y = clampf(pos.y, vs.y - scaled.y, 0.0)
	_bg.size = scaled
	_bg.position = pos
	_bg.modulate = (shot["t0"] as Color).lerp(shot["t1"] as Color, t)

	# Caption: new text per shot, fades in after 0.3s and out before the cut.
	if idx != _current_shot:
		_current_shot = idx
		_caption.text = String(shot["text"])
	var cap_a: float = minf((local - 0.3) / 0.5, (dur - local) / 0.4)
	if idx == _shots.size() - 1:
		cap_a = (local - 0.3) / 0.5  # the last caption stays until the fade-out
	_caption.modulate.a = clampf(cap_a, 0.0, 1.0)
	_caption_bar.modulate.a = clampf(cap_a, 0.0, 1.0)

	# Maya slides in/out during the hopeful beat.
	var maya_a: float = 0.0
	if _elapsed >= MAYA_IN and _elapsed < MAYA_OUT + 0.5:
		maya_a = minf((_elapsed - MAYA_IN) / 0.6, (MAYA_OUT + 0.5 - _elapsed) / 0.5)
	_maya.modulate.a = clampf(maya_a, 0.0, 1.0)
	_layout_maya(1.0 - clampf((_elapsed - MAYA_IN) / 0.6, 0.0, 1.0))

	# Lightning flashes.
	var flash_a: float = 0.0
	for e in LIGHTNING_TIMES:
		var dt: float = _elapsed - float(e)
		if dt >= 0.0 and dt < 0.5:
			flash_a = maxf(flash_a, (1.0 - dt / 0.5) * 0.7)
	_flash.modulate.a = flash_a

	# Fades: in from black, a soft dip at each cut, out to black at the end.
	var fade_a: float = 0.0
	if _elapsed < FADE_IN:
		fade_a = 1.0 - _elapsed / FADE_IN
	elif idx > 0 and local < 0.5:
		fade_a = 0.8 * (1.0 - local / 0.5)
	if _elapsed > TOTAL_TIME - FADE_OUT:
		fade_a = maxf(fade_a, (_elapsed - (TOTAL_TIME - FADE_OUT)) / FADE_OUT)
	if _skipping:
		fade_a = maxf(fade_a, clampf(_skip_t / SKIP_FADE, 0.0, 1.0))
	_fade.modulate.a = clampf(fade_a, 0.0, 1.0)

	# Music: fade up at the start, down at the end (or when skipping).
	if _music.playing:
		var vol: float = MUSIC_DB
		if _elapsed < 1.5:
			vol = lerpf(-40.0, MUSIC_DB, _elapsed / 1.5)
		var out: float = maxf(
			(_elapsed - (TOTAL_TIME - FADE_OUT)) / FADE_OUT,
			_skip_t / SKIP_FADE if _skipping else 0.0
		)
		if out > 0.0:
			vol = lerpf(vol, -40.0, clampf(out, 0.0, 1.0))
		_music.volume_db = vol


func _shot_index(time: float) -> int:
	var idx := 0
	for i in _shots.size():
		if time >= float(_shots[i]["start"]):
			idx = i
	return idx


## One-shot sound cues (thunder on each lightning flash, a chime at the reveal).
func _fire_cues() -> void:
	for i in LIGHTNING_TIMES.size():
		if not _lightning_fired[i] and _elapsed >= float(LIGHTNING_TIMES[i]):
			_lightning_fired[i] = true
			_play_sfx(THUNDER_PATH, -4.0)
	if not _alarm_fired and _elapsed >= ALARM_TIME:
		_alarm_fired = true
		_play_sfx(ALARM_PATH, -12.0)
	if not _chime_fired and _elapsed >= CHIME_TIME:
		_chime_fired = true
		_play_sfx(CHIME_PATH, -6.0)


func _play_sfx(path: String, volume_db: float) -> void:
	if not ResourceLoader.exists(path):
		return
	_sfx.stream = load(path) as AudioStream
	_sfx.volume_db = volume_db
	_sfx.play()


## Places Maya on the left of the screen, bottom-aligned. `slide` (0..1) pushes
## her slightly down/left while she is fading in.
func _layout_maya(slide: float = 0.0) -> void:
	if _maya == null:
		return
	var vs: Vector2 = get_viewport_rect().size
	var h: float = vs.y * 0.52
	var w: float = h * 0.62
	_maya.size = Vector2(w, h)
	_maya.position = Vector2(vs.x * 0.08 - slide * 60.0, vs.y - h - 150.0 + slide * 40.0)


func _input(event: InputEvent) -> void:
	if _finishing or _skipping:
		return
	var key := event as InputEventKey
	if key != null and key.pressed and not key.echo:
		if key.keycode in [KEY_ESCAPE, KEY_ENTER, KEY_KP_ENTER, KEY_SPACE]:
			get_viewport().set_input_as_handled()
			_begin_skip()


## Starts the quick fade-out; _process() then calls _finish().
func _begin_skip() -> void:
	if _finishing or _skipping:
		return
	_skipping = true
	_skip_t = 0.0
	_skip_button.disabled = true


func _make_rect(color: Color) -> ColorRect:
	var rect := ColorRect.new()
	rect.color = color
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	return rect


## Hands over to the real game. The survivor name was already set on the menu.
func _finish() -> void:
	if _finishing:
		return
	_finishing = true
	if _music != null:
		_music.stop()
	var err: Error = GameBoot.start_new_game()
	if err != OK:
		push_error("intro_story.gd: could not start the game (error %d)." % err)
		get_tree().change_scene_to_file(MENU_SCENE_PATH)
