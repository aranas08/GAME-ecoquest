extends Node2D
## Land wildlife for EcoQuest. Harmless rabbits/birds add life to the island;
## snakes and scorpions have a clear warning sign and remove exactly 10 HP when
## the player steps close. Each encounter only hurts once until the player backs
## away, preventing continuous damage while standing on the same animal.

const CONTACT_RADIUS := 42.0
const RESET_RADIUS := 78.0
const DAMAGE := 10
const MAX_CREATURES := 10
const SKY_BIRD_COUNT := 5

var _player: CharacterBody2D
var _creatures: Array[Dictionary] = [] # {pos, kind, dangerous, hit}
var _sky_birds: Array[Dictionary] = [] # small animated bird silhouettes above the island
var _sky_left := -400.0
var _sky_right := 400.0
var _sky_top := -300.0
var _sky_bottom := 300.0
var _time := 0.0

func setup(player: CharacterBody2D, tilemap: TileMapLayer, open_cells: Array[Vector2i], island_id: String) -> void:
    _player = player
    z_index = 20
    var candidates: Array[Vector2] = []
    # Decorations may consume many spawn cells before wildlife is created. If
    # that leaves too few cells, rebuild the candidate list from the actual map.
    var source_cells: Array[Vector2i] = open_cells.duplicate()
    if source_cells.size() < 8:
        source_cells.clear()
        for cell in tilemap.get_used_cells():
            var data: TileData = tilemap.get_cell_tile_data(cell)
            if data != null and data.get_collision_polygons_count(0) == 0:
                source_cells.append(cell)
    var player_local := to_local(player.global_position)
    for cell in source_cells:
        var p := to_local(tilemap.to_global(tilemap.map_to_local(cell))) + Vector2(0, 14)
        # Keep animals in the playable island area, with a few visible nearby.
        if p.distance_to(player_local) < 210.0:
            continue
        var too_close := false
        for existing in candidates:
            if p.distance_to(existing) < 120.0:
                too_close = true
                break
        if not too_close:
            candidates.append(p)
    # Use the island bounds to create a small flock that glides across the scene.
    if not open_cells.is_empty():
        var first_pos := to_local(tilemap.to_global(tilemap.map_to_local(open_cells[0])))
        _sky_left = first_pos.x
        _sky_right = first_pos.x
        _sky_top = first_pos.y
        _sky_bottom = first_pos.y
        for cell in open_cells:
            var bound_pos := to_local(tilemap.to_global(tilemap.map_to_local(cell)))
            _sky_left = minf(_sky_left, bound_pos.x)
            _sky_right = maxf(_sky_right, bound_pos.x)
            _sky_top = minf(_sky_top, bound_pos.y)
            _sky_bottom = maxf(_sky_bottom, bound_pos.y)
        var span_x := maxf(200.0, _sky_right - _sky_left)
        for bird_index in range(SKY_BIRD_COUNT):
            _sky_birds.append({
                "pos": Vector2(randf_range(_sky_left, _sky_right), randf_range(_sky_top, _sky_bottom)),
                "phase": randf() * TAU,
                "speed": randf_range(18.0, 34.0),
                "offset": randf_range(0.0, span_x)
            })
    candidates.shuffle()

    # Ensure the player can see wildlife even on smaller islands. The fallback
    # positions are on reachable map cells whenever possible.
    if candidates.is_empty():
        for offset in [Vector2(260, 100), Vector2(-260, 140), Vector2(180, -230), Vector2(-180, -250), Vector2(360, -120), Vector2(-350, -80)]:
            candidates.append(player_local + offset)
    candidates.shuffle()
    var count := mini(MAX_CREATURES, candidates.size())
    for i in range(count):
        var dangerous := i < mini(3, count)
        var kind := "snake" if dangerous and i % 2 == 0 else ("scorpion" if dangerous else ("rabbit" if i % 2 == 0 else "bird"))
        # Change the mix a little by island so the world feels varied.
        if not dangerous and island_id == "forest":
            kind = "rabbit" if i % 2 == 0 else "bird"
        _creatures.append({"pos": candidates[i], "kind": kind, "dangerous": dangerous, "hit": false, "phase": randf() * TAU})
    print("LandWildlife: spawned %d land animals and %d flying birds on %s" % [_creatures.size(), _sky_birds.size(), island_id])
    queue_redraw()

func _process(delta: float) -> void:
    if _player == null or not is_instance_valid(_player):
        return
    _time += delta
    var span_x := maxf(200.0, _sky_right - _sky_left)
    for bird in _sky_birds:
        var bird_pos: Vector2 = bird.pos
        bird_pos.x += float(bird.speed) * delta
        if bird_pos.x > _sky_right + 30.0:
            bird_pos.x = _sky_left - 30.0
            bird_pos.y = randf_range(_sky_top, _sky_bottom)
        bird_pos.y += sin(_time * 1.4 + float(bird.phase)) * 5.0 * delta
        bird.pos = bird_pos
    var player_pos := to_local(_player.global_position)
    var changed := false
    for creature in _creatures:
        var distance: float = player_pos.distance_to(creature.pos)
        if not creature.dangerous:
            continue
        if distance > RESET_RADIUS and creature.hit:
            creature.hit = false
        elif distance <= CONTACT_RADIUS and not creature.hit:
            creature.hit = true
            if _player.has_method("take_wildlife_damage"):
                _player.call("take_wildlife_damage", DAMAGE)
            else:
                _player.call("take_damage", DAMAGE)
            changed = true
    # Redraw every frame so the flock and animals animate smoothly.
    queue_redraw()

func _draw() -> void:
    for creature in _creatures:
        var p: Vector2 = creature.pos
        var kind: String = creature.kind
        var bob := sin(_time * 2.0 + float(creature.phase)) * 1.5
        var c := p + Vector2(0, bob)
        match kind:
            "snake":
                # Curled green snake with a visible head and eyes.
                draw_arc(c + Vector2(0, 2), 13.0, 0.0, TAU * 0.92, 16, Color("#286b3c"), 7.0, true)
                draw_circle(c + Vector2(11, -7), 6.0, Color("#4b9a4d"))
                draw_circle(c + Vector2(13, -9), 1.5, Color.WHITE)
                draw_circle(c + Vector2(13.5, -9), 0.7, Color.BLACK)
                draw_line(c + Vector2(16, -5), c + Vector2(21, -3), Color("#d84a43"), 2.0, true)
            "scorpion":
                draw_filled_ellipse(c + Vector2(0, 2), Vector2(12, 7), Color("#9b552e"))
                draw_circle(c + Vector2(0, 1), 7.0, Color("#b96d35"))
                draw_line(c + Vector2(8, -2), c + Vector2(16, -10), Color("#6b3c27"), 3.0, true)
                draw_line(c + Vector2(16, -10), c + Vector2(19, -17), Color("#6b3c27"), 3.0, true)
                draw_line(c + Vector2(-6, 5), c + Vector2(-13, 11), Color("#6b3c27"), 2.0, true)
                draw_line(c + Vector2(6, 5), c + Vector2(13, 11), Color("#6b3c27"), 2.0, true)
                draw_line(c + Vector2(-7, -1), c + Vector2(-14, -7), Color("#6b3c27"), 2.0, true)
                draw_line(c + Vector2(7, -1), c + Vector2(14, -7), Color("#6b3c27"), 2.0, true)
            "rabbit":
                draw_filled_ellipse(c, Vector2(10, 7), Color("#d8c6a6"))
                draw_circle(c + Vector2(8, -5), 6.0, Color("#e6d7bd"))
                draw_filled_ellipse(c + Vector2(5, -14), Vector2(2.3, 7.0), Color("#d8b5ad"))
                draw_filled_ellipse(c + Vector2(11, -14), Vector2(2.3, 7.0), Color("#d8b5ad"))
                draw_circle(c + Vector2(10, -6), 1.2, Color.BLACK)
            "bird":
                draw_filled_ellipse(c, Vector2(9, 6), Color("#e2ad43"))
                draw_circle(c + Vector2(7, -4), 5.0, Color("#f0c95a"))
                draw_colored_polygon(PackedVector2Array([c + Vector2(12, -4), c + Vector2(19, -1), c + Vector2(12, 0)]), Color("#d97836"))
                draw_circle(c + Vector2(8, -5), 1.0, Color.BLACK)
        if creature.dangerous:
            # Yellow warning triangle floats over dangerous wildlife.
            var sign := c + Vector2(0, -34)
            draw_colored_polygon(PackedVector2Array([sign + Vector2(0, -13), sign + Vector2(-13, 10), sign + Vector2(13, 10)]), Color("#ffd43b"))
            draw_polyline(PackedVector2Array([sign + Vector2(0, -13), sign + Vector2(-13, 10), sign + Vector2(13, 10), sign + Vector2(0, -13)]), Color("#3b2b12"), 2.0, true)
            draw_line(sign + Vector2(0, -6), sign + Vector2(0, 2), Color("#241d13"), 3.0, true)
            draw_circle(sign + Vector2(0, 6), 1.5, Color("#241d13"))

    # Flying birds are drawn as small dark silhouettes with flapping wings.
    # They are decorative and never damage Maya.
    for bird in _sky_birds:
        var bp: Vector2 = bird.pos
        var flap := sin(_time * 9.0 + float(bird.phase)) * 4.0
        var bird_color := Color("#354b43")
        draw_line(bp + Vector2(-10, 1), bp + Vector2(-2, flap), bird_color, 2.5, true)
        draw_line(bp + Vector2(-2, flap), bp + Vector2(3, 1), bird_color, 2.5, true)
        draw_line(bp + Vector2(3, 1), bp + Vector2(10, -2), bird_color, 2.5, true)
        draw_line(bp + Vector2(-2, flap), bp + Vector2(0, 5), bird_color, 2.0, true)

func draw_filled_ellipse(center: Vector2, radii: Vector2, color: Color) -> void:
    var points := PackedVector2Array()
    for i in range(17):
        var angle := TAU * float(i) / 16.0
        points.append(center + Vector2(cos(angle) * radii.x, sin(angle) * radii.y))
    draw_colored_polygon(points, color)
