extends Area2D
## maya.gd
## Environmental Guide NPC. Player walks close and presses "interact" (E)
## to talk.
##
## Design doc 5B lists her core verbs as Guide / Explain / Give quests /
## Provide information / Reward, and her arc as "begins by providing basic
## guidance... as the player progresses, she provides more challenging quests
## and encourages the player to become more independent". So talking to her
## does up to four things, in priority order:
##   1. First ever talk (island 1 only) -> greet the player by name, grant
##      the intro quest
##   2. Hasn't given this island's quest yet -> grant it ("Give quests";
##      wording escalates with the island's own difficulty)
##   3. Owes a reward -> hand over a supply drop for each hazard survived
##   4. Otherwise -> advice tuned to this island's hazard

signal player_in_range(in_range: bool)

## Supply drop handed over after each hazard the player survives.
const REWARD_PLASTIC := 8
const REWARD_WOOD := 5
const REWARD_HEAL := 15

## Human-readable hazard names for quest text.
const HAZARD_LABEL: Dictionary = {
	"flood": "flood", "storm": "storm", "heat": "heat wave",
}

## Generic tips, used as a fallback and on later islands.
@export var dialogue_lines: Array[String] = [
	"Collect everything you can carry. Out here, litter is raw material.",
	"When you've got materials, open the Crafting menu with C and build some gear.",
	"Keep an eye on the sky. A warning means a hazard is already on its way.",
	"Press Q any time to check what this island still needs from you.",
	"You're getting the hang of this. Keep collecting, keep crafting, keep surviving.",
]

## Hazard-specific coaching, so her advice matches the island you're on.
const HAZARD_ADVICE: Dictionary = {
	"flood": [
		"Floods come fast here. Stockpile plastic before the warning, not after.",
		"A Flood Barrier costs 20 plastic and 10 wood, and it blunts every flood after it.",
	],
	"storm": [
		"Storms tear through anything that isn't tied down. Wood is what saves you.",
		"Gather wood early. Once the warning lands you won't have time to go looking.",
	],
	"heat": [
		"The heat up here is the quiet kind of dangerous. Shade is everything.",
		"Plastic sheeting makes decent shade cover. Keep a reserve of it.",
	],
}

## The two-way conversation box (player <-> Maya).
const DIALOGUE_BOX_PATH := "res://scripts/dialogue_box.gd"

## Short replies the player and Maya trade after a piece of advice.
const PLAYER_REPLIES: Array = [
	"Got it. Thanks, Maya.",
	"Makes sense. I'll prepare.",
	"Anything else I should know?",
	"I'll keep that in mind.",
]
const MAYA_FOLLOWUPS: Array = [
	"Good. Stay sharp out there.",
	"That's the spirit. Come back any time.",
	"Just keep collecting and crafting. You've got this.",
	"Small actions, a healthier tomorrow.",
]

## Her own animated sprite sheet (32x32 cells, 6 columns). Every direction has
## its own row, so she never just flips: idle / walk for down, left, right, up,
## plus a cooking loop (back to the camera, stirring) and talk loops.
const SHEET_PATH := "res://assets/images/npc/Maya_Sheet.png"
const FRAME_SIZE := 32
const SHEET_COLS := 6
const ANIM_ROWS := {
	"idle_down": 0, "idle_left": 1, "idle_right": 2, "idle_up": 3,
	"walk_down": 4, "walk_left": 5, "walk_right": 6, "walk_up": 7,
	"cook_up": 8,
	"talk_down": 9, "talk_left": 10, "talk_right": 11,
}
const ANIM_FPS := {"idle": 5.0, "walk": 9.0, "cook": 7.0, "talk": 8.0}
const BODY_SCALE := 3.0          # same size as the player inside the house
const BODY_OFFSET_Y := 13.0      # puts her boots about 46px below her origin
const TURN_TIME := 0.35          # seconds she takes to turn and look at you

@onready var talk_sfx: AudioStreamPlayer = $TalkSFX
@onready var interact_prompt: Label = $InteractPrompt

## What she goes back to after a conversation: "idle" outdoors, "cook" in her
## kitchen (set by eco_house.gd).
var home_activity: String = "idle"
var facing: String = "down"          # down | left | right | up
var activity: String = "idle"        # idle | walk | cook | talk
var _body: AnimatedSprite2D
var _turning: bool = false

var _player_nearby: CharacterBody2D = null
var _chatting: bool = false
var _line_index: int = 0
var _quest_given: bool = false
var _island_quest_given: bool = false
## How many of the player's survived hazards she has already rewarded.
var _rewards_given: int = 0


func _ready() -> void:
	_build_body()
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)
	player_in_range.connect(func(in_range): interact_prompt.visible = in_range)
	# Marks her own quest complete the moment this island is stabilized,
	# even if the player doesn't talk to her again before pressing N.
	IslandManager.island_unlocked_next.connect(_on_island_unlocked)


func _unhandled_input(event: InputEvent) -> void:
	if _player_nearby and event.is_action_pressed("interact"):
		_talk()
		get_viewport().set_input_as_handled()


## Called by Maya's house when the player presses E next to her indoors (her
## Area2D is switched off there). She stops what she is doing, turns to face
## the player, then runs the normal conversation. Afterwards she forgets the
## player again so E can't trigger her from across the island.
func start_conversation(player: CharacterBody2D) -> void:
	if _chatting or _turning or player == null:
		return
	_turning = true
	face_toward(player.global_position)
	set_activity("idle")
	await get_tree().create_timer(TURN_TIME).timeout
	_turning = false
	if not is_instance_valid(player):
		set_activity(home_activity)
		return
	_player_nearby = player
	_talk()
	_player_nearby = null
	if not _chatting:
		set_activity(home_activity)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		_player_nearby = body
		player_in_range.emit(true)


func _on_body_exited(body: Node2D) -> void:
	if body == _player_nearby:
		_player_nearby = null
		player_in_range.emit(false)


func _talk() -> void:
	if _chatting:
		return
	if _player_nearby != null:
		face_toward(_player_nearby.global_position)
	talk_sfx.play()

	if IslandManager.current_index == 0 and not _quest_given:
		_give_intro_quest()
		return

	if not _island_quest_given:
		_give_island_quest()
		return

	if IslandManager.total_hazards_survived > _rewards_given:
		_give_reward()
		return

	_converse(_advice_conversation(_next_advice()))


## First conversation: greet the survivor by the name they chose and hand
## out the starting quest.
func _give_intro_quest() -> void:
	_quest_given = true
	QuestManager.add_quest(
		"maya_intro",
		"Learn the Ropes",
		"Talk to Maya, then survive your first environmental warning."
	)
	_converse(_intro_conversation())


## Her "Give quests" core verb, and the mechanical half of her Character Arc
## ("begins by providing basic guidance... provides more challenging quests
## and encourages the player to become more independent"): one explicit quest
## per island, worded from that island's own hazard and difficulty, so it
## reads as harder the further the player has come.
func _give_island_quest() -> void:
	_island_quest_given = true
	var island: Dictionary = IslandManager.current_island()
	var hazard_word: String = HAZARD_LABEL.get(island.hazard, island.hazard)
	QuestManager.add_quest(
		_island_quest_id(island),
		"Stabilize %s" % island.name,
		"Survive %d %s warning(s) here, including a final one worse than the rest." % [
			island.quests_to_unlock, hazard_word
		]
	)
	var line: String
	if IslandManager.current_index == 0:
		line = "One more thing: stabilize this whole island and I'll know you're ready for the next one."
	else:
		line = "New territory, same idea: stabilize %s and you're on to the next one. This one won't go easy on you." % island.name
	_converse(_island_quest_conversation(line, island, hazard_word))


func _on_island_unlocked(island: Dictionary) -> void:
	QuestManager.complete_quest(_island_quest_id(island))


func _island_quest_id(island: Dictionary) -> String:
	return "island_quest_%s" % island.id


## Her "Reward" core verb: a supply drop for every hazard survived since the
## last time the player checked in with her.
func _give_reward() -> void:
	_rewards_given = IslandManager.total_hazards_survived
	if _player_nearby == null:
		return
	_player_nearby.collect_material("plastic", REWARD_PLASTIC)
	_player_nearby.collect_material("wood", REWARD_WOOD)
	_player_nearby.heal(REWARD_HEAL)
	_converse(_reward_conversation())


## Advice for the hazard this island actually throws at you, falling back to
## the generic tips once the hazard lines run out.
func _next_advice() -> String:
	var hazard: String = IslandManager.current_island().get("hazard", "")
	var pool: Array = HAZARD_ADVICE.get(hazard, [])
	var line: String
	if _line_index < pool.size():
		line = pool[_line_index]
	elif dialogue_lines.size() > 0:
		line = dialogue_lines[(_line_index - pool.size()) % dialogue_lines.size()]
	else:
		line = "Keep going. This island still needs you."
	_line_index += 1
	return line


## Opens the player <-> Maya conversation box. Falls back to the plain HUD
## message if the box script can't be loaded.
func _converse(lines: Array) -> void:
	var box_script := load(DIALOGUE_BOX_PATH) as GDScript
	if box_script == null:
		for entry in lines:
			if entry is Dictionary and entry.get("who", "") == "maya":
				_say(String(entry.get("text", "")))
		return
	var box: Node = box_script.new()
	get_tree().root.add_child(box)
	_chatting = true
	# The box pauses the game; Maya keeps animating (mouth moving) meanwhile.
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_activity("talk")
	box.finished.connect(func() -> void:
		_chatting = false
		process_mode = Node.PROCESS_MODE_INHERIT
		set_activity(home_activity))
	box.start(lines, GameBoot.player_name)


## First meeting: Maya greets the survivor, explains what happened, and lets
## them ask questions before heading out.
func _intro_conversation() -> Array:
	var island: Dictionary = IslandManager.current_island()
	var hazard_word: String = HAZARD_LABEL.get(island.get("hazard", ""), "hazard")
	return [
		{"who": "maya", "text": "Hey, you're awake! I'm Maya, the environmental guide for this region. Welcome, {name}."},
		{"who": "player", "text": "Where am I? What happened to this place?"},
		{"who": "maya", "text": String(island.get("intro", "These islands are in trouble, and we need all the help we can get."))},
		{"who": "maya", "text": "Ask me anything before you head out."},
		{"choices": [
			{"text": "What can I actually do about all this?", "then": [
				{"who": "maya", "text": "Plastic is raw material out here. Walk over bottles, bags and driftwood and they go straight into your backpack."},
				{"who": "maya", "text": "Then press C to open the Crafting menu and build gear: flood barriers, shelter, even medicine."},
				{"who": "player", "text": "Trash into gear. I can work with that."},
			]},
			{"text": "What are these warnings you keep mentioning?", "then": [
				{"who": "maya", "text": "Every island has its own hazard. Here it's a %s. A warning means one is already on its way." % hazard_word},
				{"who": "player", "text": "How do I survive one?"},
				{"who": "maya", "text": "Stock up before it lands, craft protection, and keep your health up. Press Q any time to see what this island still needs."},
			]},
			{"text": "Why me?", "then": [
				{"who": "maya", "text": "Honestly? You're the one who woke up and asked how to help instead of how to leave."},
				{"who": "player", "text": "...Fair enough."},
				{"who": "maya", "text": "Small actions add up, {name}. That's all this takes."},
			]},
			{"text": "I'm ready. Let's go.", "exit": true, "then": [
				{"who": "maya", "text": "That's the spirit!"},
			]},
		], "loop": true, "prompt": "What do you ask Maya?"},
		{"who": "maya", "text": "Come find me after your first warning. I'll have a supply drop waiting."},
	]


## Maya hands out this island's quest, and the player asks what it takes.
func _island_quest_conversation(opening: String, island: Dictionary, hazard_word: String) -> Array:
	var player_line: String = "What does 'stabilize' actually mean?"
	var closing: String = "Understood. I'll be ready."
	if IslandManager.current_index > 0:
		player_line = "Another island, another disaster. What do I need to do?"
		closing = "Then let's get to work."
	return [
		{"who": "maya", "text": opening},
		{"who": "player", "text": player_line},
		{"who": "maya", "text": "Survive %d %s warning(s) here, including a final one worse than the rest. Do that and the way to the next island opens." % [
			int(island.get("quests_to_unlock", 1)), hazard_word
		]},
		{"who": "player", "text": closing},
	]


## Thank-you scene for the supply drop. The materials are handed over first.
func _reward_conversation() -> Array:
	return [
		{"who": "maya", "text": "You held the line out there, {name}. Take these: %d plastic, %d wood, and something for those cuts." % [
			REWARD_PLASTIC, REWARD_WOOD
		]},
		{"who": "player", "text": "Thanks, Maya. That helps a lot."},
		{"who": "maya", "text": "Don't thank me. Thank every bottle you pulled off that beach."},
	]


## A piece of advice, a short reply from the player, and a follow-up from Maya.
func _advice_conversation(advice: String) -> Array:
	var i: int = maxi(_line_index - 1, 0)
	return [
		{"who": "maya", "text": advice},
		{"who": "player", "text": String(PLAYER_REPLIES[i % PLAYER_REPLIES.size()])},
		{"who": "maya", "text": String(MAYA_FOLLOWUPS[i % MAYA_FOLLOWUPS.size()])},
	]


func _say(line: String) -> void:
	var level := get_tree().get_first_node_in_group("level")
	if level:
		level.dialogue_shown.emit("Maya: \"%s\"" % line)


# --- Sprite animation ------------------------------------------------------------------

## Builds her AnimatedSprite2D from Maya_Sheet.png. The old single-image Sprite2D
## from maya.tscn is hidden (it is still used as the portrait in dialogue).
func _build_body() -> void:
	var sheet := load(SHEET_PATH) as Texture2D
	if sheet == null:
		return
	var frames := SpriteFrames.new()
	if frames.has_animation("default"):
		frames.remove_animation("default")
	for anim_key in ANIM_ROWS.keys():
		var anim_name: String = String(anim_key)
		var row: int = int(ANIM_ROWS[anim_key])
		var kind: String = anim_name.split("_")[0]
		frames.add_animation(anim_name)
		frames.set_animation_loop(anim_name, true)
		frames.set_animation_speed(anim_name, float(ANIM_FPS.get(kind, 6.0)))
		for col in SHEET_COLS:
			var tex := AtlasTexture.new()
			tex.atlas = sheet
			tex.region = Rect2(col * FRAME_SIZE, row * FRAME_SIZE, FRAME_SIZE, FRAME_SIZE)
			frames.add_frame(anim_name, tex)
	_body = AnimatedSprite2D.new()
	_body.name = "Body"
	_body.sprite_frames = frames
	_body.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_body.scale = Vector2.ONE * BODY_SCALE
	_body.position = Vector2(0.0, BODY_OFFSET_Y)
	add_child(_body)
	var old_sprite := get_node_or_null("Sprite2D") as Sprite2D
	if old_sprite:
		old_sprite.visible = false
	_refresh_animation()


## Which way she is looking: "down", "left", "right" or "up".
func face_direction(dir: String) -> void:
	if dir != "down" and dir != "left" and dir != "right" and dir != "up":
		return
	facing = dir
	_refresh_animation()


## Looks at a point in the world (picks the dominant axis, so she always uses
## one of the four hand-drawn directions).
func face_toward(world_pos: Vector2) -> void:
	var d: Vector2 = world_pos - global_position
	if absf(d.x) > absf(d.y):
		face_direction("right" if d.x > 0.0 else "left")
	else:
		face_direction("down" if d.y > 0.0 else "up")


## "idle", "walk", "cook" or "talk".
func set_activity(new_activity: String) -> void:
	activity = new_activity
	_refresh_animation()


func _refresh_animation() -> void:
	if _body == null:
		return
	var frames: SpriteFrames = _body.sprite_frames
	var anim_name: String
	if activity == "cook":
		anim_name = "cook_up"          # always at the stove, back to the room
	else:
		anim_name = "%s_%s" % [activity, facing]
	if not frames.has_animation(anim_name):
		anim_name = "idle_%s" % facing   # e.g. there is no talk_up
	if _body.animation != StringName(anim_name) or not _body.is_playing():
		_body.play(anim_name)
