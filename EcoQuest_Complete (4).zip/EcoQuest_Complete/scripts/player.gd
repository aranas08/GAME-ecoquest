extends CharacterBody2D

## Survivor character: movement/animation (original) plus the survival
## systems needed for EcoQuest's core loop: collecting materials, HP,
## and reacting to environmental hazards like the Flood Warning challenge.

signal plastic_changed(new_total: int)
signal wood_changed(new_total: int)
signal hp_changed(new_hp: int, max_hp: int)
signal item_crafted(recipe_id: String, recipe_name: String)
## Fired for pickups from the world (not rewards), so quests can count
## bottles / bags / wood separately. item_kind is "bottle", "bag" or "wood".
signal item_collected(material_type: String, item_kind: String, amount: int)
signal craft_failed(recipe_id: String)
signal defeated

const SPEED = 300.0
const BASE_MAX_HP := 100
const CraftedStructureScript := preload("res://scripts/crafted_structure.gd")

## Backpack + grab animation. Player_Backpack.png is Player.png with a
## backpack drawn on every frame (same layout); Player_Pickup.png holds the
## 5-frame grab animation for down / right / up (left = right, flipped).
const BACKPACK_SHEET := "res://assets/images/player/Player_Backpack.png"
const PICKUP_SHEET := "res://assets/images/player/Player_Pickup.png"
const PICKUP_FRAMES := 5
const PICKUP_FPS := 12.0
const PICKUP_TIME := 0.45  # how long the grab pose holds when standing still
const ITEM_NAMES := {"bottle": "Bottle", "bag": "Bag", "wood": "Wood"}
const ITEM_ICONS := {
	"bottle": "res://assets/images/items/plastic_bottle.png",
	"bag": "res://assets/images/items/plastic_bag.png",
	"wood": "res://assets/images/items/wood_log.png",
}

var last_direction: Vector2 = Vector2.RIGHT
var max_hp: int = BASE_MAX_HP
var hp: int = BASE_MAX_HP
var plastic_count: int = 0
var wood_count: int = 0
var flood_resistance: int = 0  # flat damage reduction from crafted gear
var lifetime_plastic: int = 0  # everything ever picked up, for the ending summary
var lifetime_wood: int = 0
var crafted_ids: Dictionary = {}  # recipe_id -> times crafted
var is_defeated: bool = false
## Set by Maya's house while the player is inside. The water hazard and other
## island-wide systems skip the player while this is true.
var indoors: bool = false
## Multiplier on SPEED (the house lowers it a little for tighter steering).
var speed_scale: float = 1.0
## Why the player died ("flood", ...). main.gd uses it for the game-over text.
var death_cause: String = ""
var _pickup_left: float = 0.0
var _bump_tween: Tween

@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
@onready var name_label: Label = $NameLabel

## How far above the player's origin the name tag floats, in world pixels.
## NameLabel has top_level = true (it ignores this node's scale/rotation),
## so this offset is a plain screen-space pixel amount, not affected by the
## Player node's Vector2(4, 4) scale.
const NAME_LABEL_OFFSET_Y := 60.0


func _ready() -> void:
	add_to_group("player")
	# Top-down game: the default GROUNDED mode treats walls below you as a "floor"
	# (floor snap / slope handling), which makes the character stick and jitter
	# against furniture and walls. FLOATING is the correct mode for top-down.
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	_setup_backpack_and_pickup()
	if IslandManager.has_saved_state():
		IslandManager.apply_saved_state(self)
	# Show whatever name was entered on the main menu (falls back to
	# GameBoot's default "Survivor" if none was set).
	name_label.text = GameBoot.player_name
	_update_name_label_position()
	# Push initial values so any HUD that connects late still gets synced.
	hp_changed.emit(hp, max_hp)
	plastic_changed.emit(plastic_count)
	wood_changed.emit(wood_count)


func _physics_process(_delta: float) -> void:
	if is_defeated:
		velocity = Vector2.ZERO
		_update_name_label_position()
		return
	_pickup_left = maxf(_pickup_left - get_physics_process_delta_time(), 0.0)
	process_movement()
	process_animation(last_direction)
	move_and_slide()
	_update_name_label_position()


## Keeps NameLabel centered above the player's head every frame, in world
## space, regardless of movement direction or the node's own scale.
func _update_name_label_position() -> void:
	var above_head: Vector2 = global_position + Vector2(0, -NAME_LABEL_OFFSET_Y)
	name_label.global_position = above_head - Vector2(name_label.size.x * 0.5, name_label.size.y)
	
func process_movement() -> void:
		# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_vector("left","right", "up","down")
	
	if direction != Vector2.ZERO:
		velocity = direction * SPEED * speed_scale
		last_direction = direction
	else:
		velocity = Vector2.ZERO
	
	
	
func process_animation(direction) -> void:
		# Holding the grab pose while standing still; moving cancels it.
		if _pickup_left > 0.0:
			if velocity == Vector2.ZERO:
				return
			_pickup_left = 0.0
		if velocity != Vector2.ZERO:
			play_animation("run", direction)
		else:
				play_animation("idle", direction)
		
func play_animation(prefix: String, dir: Vector2) -> void:
		if dir.x != 0:
			animated_sprite_2d.flip_h = dir.x < 0
			animated_sprite_2d.play(prefix + "_right")
		elif dir.y < 0:
			animated_sprite_2d.play(prefix + "_up")
		elif dir.y > 0:
			animated_sprite_2d.play(prefix + "_down")


# --- Survival systems (Story Beats 1-4: collecting, managing resources) ---

func collect_material(material_type: String, amount: int = 1, item_kind: String = "") -> void:
	match material_type:
		"plastic":
			plastic_count += amount
			lifetime_plastic += amount
			plastic_changed.emit(plastic_count)
		"wood":
			wood_count += amount
			lifetime_wood += amount
			wood_changed.emit(wood_count)
		_:
			return
	if item_kind != "":
		item_collected.emit(material_type, item_kind, amount)
		_on_item_grabbed(item_kind, amount)


func take_damage(amount: int) -> void:
	var mitigated: int = maxi(amount - flood_resistance, 0)
	hp = clampi(hp - mitigated, 0, max_hp)
	hp_changed.emit(hp, max_hp)
	if hp <= 0:
		_on_defeated()


## Instant death (the tidal wave). Ignores armour and max HP.
func die_instantly(cause: String = "") -> void:
	if is_defeated:
		return
	death_cause = cause
	hp = 0
	hp_changed.emit(hp, max_hp)
	_on_defeated()


func heal(amount: int) -> void:
	hp = clampi(hp + amount, 0, max_hp)
	hp_changed.emit(hp, max_hp)


func _on_defeated() -> void:
	if is_defeated:
		return
	is_defeated = true
	animated_sprite_2d.play("dying")
	defeated.emit()


# --- Crafting (Story Beat 4: "creates useful equipment and structures") ---
## recipe is a Dictionary shaped like:
## { id, name, plastic (cost), wood (cost), effect, value, repeatable }
## effect is one of: "heal", "max_hp", "flood_resistance".
func craft(recipe: Dictionary) -> bool:
	var recipe_id: String = recipe.get("id", "")
	var already_owned: bool = crafted_ids.has(recipe_id) and not recipe.get("repeatable", true)
	var plastic_cost: int = recipe.get("plastic", 0)
	var wood_cost: int = recipe.get("wood", 0)

	if already_owned or plastic_count < plastic_cost or wood_count < wood_cost:
		craft_failed.emit(recipe_id)
		return false

	plastic_count -= plastic_cost
	wood_count -= wood_cost
	plastic_changed.emit(plastic_count)
	wood_changed.emit(wood_count)

	_apply_recipe_effect(recipe)
	crafted_ids[recipe_id] = crafted_ids.get(recipe_id, 0) + 1
	item_crafted.emit(recipe_id, recipe.get("name", recipe_id))
	_spawn_crafted_structure(recipe_id)
	return true


func _apply_recipe_effect(recipe: Dictionary) -> void:
	var value: int = recipe.get("value", 0)
	match recipe.get("effect", ""):
		"heal":
			heal(value)
		"max_hp":
			max_hp += value
			heal(value)  # top up by the same amount so crafting always feels rewarding
		"flood_resistance":
			flood_resistance += value
		_:
			pass


## The Beach Shelter / Flood Barrier are really built in front of the character:
## they assemble piece by piece (crafted_structure.gd) while the character crouches
## and works.
func _spawn_crafted_structure(recipe_id: String) -> void:
	if recipe_id != "beach_shelter" and recipe_id != "flood_barrier":
		return
	var parent: Node = get_parent()
	if indoors or parent == null:
		return
	var dir: Vector2 = last_direction
	if absf(dir.x) >= absf(dir.y):
		dir = Vector2(signf(dir.x), 0.0)
	else:
		dir = Vector2(0.0, signf(dir.y))
	if dir == Vector2.ZERO:
		dir = Vector2.DOWN
	var structure = CraftedStructureScript.new()
	structure.kind = recipe_id
	structure.target = self
	parent.add_child(structure)
	structure.global_position = global_position + Vector2(0.0, 24.0) + dir * 150.0
	last_direction = dir
	velocity = Vector2.ZERO
	_pickup_left = 1.6
	play_animation("pickup", dir)


# --- Backpack + grab animation ---

## Swaps every existing frame onto the backpack version of the sprite sheet
## (so the character always wears a backpack) and adds the pickup_* animations.
## player.tscn itself is left untouched.
func _setup_backpack_and_pickup() -> void:
	var frames: SpriteFrames = animated_sprite_2d.sprite_frames
	if frames == null:
		return
	var pack_sheet := load(BACKPACK_SHEET) as Texture2D
	if pack_sheet != null:
		for anim in frames.get_animation_names():
			for i in frames.get_frame_count(anim):
				var atlas := frames.get_frame_texture(anim, i) as AtlasTexture
				if atlas != null:
					atlas.atlas = pack_sheet
	var pickup_sheet := load(PICKUP_SHEET) as Texture2D
	if pickup_sheet == null:
		return
	var facings: Array[String] = ["down", "right", "up"]
	for row in facings.size():
		var anim_name: String = "pickup_" + facings[row]
		if frames.has_animation(anim_name):
			continue
		frames.add_animation(anim_name)
		frames.set_animation_speed(anim_name, PICKUP_FPS)
		frames.set_animation_loop(anim_name, false)
		for col in PICKUP_FRAMES:
			var tex := AtlasTexture.new()
			tex.atlas = pickup_sheet
			tex.region = Rect2(col * 32, row * 32, 32, 32)
			frames.add_frame(anim_name, tex)


## Called for every pickup from the world (bottle / bag / wood).
## Standing still: crouch-and-grab pose. Running: no pose (so movement stays
## responsive), but the item still flies into the backpack and the player bounces.
func _on_item_grabbed(item_kind: String, amount: int = 1) -> void:
	if is_defeated:
		return
	if velocity == Vector2.ZERO:
		_pickup_left = PICKUP_TIME
		play_animation("pickup", last_direction)
	_spawn_item_into_backpack(item_kind)
	_spawn_pickup_text(item_kind, amount)
	_bump_sprite()


## A little copy of the item hops up, then flies into the backpack.
func _spawn_item_into_backpack(item_kind: String) -> void:
	var path: String = ITEM_ICONS.get(item_kind, "")
	if path == "" or not ResourceLoader.exists(path):
		return
	var tex := load(path) as Texture2D
	if tex == null:
		return
	var icon := Sprite2D.new()
	icon.texture = tex
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	icon.scale = Vector2.ONE * (10.0 / float(tex.get_height()))
	var start: Vector2
	var target: Vector2
	if last_direction.x != 0.0:
		var side: float = signf(last_direction.x)
		start = Vector2(side * 7.0, 4.0)
		target = Vector2(-side * 5.0, 1.0)  # the backpack is on the back
	elif last_direction.y < 0.0:
		start = Vector2(0.0, -5.0)
		target = Vector2(0.0, 2.0)
	else:
		start = Vector2(0.0, 8.0)
		target = Vector2(0.0, 1.0)
	icon.position = start
	add_child(icon)
	var tw := create_tween()
	tw.tween_property(icon, "position", start + Vector2(0.0, -6.0), 0.12) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(icon, "position", target, 0.22) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.parallel().tween_property(icon, "scale", icon.scale * 0.35, 0.22)
	tw.tween_callback(icon.queue_free)


## Quick squash-and-stretch once the item lands in the backpack.
func _bump_sprite() -> void:
	if _bump_tween != null and _bump_tween.is_valid():
		_bump_tween.kill()
	animated_sprite_2d.scale = Vector2.ONE
	_bump_tween = create_tween()
	_bump_tween.tween_interval(0.28)
	_bump_tween.tween_property(animated_sprite_2d, "scale", Vector2(1.14, 0.88), 0.06)
	_bump_tween.tween_property(animated_sprite_2d, "scale", Vector2.ONE, 0.12) \
		.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


## A "+1 Bottle" tag floats up from the player and fades out.
func _spawn_pickup_text(item_kind: String, amount: int) -> void:
	var label := Label.new()
	label.text = "+%d %s" % [amount, String(ITEM_NAMES.get(item_kind, item_kind.capitalize()))]
	label.top_level = true  # ignore this node's 4x scale, like NameLabel
	label.z_index = 50
	label.add_theme_font_size_override("font_size", 24)
	label.add_theme_color_override("font_color", Color(0.78, 1.0, 0.66))
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	label.add_theme_constant_override("outline_size", 6)
	add_child(label)
	label.global_position = global_position + Vector2(-34.0, -120.0)
	var rise_to: float = label.global_position.y - 56.0
	var tw := create_tween()
	tw.tween_property(label, "global_position:y", rise_to, 0.8) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(label, "modulate:a", 0.0, 0.5).set_delay(0.3)
	tw.tween_callback(label.queue_free)
