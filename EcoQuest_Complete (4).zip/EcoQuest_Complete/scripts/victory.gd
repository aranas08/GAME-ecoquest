extends CanvasLayer
## victory.gd
## Story Beat 6 ("Resolution / Ending"): shown once the last island in
## IslandManager.ISLANDS has been stabilized. Freezes gameplay, summarises
## the run, and offers a way back to the main menu.

@onready var panel: Panel = %VictoryPanel
@onready var title_label: Label = %VictoryTitle
@onready var message_label: Label = %VictoryMessage
@onready var stats_label: Label = %VictoryStats
@onready var menu_button: Button = %VictoryMenuButton
@onready var keep_playing_button: Button = %KeepPlayingButton
@onready var sfx: AudioStreamPlayer = $SFX

var _shown: bool = false


func _ready() -> void:
	panel.visible = false
	menu_button.pressed.connect(_on_menu_pressed)
	keep_playing_button.pressed.connect(_on_keep_playing_pressed)


func show_victory(player: Node) -> void:
	if _shown:
		return
	_shown = true

	title_label.text = "EVERY ISLAND STABILIZED"
	message_label.text = (
		"%s, you found every ruined coastline on the map and gave it a second chance. "
		+ "The plastic is cleared, the shelters are standing, and the storms "
		+ "finally have somewhere to break."
	) % GameBoot.player_name
	stats_label.text = _build_summary(player)

	panel.visible = true
	sfx.play()
	# Keep this UI responsive while the rest of the game is frozen.
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().paused = true
	menu_button.grab_focus()


func _build_summary(player: Node) -> String:
	var lines: Array[String] = [
		"Islands stabilized:  %d of %d" % [
			IslandManager.islands_stabilized, IslandManager.ISLANDS.size()
		],
		"Hazards survived:  %d" % IslandManager.total_hazards_survived,
		"Hazards failed:  %d" % IslandManager.total_hazards_failed,
	]
	if player != null:
		lines.append("Plastic recovered:  %d" % player.lifetime_plastic)
		lines.append("Wood gathered:  %d" % player.lifetime_wood)
		lines.append("Gear crafted:  %d" % player.crafted_ids.size())
	return "\n".join(lines)


func _on_menu_pressed() -> void:
	GameBoot.return_to_menu()


## Lets the player stay on the final island and keep collecting/crafting
## instead of being forced out of the run.
func _on_keep_playing_pressed() -> void:
	panel.visible = false
	get_tree().paused = false
