extends Control
## main_menu.gd
## The menu the player lands on after the loading screen finishes.
## Buttons: Continue (only when a run is already in progress), New Game,
## How to Play, Settings and Quit.

## The short story clip that plays before a new game starts.
const INTRO_SCENE_PATH := "res://Scenes/intro_story.tscn"

## Fade in from black on arrival / fade to black before entering the game.
const FADE_TIME := 0.4

## Target volume (dB) for the menu theme once it's faded in.
const MUSIC_VOLUME_DB := -8.0

## How much of the vertical crop comes off the TOP of the artwork when the
## window is wider than the image. The logo sits near the top, so most of the
## crop is taken from the bottom. Matches loading_screen.gd.
const CROP_FROM_TOP := 0.25

@onready var background: TextureRect = %Background
@onready var button_column: VBoxContainer = %ButtonColumn
@onready var continue_button: Button = %ContinueButton
@onready var new_game_button: Button = %NewGameButton
@onready var how_to_play_button: Button = %HowToPlayButton
@onready var settings_button: Button = %SettingsButton
@onready var quit_button: Button = %QuitButton
@onready var overlay: Control = %Overlay
@onready var how_to_play_panel: PanelContainer = %HowToPlayPanel
@onready var name_panel: PanelContainer = %NamePanel
@onready var name_input: LineEdit = %NameInput
@onready var begin_button: Button = %BeginButton
@onready var cancel_name_button: Button = %CancelNameButton
@onready var settings_panel: PanelContainer = %SettingsPanel
@onready var quit_confirm_panel: PanelContainer = %QuitConfirmPanel
@onready var confirm_quit_button: Button = %ConfirmQuitButton
@onready var cancel_quit_button: Button = %CancelQuitButton
@onready var close_how_to_play: Button = %CloseHowToPlay
@onready var close_settings: Button = %CloseSettings
@onready var volume_slider: HSlider = %VolumeSlider
@onready var volume_value: Label = %VolumeValue
@onready var fullscreen_button: Button = %FullscreenButton
@onready var fade: ColorRect = %Fade
@onready var music_player: AudioStreamPlayer = %MusicPlayer

var _leaving: bool = false
var _has_run: bool = false


func _ready() -> void:
	_fit_background()
	resized.connect(_fit_background)

	# Continue is only meaningful once a run has actually been started, either
	# this session or (via SaveManager) a previous one. Hidden (not just
	# disabled) when there's nothing to continue, and _fit_button_column()
	# below reflows the column so hiding it doesn't leave an empty gap.
	_has_run = GameBoot.has_continuable_run()
	continue_button.visible = _has_run
	await _fit_button_column()

	# There is nothing to quit to in a browser build.
	quit_button.visible = not OS.has_feature("web")

	continue_button.pressed.connect(_on_continue_pressed)
	new_game_button.pressed.connect(_on_new_game_pressed)
	how_to_play_button.pressed.connect(_on_how_to_play_pressed)
	settings_button.pressed.connect(_on_settings_pressed)
	quit_button.pressed.connect(_on_quit_pressed)
	close_how_to_play.pressed.connect(_close_overlay)
	close_settings.pressed.connect(_close_overlay)
	begin_button.pressed.connect(_on_begin_pressed)
	cancel_name_button.pressed.connect(_close_overlay)
	confirm_quit_button.pressed.connect(func(): get_tree().quit())
	cancel_quit_button.pressed.connect(_close_overlay)
	# Enter in the name box starts the game too.
	name_input.text_submitted.connect(func(_t: String): _on_begin_pressed())

	# Settings reflect the live audio bus / window state.
	var master := AudioServer.get_bus_index("Master")
	var linear: float = db_to_linear(AudioServer.get_bus_volume_db(master))
	volume_slider.value = clampf(linear, 0.0, 1.0)
	_update_volume_label()
	volume_slider.value_changed.connect(_on_volume_changed)

	var mode := DisplayServer.window_get_mode()
	fullscreen_button.button_pressed = (
		mode == DisplayServer.WINDOW_MODE_FULLSCREEN
		or mode == DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN
	)
	_update_fullscreen_label()
	fullscreen_button.toggled.connect(_on_fullscreen_toggled)

	overlay.visible = false
	name_panel.visible = false

	# Keyboard/controller players start on the first visible button.
	if _has_run:
		continue_button.grab_focus()
	else:
		new_game_button.grab_focus()

	fade.color.a = 1.0
	create_tween().tween_property(fade, "color:a", 0.0, FADE_TIME)

	_play_theme()


func _unhandled_input(event: InputEvent) -> void:
	# Escape backs out of an open panel.
	if overlay.visible and event.is_action_pressed("ui_cancel"):
		_close_overlay()
		get_viewport().set_input_as_handled()


func _on_continue_pressed() -> void:
	_leave(func(): return GameBoot.continue_game())


## New Game asks for a survivor name first (design doc 5A).
func _on_new_game_pressed() -> void:
	name_input.text = ""
	_open_panel(name_panel, begin_button)
	name_input.grab_focus()


func _on_begin_pressed() -> void:
	if _leaving:
		return
	GameBoot.set_player_name(name_input.text)
	# Preserve the short story clip before starting gameplay. The intro scene
	# calls GameBoot.start_new_game() when the clip finishes or is skipped.
	_leave(func(): return get_tree().change_scene_to_file(INTRO_SCENE_PATH))


func _on_how_to_play_pressed() -> void:
	_open_panel(how_to_play_panel, close_how_to_play)


func _on_settings_pressed() -> void:
	_open_panel(settings_panel, close_settings)


func _on_quit_pressed() -> void:
	_open_panel(quit_confirm_panel, cancel_quit_button)


func _open_panel(panel: PanelContainer, focus_target: Button) -> void:
	how_to_play_panel.visible = false
	settings_panel.visible = false
	name_panel.visible = false
	quit_confirm_panel.visible = false
	panel.visible = true
	overlay.visible = true
	focus_target.grab_focus()


func _close_overlay() -> void:
	overlay.visible = false
	how_to_play_panel.visible = false
	settings_panel.visible = false
	name_panel.visible = false
	quit_confirm_panel.visible = false
	if _has_run:
		continue_button.grab_focus()
	else:
		new_game_button.grab_focus()


func _on_volume_changed(value: float) -> void:
	var master := AudioServer.get_bus_index("Master")
	# Silence at the very bottom of the slider instead of an enormous negative dB.
	if value <= 0.001:
		AudioServer.set_bus_mute(master, true)
	else:
		AudioServer.set_bus_mute(master, false)
		AudioServer.set_bus_volume_db(master, linear_to_db(value))
	_update_volume_label()


func _update_volume_label() -> void:
	volume_value.text = "%d%%" % int(round(volume_slider.value * 100.0))


func _on_fullscreen_toggled(pressed: bool) -> void:
	DisplayServer.window_set_mode(
		DisplayServer.WINDOW_MODE_FULLSCREEN if pressed else DisplayServer.WINDOW_MODE_WINDOWED
	)
	_update_fullscreen_label()


func _update_fullscreen_label() -> void:
	fullscreen_button.text = "On" if fullscreen_button.button_pressed else "Off"


## Fades to black, then runs the action that swaps scenes.
func _leave(action: Callable) -> void:
	if _leaving:
		return
	_leaving = true
	button_column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(fade, "color:a", 1.0, FADE_TIME)
	tween.tween_property(music_player, "volume_db", MUSIC_VOLUME_DB - 24.0, FADE_TIME)
	tween.set_parallel(false)
	tween.tween_callback(func():
		music_player.stop()
		var err: int = action.call()
		if err != OK:
			_leaving = false
			button_column.mouse_filter = Control.MOUSE_FILTER_STOP
			fade.color.a = 0.0
			music_player.volume_db = MUSIC_VOLUME_DB
			_play_theme()
			push_error("main_menu.gd: could not change scene (error %d)." % err)
	)


## Starts the menu theme from silence and fades it up to its resting volume.
## Playing it here (rather than autoplay on the node) means it starts
## alongside the screen fade-in and can be faded out/stopped cleanly in
## _leave() instead of just cutting off.
func _play_theme() -> void:
	music_player.volume_db = -40.0
	music_player.play()
	create_tween().tween_property(music_player, "volume_db", MUSIC_VOLUME_DB, FADE_TIME * 2.0)


## Resizes ButtonColumn's reserved box to exactly match the height of its
## currently-visible children, keeping it flush with the bottom of the
## screen. Without this, hiding Continue on a fresh game would leave the
## fixed-height box mostly empty, showing as a gap above "New Game".
func _fit_button_column() -> void:
	await get_tree().process_frame
	var total: float = 0.0
	var count := 0
	for child in button_column.get_children():
		if child is Control and child.visible:
			total += child.size.y
			count += 1
	if count > 1:
		total += button_column.get_theme_constant("separation") * (count - 1)
	button_column.offset_top = button_column.offset_bottom - total


## Scales the artwork to cover the whole screen (like CSS "object-fit: cover"),
## so it never shows empty edges at any window shape.
func _fit_background() -> void:
	var tex := background.texture
	if tex == null:
		return
	var tex_size: Vector2 = tex.get_size()
	var scale_factor: float = maxf(size.x / tex_size.x, size.y / tex_size.y)
	var scaled: Vector2 = tex_size * scale_factor
	var extra: Vector2 = scaled - size
	background.size = scaled
	background.position = Vector2(-extra.x * 0.5, -extra.y * CROP_FROM_TOP)
