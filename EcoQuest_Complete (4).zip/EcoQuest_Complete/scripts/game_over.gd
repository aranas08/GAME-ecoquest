extends CanvasLayer
## game_over.gd
## Shown when the player's HP is depleted. Freezes gameplay and offers a
## retry (reload the current island) or a trip back to the main menu.

@onready var panel: Panel = %Panel
@onready var frame: PanelContainer = %Frame
@onready var message_label: Label = %MessageLabel
@onready var retry_button: Button = %RetryButton
@onready var menu_button: Button = %MenuButton
@onready var sfx: AudioStreamPlayer = $SFX


func _ready() -> void:
	# Keep this UI responsive while the rest of the game is paused.
	process_mode = Node.PROCESS_MODE_ALWAYS
	panel.visible = false
	retry_button.pressed.connect(_on_retry_pressed)
	menu_button.pressed.connect(_on_menu_pressed)


func show_game_over(message: String) -> void:
	message_label.text = message
	panel.visible = true
	sfx.play()
	get_tree().paused = true
	retry_button.grab_focus()
	_play_intro()


func _play_intro() -> void:
	# Small fade + pop so the panel lands rather than snapping on.
	var dim: ColorRect = panel.get_node("Dim")
	dim.modulate.a = 0.0
	frame.modulate.a = 0.0

	# Wait for the container to lay out so the pivot lands on the real centre.
	await get_tree().process_frame
	frame.pivot_offset = frame.size / 2.0
	frame.scale = Vector2(0.88, 0.88)

	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(dim, "modulate:a", 1.0, 0.25)
	tween.tween_property(frame, "modulate:a", 1.0, 0.25).set_delay(0.08)
	tween.tween_property(frame, "scale", Vector2.ONE, 0.32) \
		.set_delay(0.08) \
		.set_trans(Tween.TRANS_BACK) \
		.set_ease(Tween.EASE_OUT)


func _on_retry_pressed() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _on_menu_pressed() -> void:
	# GameBoot keeps run_in_progress set, so the menu will offer "Continue"
	# to come back to this island.
	GameBoot.return_to_menu()
