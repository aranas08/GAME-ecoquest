extends Area2D
## collectible_item.gd
## A single collectible material scattered on the island — plastic waste
## (Storyboard Panels 2-3) or crafting materials like wood. `material_type`
## and `amount` are set per-scene (plastic_bottle.tscn, wood_log.tscn, etc.).

signal collected(item: Area2D)

@export var material_type: String = "plastic"
@export var amount: int = 1
## "bottle" / "bag" / "wood" - lets quests count each kind separately.
@export var item_kind: String = ""

var _collected: bool = false

@onready var pickup_sfx: AudioStreamPlayer = get_node_or_null("PickupSFX")


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if _collected:
		return
	if body.is_in_group("player") and body.has_method("collect_material"):
		_collected = true
		body.collect_material(material_type, amount, item_kind)
		collected.emit(self)

		set_deferred("monitoring", false)
		# Hide the art right away so the item reads as picked up, even
		# though the node lives on until the pickup sound finishes.
		var sprite := get_node_or_null("Sprite2D")
		if sprite:
			sprite.hide()
		if pickup_sfx:
			pickup_sfx.play()
			await pickup_sfx.finished
		queue_free()
