extends CanvasLayer
## pause_menu.gd
## In-game pause overlay. Toggle with "ui_cancel" (Escape by default).
## Actually freezes gameplay via get_tree().paused, so this whole node
## (and its children) must keep processing input while paused.

@onready var panel: Panel = %PausePanel
@onready var resume_button: Button = %ResumeButton
@onready var restart_button: Button = %RestartButton
@onready var main_menu_button: Button = %MainMenuButton
@onready var quit_button: Button = %QuitButton


func _ready() -> void:
	# Must keep running while the SceneTree is paused, or this menu could
	# never be closed again once it opens.
	process_mode = Node.PROCESS_MODE_ALWAYS
	panel.visible = false

	resume_button.pressed.connect(_on_resume_pressed)
	restart_button.pressed.connect(_on_restart_pressed)
	main_menu_button.pressed.connect(_on_main_menu_pressed)
	quit_button.pressed.connect(_on_quit_pressed)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if panel.visible:
			_close()
		else:
			_open()
		get_viewport().set_input_as_handled()


func _open() -> void:
	panel.visible = true
	get_tree().paused = true
	resume_button.grab_focus()


func _close() -> void:
	panel.visible = false
	get_tree().paused = false


func _on_resume_pressed() -> void:
	_close()


## Starts a brand-new run from island 1, same as "New Game" on the main menu.
func _on_restart_pressed() -> void:
	get_tree().paused = false
	GameBoot.start_new_game()


func _on_main_menu_pressed() -> void:
	_save_progress()
	get_tree().paused = false
	GameBoot.return_to_menu()


func _on_quit_pressed() -> void:
	_save_progress()
	get_tree().quit()


## Autosaves normally only fire after specific events (surviving a hazard,
## unlocking an island), so without this, backing out here mid-exploration
## would silently lose progress and leave "Continue" greyed out next time.
func _save_progress() -> void:
	var player := get_tree().get_first_node_in_group("player")
	if player:
		SaveManager.save_game(player)
