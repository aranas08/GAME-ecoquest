extends Node2D
## water_life.gd
## Added to the level by base_level.gd (right after water_hazard.gd). Dresses the
## open water with:
##   * rowing boats moored at the shore - step onto one and the polluted water
##     can't hurt you while you stand on the deck,
##   * stepping-stone rocks (some lead out from the boats, some sit in small
##     clusters) - also safe to stand on, so you can hop out across the sea,
##   * wildlife: schools of fish, sea turtles and drifting jellyfish. They stay
##     in deep water and swim away when you get close.
##
## Everything is drawn from the pixel-art tables at the bottom of this file, so
## there are no extra image files to import. water_hazard.gd asks this node
## "covers(pos)" (via the "water_safe" group) before it applies water damage.

const SPRITE_SCALE := 4.0
const CELL := 64.0                    # 16px tiles x the TileMapLayer's scale of 4
const SOURCE_WATER_FULL := 2          # Water_Middle: plain open water
const SHORE_SOURCES := [3, 4]         # Water_Tile (shore edge) and Beach_Tile
const EDGE_MARGIN := 3                # boats keep this many cells inside the map edge
const WILDLIFE_MARGIN := 1            # wildlife may use the thin sea band right at the edge

# Layers (relative to the level). Tilemap is -10, shore decor is -5, player 0.
const Z_CRITTERS := -9
const Z_FOAM := -8
const Z_PLATFORMS := -7

const MAX_BOATS := 3
const BOAT_MIN_SEPARATION := 12       # cells between moored boats
const BOAT_SHIFT := 36.0              # px the boat sits toward the shore, so it overlaps the bank
const BOAT_HALF_LENGTH := 56.0
const DECK_HALF_LENGTH := 52.0
const DECK_HALF_WIDTH := 20.0
const TRAIL_STONES := Vector2i(3, 4)  # min / max stepping stones leading out from each boat
const STONE_OVERLAP := 14.0
const FLEE_RADIUS := 230.0

var _level: Node2D
var _tilemap: TileMapLayer
var _player: CharacterBody2D
var _shape: CollisionShape2D

var _deep: Dictionary = {}            # Vector2i -> true: open-water cells (the 4 cells beside them are water too)
var _deep_cells: Array[Vector2i] = []
var _boats: Array[Dictionary] = []    # {sprite, rect, base_pos, base_rot, flip, phase, dip, dir, cell}
var _stones: Array[Dictionary] = []   # {pos, rx, ry, phase}
var _schools: Array[Dictionary] = []  # {target, timer}
var _critters: Array[Dictionary] = []
var _time := 0.0

var _foam: Node2D
var _layer_critters: Node2D
var _layer_platforms: Node2D

static var _tex_cache: Dictionary = {}


func setup(level: Node2D, tilemap: TileMapLayer, player: CharacterBody2D) -> void:
	_level = level
	_tilemap = tilemap
	_player = player
	_shape = player.get_node_or_null("CollisionShape2D") as CollisionShape2D
	add_to_group("water_safe")
	tilemap.z_index = -10   # make sure everything below sits above the ground tiles

	_layer_critters = Node2D.new()
	_layer_critters.name = "Wildlife"
	_layer_critters.z_index = Z_CRITTERS
	add_child(_layer_critters)

	_foam = Node2D.new()
	_foam.name = "Foam"
	_foam.z_index = Z_FOAM
	_foam.draw.connect(_draw_foam)
	add_child(_foam)

	_layer_platforms = Node2D.new()
	_layer_platforms.name = "Platforms"
	_layer_platforms.z_index = Z_PLATFORMS
	add_child(_layer_platforms)

	_scan_water()
	if _deep_cells.size() < 12:
		return
	_place_boats()
	_place_rock_clusters()
	_spawn_wildlife()


# --- Public: used by water_hazard.gd -------------------------------------------

## True when `world_pos` (the player's feet) is on a boat deck or a stepping stone.
func covers(world_pos: Vector2) -> bool:
	for b in _boats:
		var rect: Rect2 = b.rect
		if rect.has_point(world_pos):
			return true
	for s in _stones:
		var d: Vector2 = world_pos - s.pos
		var rx: float = s.rx
		var ry: float = s.ry
		if (d.x * d.x) / (rx * rx) + (d.y * d.y) / (ry * ry) <= 1.0:
			return true
	return false


# --- Map helpers -----------------------------------------------------------------

func _cell_at(world_pos: Vector2) -> Vector2i:
	return _tilemap.local_to_map(_tilemap.to_local(world_pos))


func _cell_center(cell: Vector2i) -> Vector2:
	return _tilemap.to_global(_tilemap.map_to_local(cell))


func _is_full_water(cell: Vector2i) -> bool:
	return _tilemap.get_cell_source_id(cell) == SOURCE_WATER_FULL


func _scan_water() -> void:
	_deep.clear()
	_deep_cells.clear()
	var used: Rect2i = _tilemap.get_used_rect()
	var dirs: Array[Vector2i] = [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]
	for x in range(used.position.x + WILDLIFE_MARGIN, used.end.x - WILDLIFE_MARGIN):
		for y in range(used.position.y + WILDLIFE_MARGIN, used.end.y - WILDLIFE_MARGIN):
			var c := Vector2i(x, y)
			if not _is_full_water(c):
				continue
			var all_water := true
			for d in dirs:
				if not _is_full_water(c + d):
					all_water = false
			if all_water:
				_deep[c] = true
				_deep_cells.append(c)


func _is_deep_at(world_pos: Vector2) -> bool:
	return _deep.has(_cell_at(world_pos))


func _is_water_at(world_pos: Vector2) -> bool:
	return _is_full_water(_cell_at(world_pos))


## True when a stone of this size would sit entirely on plain open water.
func _stone_fits(pos: Vector2, variant: String) -> bool:
	var r: Vector2 = _stone_radii(variant)
	for off in [Vector2.ZERO, Vector2(r.x, 0), Vector2(-r.x, 0), Vector2(0, r.y), Vector2(0, -r.y)]:
		if not _is_water_at(pos + off):
			return false
	return true


func _line_is_water(a: Vector2, b: Vector2) -> bool:
	var steps: int = maxi(1, int(ceil(a.distance_to(b) / 32.0)))
	for i in range(0, steps + 1):
		if not _is_water_at(a.lerp(b, float(i) / float(steps))):
			return false
	return true


func _line_is_deep(a: Vector2, b: Vector2) -> bool:
	var steps: int = maxi(1, int(ceil(a.distance_to(b) / 32.0)))
	for i in range(1, steps + 1):
		if not _is_deep_at(a.lerp(b, float(i) / float(steps))):
			return false
	return true


func _pick_target(from: Vector2, reach_cells: int) -> Vector2:
	var here: Vector2i = _cell_at(from)
	for attempt in 14:
		var cell: Vector2i = here + Vector2i(randi_range(-reach_cells, reach_cells), randi_range(-reach_cells, reach_cells))
		if not _deep.has(cell):
			continue
		var p: Vector2 = _cell_center(cell) + Vector2(randf_range(-22.0, 22.0), randf_range(-22.0, 22.0))
		if _line_is_deep(from, p):
			return p
	return from


func _player_feet() -> Vector2:
	if _shape:
		return _shape.global_position + Vector2(0, 24)
	return _player.global_position + Vector2(0, 40)


# --- Boats -----------------------------------------------------------------------

func _find_dock_candidates() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	var dirs: Array[Vector2i] = [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]
	var used: Rect2i = _tilemap.get_used_rect()
	for x in range(used.position.x + EDGE_MARGIN, used.end.x - EDGE_MARGIN):
		for y in range(used.position.y + EDGE_MARGIN, used.end.y - EDGE_MARGIN):
			var c := Vector2i(x, y)
			if not _is_full_water(c):
				continue
			for d in dirs:
				if not (_tilemap.get_cell_source_id(c + d) in SHORE_SOURCES):
					continue
				var side: Vector2i = Vector2i(d.y, d.x)
				if _is_full_water(c - d) and _is_full_water(c + side) and _is_full_water(c - side):
					out.append({"cell": c, "dir": d})
	return out


func _place_boats() -> void:
	var candidates: Array[Dictionary] = _find_dock_candidates()
	candidates.shuffle()
	var chosen: Array[Vector2i] = []
	for cand in candidates:
		if _boats.size() >= MAX_BOATS:
			break
		var cell: Vector2i = cand.cell
		var too_close := false
		for other in chosen:
			if Vector2(cell - other).length() < float(BOAT_MIN_SEPARATION):
				too_close = true
		if too_close:
			continue
		chosen.append(cell)
		_add_boat(cell, cand.dir)


func _add_boat(cell: Vector2i, shore_dir: Vector2i) -> void:
	var toward_shore: Vector2 = Vector2(shore_dir)
	var bow_dir: Vector2 = -toward_shore   # bow points out to sea, stern at the bank
	var center: Vector2 = _cell_center(cell) + toward_shore * BOAT_SHIFT

	var sprite := Sprite2D.new()
	sprite.texture = _tex("boat")
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.centered = true
	sprite.scale = Vector2(SPRITE_SCALE, SPRITE_SCALE)
	var base_rot := 0.0
	var flip := false
	if shore_dir.y == 0:
		flip = bow_dir.x < 0.0
		if flip:
			sprite.scale.x = -SPRITE_SCALE
	else:
		base_rot = PI * 0.5 if bow_dir.y > 0.0 else -PI * 0.5
	sprite.rotation = base_rot
	_layer_platforms.add_child(sprite)
	sprite.global_position = center

	var half := Vector2(DECK_HALF_LENGTH, DECK_HALF_WIDTH)
	if shore_dir.y != 0:
		half = Vector2(DECK_HALF_WIDTH, DECK_HALF_LENGTH)
	_boats.append({
		"sprite": sprite,
		"rect": Rect2(center - half, half * 2.0),
		"base_pos": center,
		"base_rot": base_rot,
		"phase": randf() * TAU,
		"dip": 0.0,
		"dir": shore_dir,
		"cell": cell,
	})
	_add_trail(center, bow_dir)


## A line of stepping stones leading from the boat's bow out into open water.
func _add_trail(boat_center: Vector2, bow_dir: Vector2) -> void:
	var horizontal: bool = absf(bow_dir.x) > 0.5
	var perp: Vector2 = Vector2(bow_dir.y, bow_dir.x)
	var along: float = BOAT_HALF_LENGTH
	var prev_radius: float = 0.0
	var count: int = randi_range(TRAIL_STONES.x, TRAIL_STONES.y)
	for i in count:
		var variant: String = ["rockA", "rockB", "rockC", "rockD"].pick_random()
		var dims: Vector2 = _stone_radii(variant)
		var axis_r: float = dims.x if horizontal else dims.y
		if i == 0:
			along += axis_r * 0.6
		else:
			along += prev_radius + axis_r - STONE_OVERLAP
		prev_radius = axis_r
		var pos: Vector2 = boat_center + bow_dir * along + perp * randf_range(-8.0, 8.0)
		if not _stone_fits(pos, variant) or not _line_is_water(boat_center + bow_dir * (BOAT_HALF_LENGTH + 8.0), pos):
			break
		_add_stone(pos, variant)


# --- Rocks -----------------------------------------------------------------------

func _stone_radii(variant: String) -> Vector2:
	var tex: ImageTexture = _tex(variant)
	# A little bigger than the art so landing on a rock is forgiving.
	return Vector2(tex.get_width() * SPRITE_SCALE * 0.5 + 6.0, tex.get_height() * SPRITE_SCALE * 0.5 + 10.0)


func _add_stone(pos: Vector2, variant: String) -> void:
	var sprite := Sprite2D.new()
	sprite.texture = _tex(variant)
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.scale = Vector2(SPRITE_SCALE, SPRITE_SCALE)
	sprite.flip_h = randf() < 0.5
	_layer_platforms.add_child(sprite)
	sprite.global_position = pos
	var radii: Vector2 = _stone_radii(variant)
	_stones.append({"pos": pos, "rx": radii.x, "ry": radii.y, "phase": randf() * TAU})


## Small islets of 2-3 rocks out in the open sea.
func _place_rock_clusters() -> void:
	var wanted: int = clampi(_deep_cells.size() / 150, 3, 8)
	var centres: Array[Vector2] = []
	for b in _boats:
		centres.append(b.base_pos)
	var tries := 0
	while wanted > 0 and tries < 300:
		tries += 1
		var cell: Vector2i = _deep_cells[randi() % _deep_cells.size()]
		var c: Vector2 = _cell_center(cell)
		var far_enough := true
		for other in centres:
			if c.distance_to(other) < CELL * 6.0:
				far_enough = false
		if not far_enough:
			continue
		centres.append(c)
		wanted -= 1
		var members: int = randi_range(2, 3)
		var angle: float = randf() * TAU
		for m in members:
			var variant: String = ["rockA", "rockB", "rockC", "rockD"].pick_random()
			var pos: Vector2 = c + Vector2.from_angle(angle + float(m) * TAU / float(members)) * (0.0 if members == 1 else randf_range(34.0, 52.0))
			if _stone_fits(pos, variant):
				_add_stone(pos, variant)


# --- Wildlife --------------------------------------------------------------------

func _spawn_wildlife() -> void:
	var n: int = _deep_cells.size()
	for i in clampi(n / 70, 3, 7):
		_spawn_school()
	for i in clampi(n / 160, 1, 3):
		_spawn_turtle()
	for i in clampi(n / 110, 2, 6):
		_spawn_jelly()


func _random_water_spot() -> Vector2:
	var cell: Vector2i = _deep_cells[randi() % _deep_cells.size()]
	return _cell_center(cell) + Vector2(randf_range(-20.0, 20.0), randf_range(-20.0, 20.0))


func _make_critter_sprite(tex: Texture2D) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = tex
	s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	s.scale = Vector2(SPRITE_SCALE, SPRITE_SCALE)
	_layer_critters.add_child(s)
	return s


func _spawn_school() -> void:
	var home: Vector2 = _random_water_spot()
	var school_id: int = _schools.size()
	_schools.append({"target": home, "timer": randf_range(1.0, 4.0)})
	var kind: String = ["fish_orange", "fish_silver", "fish_yellow"].pick_random()
	var members: int = randi_range(3, 5)
	for i in members:
		var offset := Vector2(randf_range(-70.0, 70.0), randf_range(-50.0, 50.0))
		var pos: Vector2 = home + offset
		if not _is_deep_at(pos):
			pos = home
		var sprite: Sprite2D = _make_critter_sprite(_tex(kind))
		sprite.global_position = pos
		_critters.append({
			"kind": "fish", "sprite": sprite, "pos": pos, "vel": Vector2.ZERO,
			"speed": randf_range(70.0, 105.0), "school": school_id, "offset": offset * 0.6,
			"phase": randf() * TAU,
		})


func _spawn_turtle() -> void:
	var pos: Vector2 = _random_water_spot()
	var sprite: Sprite2D = _make_critter_sprite(_tex("turtle0"))
	sprite.global_position = pos
	_critters.append({
		"kind": "turtle", "sprite": sprite, "pos": pos, "vel": Vector2.ZERO,
		"speed": randf_range(34.0, 46.0), "target": _pick_target(pos, 6), "pause": 0.0,
		"anim": randf() * 1.0, "frame": 0, "heading": 0.0,
	})


func _spawn_jelly() -> void:
	var pos: Vector2 = _random_water_spot()
	var sprite: Sprite2D = _make_critter_sprite(_tex("jelly0"))
	sprite.modulate = Color(1, 1, 1, 0.9)
	sprite.global_position = pos
	_critters.append({
		"kind": "jelly", "sprite": sprite, "pos": pos, "vel": Vector2.ZERO,
		"speed": randf_range(16.0, 26.0), "target": _pick_target(pos, 4), "pause": randf_range(0.0, 2.0),
		"anim": randf() * 1.0, "frame": 0, "phase": randf() * TAU,
	})


# --- Per-frame -------------------------------------------------------------------

func _process(delta: float) -> void:
	if _player == null or _tilemap == null:
		return
	_time += delta
	var player_pos: Vector2 = _player.global_position
	_update_schools(delta)
	for c in _critters:
		match String(c.kind):
			"fish":
				_update_fish(c, delta, player_pos)
			"turtle":
				_update_turtle(c, delta, player_pos)
			"jelly":
				_update_jelly(c, delta)
	_update_boats(delta)
	_foam.queue_redraw()


func _update_schools(delta: float) -> void:
	for s in _schools:
		s.timer -= delta
		if s.timer <= 0.0:
			s.timer = randf_range(3.0, 6.5)
			s.target = _pick_target(s.target, 7)


func _update_fish(c: Dictionary, delta: float, player_pos: Vector2) -> void:
	var school: Dictionary = _schools[c.school]
	var goal: Vector2 = Vector2(school.target) + Vector2(c.offset)
	var pos: Vector2 = c.pos
	var to_goal: Vector2 = goal - pos
	var speed: float = c.speed
	var desired: Vector2 = Vector2.ZERO
	if to_goal.length() > 14.0:
		desired = to_goal.normalized() * speed
	else:
		desired = Vector2.from_angle(_time + float(c.phase)) * speed * 0.2
	var away: Vector2 = pos - player_pos
	if away.length() < FLEE_RADIUS and away.length() > 0.1:
		desired = away.normalized() * speed * 2.1
	var vel: Vector2 = c.vel
	vel = vel.lerp(desired, clampf(delta * 3.5, 0.0, 1.0))
	var next_pos: Vector2 = pos + vel * delta
	if _is_deep_at(next_pos):
		pos = next_pos
	else:
		var back: Vector2 = _cell_center(_cell_at(pos)) - pos
		vel = back.normalized() * speed if back.length() > 1.0 else Vector2.ZERO
		school.timer = 0.0
	c.pos = pos
	c.vel = vel
	var sprite: Sprite2D = c.sprite
	sprite.global_position = pos + Vector2(0.0, sin(_time * 5.0 + float(c.phase)) * 1.5)
	_face_fish(sprite, vel)


func _face_fish(sprite: Sprite2D, vel: Vector2) -> void:
	if vel.length() < 4.0:
		return
	if vel.x >= 0.0:
		sprite.scale = Vector2(SPRITE_SCALE, SPRITE_SCALE)
		sprite.rotation = clampf(atan2(vel.y, vel.x), -0.7, 0.7)
	else:
		sprite.scale = Vector2(-SPRITE_SCALE, SPRITE_SCALE)
		sprite.rotation = clampf(atan2(-vel.y, -vel.x), -0.7, 0.7)


func _update_turtle(c: Dictionary, delta: float, player_pos: Vector2) -> void:
	var pos: Vector2 = c.pos
	var vel: Vector2 = c.vel
	var speed: float = c.speed
	if float(c.pause) > 0.0:
		c.pause = float(c.pause) - delta
		vel = vel.lerp(Vector2.ZERO, clampf(delta * 2.0, 0.0, 1.0))
	else:
		var to_target: Vector2 = Vector2(c.target) - pos
		if to_target.length() < 24.0:
			c.pause = randf_range(1.0, 3.5)
			c.target = _pick_target(pos, 6)
		else:
			var desired: Vector2 = to_target.normalized() * speed
			var away: Vector2 = pos - player_pos
			if away.length() < FLEE_RADIUS * 0.7 and away.length() > 0.1:
				desired = away.normalized() * speed * 1.8
			vel = vel.lerp(desired, clampf(delta * 1.5, 0.0, 1.0))
	var next_pos: Vector2 = pos + vel * delta
	if _is_deep_at(next_pos):
		pos = next_pos
	else:
		vel = Vector2.ZERO
		c.target = _pick_target(pos, 6)
		c.pause = 0.5
	c.pos = pos
	c.vel = vel
	var sprite: Sprite2D = c.sprite
	sprite.global_position = pos + Vector2(0.0, sin(_time * 1.6 + float(c.anim) * 6.0) * 1.5)
	if vel.length() > 3.0:
		c.heading = lerp_angle(float(c.heading), vel.angle(), clampf(delta * 3.0, 0.0, 1.0))
	sprite.rotation = float(c.heading)
	# Flipper paddling.
	c.anim = float(c.anim) + delta * (1.6 if vel.length() > 3.0 else 0.5)
	var frame: int = int(floor(float(c.anim) * 2.0)) % 2
	if frame != int(c.frame):
		c.frame = frame
		sprite.texture = _tex("turtle%d" % frame)


func _update_jelly(c: Dictionary, delta: float) -> void:
	var pos: Vector2 = c.pos
	var vel: Vector2 = c.vel
	if float(c.pause) > 0.0:
		c.pause = float(c.pause) - delta
	else:
		var to_target: Vector2 = Vector2(c.target) - pos
		if to_target.length() < 20.0:
			c.pause = randf_range(0.5, 2.5)
			c.target = _pick_target(pos, 4)
		else:
			vel = vel.lerp(to_target.normalized() * float(c.speed), clampf(delta * 1.2, 0.0, 1.0))
	vel = vel.lerp(Vector2.ZERO, clampf(delta * 0.35, 0.0, 1.0))
	var next_pos: Vector2 = pos + vel * delta
	if _is_deep_at(next_pos):
		pos = next_pos
	else:
		vel = Vector2.ZERO
		c.target = _pick_target(pos, 4)
	c.pos = pos
	c.vel = vel
	c.anim = float(c.anim) + delta * 1.3
	var pulse: float = sin(_time * 3.2 + float(c.phase))
	var sprite: Sprite2D = c.sprite
	sprite.global_position = pos + Vector2(0.0, pulse * 4.0)
	sprite.scale = Vector2(SPRITE_SCALE * (1.0 + pulse * 0.05), SPRITE_SCALE * (1.0 - pulse * 0.06))
	var frame: int = int(floor(float(c.anim) * 2.0)) % 2
	if frame != int(c.frame):
		c.frame = frame
		sprite.texture = _tex("jelly%d" % frame)


func _update_boats(delta: float) -> void:
	var feet: Vector2 = _player_feet()
	for b in _boats:
		var rect: Rect2 = b.rect
		var target_dip: float = 1.0 if (rect.has_point(feet) and not _player.is_defeated) else 0.0
		b.dip = lerpf(float(b.dip), target_dip, clampf(delta * 6.0, 0.0, 1.0))
		var sprite: Sprite2D = b.sprite
		var base_pos: Vector2 = b.base_pos
		var phase: float = b.phase
		sprite.global_position = base_pos + Vector2(0.0, sin(_time * 1.6 + phase) * 2.0 + float(b.dip) * 4.0)
		sprite.rotation = float(b.base_rot) + sin(_time * 1.1 + phase) * 0.022


# --- Foam rings around boats and rocks ---------------------------------------------

func _ellipse_pts(c: Vector2, rx: float, ry: float, closed: bool = false, n: int = 28) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in (n + 1 if closed else n):
		var a: float = TAU * float(i) / float(n)
		pts.append(c + Vector2(cos(a) * rx, sin(a) * ry))
	return pts


func _draw_foam() -> void:
	for s in _stones:
		var c: Vector2 = _foam.to_local(s.pos)
		var wob: float = sin(_time * 1.8 + float(s.phase)) * 2.0
		var rx: float = float(s.rx)
		var ry: float = float(s.ry)
		_foam.draw_colored_polygon(_ellipse_pts(c, rx + 7.0 + wob, ry + 5.0 + wob * 0.6), Color(0.0, 0.8, 0.98, 0.35))
		_foam.draw_polyline(_ellipse_pts(c, rx + 5.0 + wob, ry + 3.0 + wob * 0.6, true), Color(1, 1, 1, 0.6), 2.0)
	for b in _boats:
		var rect: Rect2 = b.rect
		var c: Vector2 = _foam.to_local(rect.get_center())
		var wob: float = sin(_time * 1.6 + float(b.phase)) * 2.5
		var vertical: bool = Vector2i(b.dir).y != 0
		var rx: float = 70.0 if not vertical else 40.0
		var ry: float = 40.0 if not vertical else 70.0
		_foam.draw_colored_polygon(_ellipse_pts(c, rx + 6.0 + wob, ry + 6.0 + wob), Color(0.0, 0.8, 0.98, 0.35))
		_foam.draw_polyline(_ellipse_pts(c, rx + 4.0 + wob, ry + 4.0 + wob, true), Color(1, 1, 1, 0.55), 2.0)
		# Mooring rope from the stern to the bank.
		var toward_shore: Vector2 = Vector2(Vector2i(b.dir))
		var stern: Vector2 = c + toward_shore * (DECK_HALF_LENGTH - 6.0)
		var bank: Vector2 = c + toward_shore * (DECK_HALF_LENGTH + 22.0)
		var mid: Vector2 = (stern + bank) * 0.5 + Vector2(0.0, 7.0)
		_foam.draw_polyline(PackedVector2Array([stern, mid, bank]), Color(0.93, 0.87, 0.7), 3.0)


# --- Pixel art ---------------------------------------------------------------------

static func _tex(key: String) -> ImageTexture:
	if _tex_cache.has(key):
		return _tex_cache[key]
	var rows: Array = ART[key]
	var pal: Dictionary = PALETTES[PALETTE_OF[key]]
	var h: int = rows.size()
	var w: int = String(rows[0]).length()
	var img: Image = Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	for y in h:
		var row: String = rows[y]
		for x in w:
			var ch: String = row.substr(x, 1)
			if pal.has(ch):
				img.set_pixel(x, y, Color.html(String(pal[ch])))
	var tex: ImageTexture = ImageTexture.create_from_image(img)
	_tex_cache[key] = tex
	return tex


# Pixel art: one string per row, '.' = transparent. Each art pixel is drawn 4x4 on screen.
# Palettes are hex colours. (tools/water_life_art.py is the script these rows came from.)
const ART := {
	"boat": [
		"..ooooooooooooooooooooooo.....",
		"..oHHHHHHHHHHHHHHHHHHHHHHoo...",
		"ooHdpdddSSddpdddSSddpddddHHo..",
		"oHddpdddSSdOOOOOOOOOpddddddHo.",
		"oHddpdddSSddpdddSSddpddddddHo.",
		"oHddrrddSSddpdddSSddpddddddHo.",
		"oHddprddSSddpdddSSddpdddddddHo",
		"oHddrrddSSddpdddSSddpddddddHo.",
		"oHddpdddSSddpdddSSddpddddddHo.",
		"oHddpdddSSddpdddSSddpddddddHo.",
		"ooHdpdddSSddpdddSSddpddddHHo..",
		"..oHHHHHHHHHHHHHHHHHHHHHHoo...",
		"..ooooooooooooooooooooooo.....",
	],
	"fish_orange": [
		"....ooo....",
		"oo.oBBBBo..",
		"ooBBBBBwBo.",
		"ooBBBBBBBoo",
		"oo.oLLLLo..",
		"....ooo....",
	],
	"fish_silver": [
		"....ooo....",
		"oo.oBBBBo..",
		"ooBBBBBwBo.",
		"ooBBBBBBBoo",
		"oo.oLLLLo..",
		"....ooo....",
	],
	"fish_yellow": [
		"....ooo....",
		"oo.oBBBBo..",
		"ooBBBBBwBo.",
		"ooBBBBBBBoo",
		"oo.oLLLLo..",
		"....ooo....",
	],
	"jelly0": [
		"..JJJJJ..",
		".JWWJJJJ.",
		"oJWJJJJJo",
		"oJJJJJJJo",
		".KKKKKKK.",
		"..T..T.T.",
		"...T.TT..",
		"...TT.T..",
		"..T.T..T.",
		"..t..t.t.",
		"...t.tt..",
	],
	"jelly1": [
		"..JJJJJ..",
		".JWWJJJJ.",
		"oJWJJJJJo",
		"oJJJJJJJo",
		".KKKKKKK.",
		"...T.TT..",
		"...TT.T..",
		"..T.T..T.",
		"..T..T.T.",
		"...t.tt..",
		"...tt.t..",
	],
	"turtle0": [
		"fffn......nfffn",
		"nfffn.OO.nfffn.",
		".nnnOOssOOnnn..",
		"...OlscslsO....",
		"..OsscscsssOnn.",
		"nnOssscssssOhwn",
		"ffOscssscssOhhh",
		"nnOssscssssOhhn",
		"..OsscscsssOnn.",
		"...OsscsssO....",
		".nnnOOssOOnnn..",
		"nfffn.OO.nfffn.",
		"fffn......nfffn",
	],
	"turtle1": [
		".nnn......nnn..",
		"nfffn.OO.nfffn.",
		".nnnOOssOOnnn..",
		"...OlscslsO....",
		"..OsscscsssOnn.",
		"nnOssscssssOhwn",
		"ffOscssscssOhhh",
		"nnOssscssssOhhn",
		"..OsscscsssOnn.",
		"...OsscsssO....",
		".nnnOOssOOnnn..",
		"nfffn.OO.nfffn.",
		".nnn......nnn..",
	],
	"rockA": [
		"...ooooooo......",
		"...oLLLLLLooo...",
		"..oLLLDLmmmmmo..",
		"..oLLLmDmmmmmmo.",
		".oLLmmmmDmmmmmmo",
		"oLmmmmmmmmmmDDDo",
		"ommmmmmmmmmDDDDo",
		".ommmmmmmDDDDooo",
		"..oommmDDoooo...",
		"....ooooo.......",
	],
	"rockB": [
		"...ooooooo...",
		"..oLLLLLmmo..",
		"..oLLmmmmmo..",
		"ooLDDmmmmmmo.",
		"ommmmDDDmmmDo",
		"ommmmmmmDDDDo",
		".oooomDDoooo.",
		".....ooo.....",
	],
	"rockC": [
		"....ooooooo.......",
		"...oLLLLGGLoo.....",
		"..oLGLGLGLmGmooo..",
		".oLLLLLmmGmGmGmmoo",
		".oLLLmmmGmmGGmmmmo",
		".oLmGmmmGGmDDDGmGo",
		".ommGmDDDmmGGGGGDo",
		"..ommmmmmmmmDDDDo.",
		"..ommmmmmmDDDDDo..",
		"..ommmmmDoooooo...",
		"...oooooo.........",
	],
	"rockD": [
		"..oooooo...",
		".oLLLLmmo..",
		".oLDDDmmmoo",
		".ommmmDDDmo",
		"ommmmmmmDoo",
		".ommmmDoo..",
		"..ooooo....",
	],
}
const PALETTE_OF := {
	"boat": "boat",
	"fish_orange": "fish_orange",
	"fish_silver": "fish_silver",
	"fish_yellow": "fish_yellow",
	"jelly0": "jelly",
	"jelly1": "jelly",
	"turtle0": "turtle",
	"turtle1": "turtle",
	"rockA": "rock",
	"rockB": "rock",
	"rockC": "rock",
	"rockD": "rock",
}
const PALETTES := {
	"boat": {"o": "#3b2210", "H": "#9a6430", "d": "#e0b36e", "p": "#c48f4e", "S": "#8a5526", "r": "#f1e6c8", "O": "#6b4220"},
	"fish_orange": {"o": "#5a2208", "B": "#ff8a2a", "L": "#ffd49a", "w": "#ffffff"},
	"fish_silver": {"o": "#0c2c4a", "B": "#9fc3e0", "L": "#e8f4ff", "w": "#ffffff"},
	"fish_yellow": {"o": "#4a3a06", "B": "#ffd23a", "L": "#fff3b0", "w": "#ffffff"},
	"jelly": {"J": "#f3a6e8", "K": "#c273d6", "W": "#ffffff", "o": "#7a3a96", "T": "#e58bd9", "t": "#f6c3ef"},
	"turtle": {"s": "#4fa86a", "O": "#1d5a38", "c": "#2f7d4c", "l": "#7fd08e", "f": "#6fbf7a", "h": "#7fcf86", "w": "#ffffff", "n": "#17482d"},
	"rock": {"o": "#2b2e36", "m": "#8d939e", "L": "#b9bfc9", "D": "#666c78", "G": "#5fa04a"},
}
