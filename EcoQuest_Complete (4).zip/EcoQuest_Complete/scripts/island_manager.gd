extends Node
## island_manager.gd (Autoload: IslandManager)
## Multi-island progression (Story Beat 6: "the player continues their
## journey with new environmental problems... each island increases in
## difficulty as the player progresses").
##
## Every island now has its OWN map: `terrain_scene` points at a scene under
## Scenes/levels/islands/ containing a TileMapLayer plus two Marker2D nodes
## (PlayerStart, MayaSpot). base_level.gd swaps that terrain in when the level
## loads. Open those scenes in the editor to repaint an island with the
## TileMap tool - the shared tileset is assets/tilesets/eco_tileset.tres.
## `tint` is only a very light mood colour on top of the real tiles now.

signal island_changed(island: Dictionary)
signal island_unlocked_next(island: Dictionary)

const ISLANDS: Array[Dictionary] = [
	{
		"id": "beach", "name": "Plastic Beach",
		"terrain_scene": "res://Scenes/levels/islands/island_1_beach.tscn",
		"hazard": "flood", "tint": Color(1, 1, 1),
		"intro": "This island has been badly damaged.",
		"quests_to_unlock": 2, "difficulty": 1.0,
	},
	{
		"id": "forest", "name": "Deforested Woods",
		"terrain_scene": "res://Scenes/levels/islands/island_2_forest.tscn",
		"hazard": "storm", "tint": Color(0.96, 1.0, 0.94),
		"intro": "The trees here have been cut down. Storms hit harder without them.",
		"quests_to_unlock": 2, "difficulty": 1.15,
	},
	{
		"id": "river", "name": "Polluted River Delta",
		"terrain_scene": "res://Scenes/levels/islands/island_3_river.tscn",
		"hazard": "flood", "tint": Color(0.95, 0.98, 1.0),
		"intro": "The river is choked with waste. Flash floods are common here.",
		"quests_to_unlock": 2, "difficulty": 1.3,
	},
	{
		"id": "village", "name": "Abandoned Village",
		"terrain_scene": "res://Scenes/levels/islands/island_4_village.tscn",
		"hazard": "storm", "tint": Color(1.0, 0.97, 0.92),
		"intro": "This village was abandoned after repeated storms.",
		"quests_to_unlock": 2, "difficulty": 1.45,
	},
	{
		"id": "mountain", "name": "Barren Mountain",
		"terrain_scene": "res://Scenes/levels/islands/island_5_mountain.tscn",
		"hazard": "heat", "tint": Color(1.0, 0.95, 0.88),
		"intro": "The mountain is barren and exposed. The heat here is dangerous.",
		"quests_to_unlock": 3, "difficulty": 1.6,
	},
]

var current_index: int = 0
var quests_completed_this_island: int = 0
var saved_player_state: Dictionary = {}

## Run-wide totals, used by the ending screen (Story Beat 6, "Resolution").
var total_hazards_survived: int = 0
var total_hazards_failed: int = 0
var islands_stabilized: int = 0


func current_island() -> Dictionary:
	return ISLANDS[current_index]


func save_player_state(player: Node) -> void:
	saved_player_state = {
		"lifetime_plastic": player.lifetime_plastic,
		"lifetime_wood": player.lifetime_wood,
		"hp": player.hp,
		"max_hp": player.max_hp,
		"plastic_count": player.plastic_count,
		"wood_count": player.wood_count,
		"flood_resistance": player.flood_resistance,
		"crafted_ids": player.crafted_ids.duplicate(),
	}


func has_saved_state() -> bool:
	return not saved_player_state.is_empty()


func apply_saved_state(player: Node) -> void:
	if saved_player_state.is_empty():
		return
	player.max_hp = saved_player_state.max_hp
	player.hp = saved_player_state.hp
	player.plastic_count = saved_player_state.plastic_count
	player.wood_count = saved_player_state.wood_count
	player.flood_resistance = saved_player_state.flood_resistance
	player.crafted_ids = saved_player_state.crafted_ids.duplicate()
	player.lifetime_plastic = saved_player_state.get("lifetime_plastic", 0)
	player.lifetime_wood = saved_player_state.get("lifetime_wood", 0)


func register_success() -> bool:
	## Call after a hazard challenge is successfully completed.
	## Returns true if this unlocks progression to the next island.
	quests_completed_this_island += 1
	total_hazards_survived += 1
	var island := current_island()
	var unlocked: bool = quests_completed_this_island >= island.quests_to_unlock
	if unlocked:
		islands_stabilized = maxi(islands_stabilized, current_index + 1)
		island_unlocked_next.emit(island)
	return unlocked


func register_failure() -> void:
	## Call after a hazard challenge is failed, for the end-of-run summary.
	total_hazards_failed += 1


func is_current_island_stabilized() -> bool:
	## True once enough hazards have been survived on this island.
	return quests_completed_this_island >= current_island().quests_to_unlock


func is_final_island_complete() -> bool:
	## True once the last island in the list has been stabilized.
	return not has_next_island() and quests_completed_this_island >= current_island().quests_to_unlock


func has_next_island() -> bool:
	return current_index < ISLANDS.size() - 1


func advance_island() -> Dictionary:
	if has_next_island():
		current_index += 1
	quests_completed_this_island = 0
	var island := current_island()
	island_changed.emit(island)
	return island


func reset() -> void:
	current_index = 0
	quests_completed_this_island = 0
	saved_player_state = {}
	total_hazards_survived = 0
	total_hazards_failed = 0
	islands_stabilized = 0


## Plain-data snapshot for SaveManager. Deliberately does not store the
## `ISLANDS` array itself (that's static game data, not save data) — only
## which island the player is on and how far they've gotten.
func serialize() -> Dictionary:
	return {
		"current_index": current_index,
		"quests_completed_this_island": quests_completed_this_island,
		"saved_player_state": saved_player_state.duplicate(true),
		"total_hazards_survived": total_hazards_survived,
		"total_hazards_failed": total_hazards_failed,
		"islands_stabilized": islands_stabilized,
	}


func restore(data: Dictionary) -> void:
	current_index = clampi(int(data.get("current_index", 0)), 0, ISLANDS.size() - 1)
	quests_completed_this_island = int(data.get("quests_completed_this_island", 0))
	saved_player_state = data.get("saved_player_state", {}).duplicate(true)
	total_hazards_survived = int(data.get("total_hazards_survived", 0))
	total_hazards_failed = int(data.get("total_hazards_failed", 0))
	islands_stabilized = int(data.get("islands_stabilized", 0))
