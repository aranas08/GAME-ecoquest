extends CanvasLayer
## crafting_menu.gd
## Story Beat 4: "The player creates useful equipment and structures that
## help them survive and progress through the island."
##
## Two-pane layout: a selectable recipe list on the left, details plus a
## material checklist on the right. Rows are built at runtime from RECIPES.
## Toggle with the "toggle_craft" input action (default: C).

signal closed

const ICON_DIR := "res://assets/images/UI/icons/"
const PLASTIC_ICON := "res://assets/images/items/plastic_bottle.png"
const WOOD_ICON := "res://assets/images/items/wood_log.png"

const RECIPES: Array[Dictionary] = [
	{
		"id": "water_filter",
		"name": "Water Filter",
		"desc": "Purify water on the spot. Restores 30 HP.",
		"plastic": 10, "wood": 5,
		"effect": "heal", "value": 30,
		"repeatable": true,
	},
	{
		"id": "beach_shelter",
		"name": "Beach Shelter",
		"desc": "A safe place to rest. Permanently +20 Max HP.",
		"plastic": 15, "wood": 15,
		"effect": "max_hp", "value": 20,
		"repeatable": false,
	},
	{
		"id": "flood_barrier",
		"name": "Flood Barrier",
		"desc": "Sandbags and scrap wood. Reduces future flood damage by 15.",
		"plastic": 20, "wood": 10,
		"effect": "flood_resistance", "value": 15,
		"repeatable": false,
	},
]

# Palette shared with the game-over frame so the two menus read as one set.
const C_ROW_BG := Color(0.145, 0.173, 0.208)
const C_ROW_BORDER := Color(0.239, 0.278, 0.325)
const C_ROW_HOVER := Color(0.196, 0.231, 0.275)
const C_SEL_BG := Color(0.176, 0.302, 0.157)
const C_SEL_BORDER := Color(1.0, 0.804, 0.212)
const C_OK := Color(0.545, 0.859, 0.451)
const C_SHORT := Color(0.925, 0.463, 0.42)

@onready var panel: Panel = %CraftingPanel
@onready var frame: PanelContainer = %Frame
@onready var recipe_list: VBoxContainer = %RecipeList
@onready var close_button: Button = %CloseButton
@onready var detail_icon: TextureRect = %DetailIcon
@onready var detail_name: Label = %DetailName
@onready var detail_cost: Label = %DetailCost
@onready var detail_desc: Label = %DetailDesc
@onready var materials_list: VBoxContainer = %MaterialsList
@onready var craft_button: Button = %CraftButton
@onready var craft_sfx: AudioStreamPlayer = $CraftSFX

var player: Node
var _selected_index: int = 0
var _rows: Array[Button] = []
var _row_buttons: Dictionary = {}  # recipe_id -> small Craft button


func _ready() -> void:
	panel.visible = false
	close_button.pressed.connect(_close)
	craft_button.pressed.connect(_on_craft_pressed.bind(null))
	player = get_tree().get_first_node_in_group("player")
	if player:
		player.plastic_changed.connect(func(_v): _refresh())
		player.wood_changed.connect(func(_v): _refresh())
	_build_rows()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("toggle_craft"):
		if panel.visible:
			_close()
		else:
			_open()
		get_viewport().set_input_as_handled()
		return

	if not panel.visible:
		return

	if event.is_action_pressed("ui_cancel"):
		_close()
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("ui_down"):
		_select(_selected_index + 1)
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("ui_up"):
		_select(_selected_index - 1)
		get_viewport().set_input_as_handled()


func _open() -> void:
	panel.visible = true
	_select(_selected_index)
	_refresh()
	_play_intro()


func _close() -> void:
	panel.visible = false
	closed.emit()


func _play_intro() -> void:
	frame.modulate.a = 0.0
	await get_tree().process_frame
	frame.pivot_offset = frame.size / 2.0
	frame.scale = Vector2(0.94, 0.94)
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(frame, "modulate:a", 1.0, 0.16)
	tween.tween_property(frame, "scale", Vector2.ONE, 0.22) \
		.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


# ---------------------------------------------------------------- style utils

func _box(bg: Color, border: Color, border_width: int = 2, radius: int = 8,
		pad_x: int = 10, pad_y: int = 8) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_border_width_all(border_width)
	sb.border_width_bottom = border_width + 1
	sb.border_color = border
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = pad_x
	sb.content_margin_right = pad_x
	sb.content_margin_top = pad_y
	sb.content_margin_bottom = pad_y + 1
	return sb


func _style_row(row: Button, selected: bool) -> void:
	var bg := C_SEL_BG if selected else C_ROW_BG
	var border := C_SEL_BORDER if selected else C_ROW_BORDER
	var width := 3 if selected else 2
	row.add_theme_stylebox_override("normal", _box(bg, border, width))
	row.add_theme_stylebox_override("hover", _box(C_ROW_HOVER if not selected else bg, border, width))
	row.add_theme_stylebox_override("pressed", _box(bg, border, width))
	row.add_theme_stylebox_override("focus", _box(bg, border, width))


func _icon_rect(path: String, px: float) -> TextureRect:
	var tex := TextureRect.new()
	tex.texture = load(path)
	tex.custom_minimum_size = Vector2(px, px)
	tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tex.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	tex.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return tex


func _recipe_icon_path(recipe: Dictionary) -> String:
	return "%srecipe_%s.png" % [ICON_DIR, recipe.id]


# ------------------------------------------------------------------ row build

func _build_rows() -> void:
	for child in recipe_list.get_children():
		recipe_list.remove_child(child)
		child.queue_free()
	_rows.clear()
	_row_buttons.clear()

	for i in RECIPES.size():
		var recipe: Dictionary = RECIPES[i]

		var row := Button.new()
		row.custom_minimum_size = Vector2(0, 86)
		row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.focus_mode = Control.FOCUS_NONE
		row.pressed.connect(_select.bind(i))
		_style_row(row, i == 0)

		# Button has no layout of its own, so anchor the contents to it.
		var margin := MarginContainer.new()
		margin.set_anchors_preset(Control.PRESET_FULL_RECT)
		margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
		margin.add_theme_constant_override("margin_left", 12)
		margin.add_theme_constant_override("margin_right", 12)
		margin.add_theme_constant_override("margin_top", 10)
		margin.add_theme_constant_override("margin_bottom", 10)
		row.add_child(margin)

		var hbox := HBoxContainer.new()
		hbox.add_theme_constant_override("separation", 14)
		hbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
		margin.add_child(hbox)

		var icon_frame := PanelContainer.new()
		icon_frame.add_theme_stylebox_override(
			"panel", _box(Color(0.094, 0.11, 0.137), Color(0.29, 0.33, 0.38), 2, 6, 6, 6)
		)
		icon_frame.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		icon_frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
		icon_frame.add_child(_icon_rect(_recipe_icon_path(recipe), 44))
		hbox.add_child(icon_frame)

		var texts := VBoxContainer.new()
		texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		texts.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		texts.add_theme_constant_override("separation", 4)
		texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hbox.add_child(texts)

		var name_label := Label.new()
		name_label.text = recipe.name
		name_label.add_theme_font_size_override("font_size", 21)
		name_label.add_theme_color_override("font_color", Color(1, 0.988, 0.965))
		texts.add_child(name_label)

		var cost_row := HBoxContainer.new()
		cost_row.add_theme_constant_override("separation", 8)
		cost_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		texts.add_child(cost_row)
		cost_row.add_child(_icon_rect(PLASTIC_ICON, 20))
		cost_row.add_child(_cost_label("Plastic %d," % recipe.plastic))
		cost_row.add_child(_icon_rect(WOOD_ICON, 20))
		cost_row.add_child(_cost_label("Wood %d" % recipe.wood))

		var craft_small := Button.new()
		craft_small.text = "Craft"
		craft_small.custom_minimum_size = Vector2(96, 44)
		craft_small.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		craft_small.focus_mode = Control.FOCUS_NONE
		craft_small.add_theme_font_size_override("font_size", 18)
		craft_small.mouse_filter = Control.MOUSE_FILTER_STOP
		craft_small.pressed.connect(_on_craft_pressed.bind(recipe))
		hbox.add_child(craft_small)

		recipe_list.add_child(row)
		_rows.append(row)
		_row_buttons[recipe.id] = craft_small

	_select(0)
	_refresh()


func _cost_label(text: String) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 16)
	label.add_theme_color_override("font_color", Color(0.784, 0.812, 0.839))
	label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label


# ------------------------------------------------------------------ selection

func _select(index: int) -> void:
	if _rows.is_empty():
		return
	_selected_index = wrapi(index, 0, _rows.size())
	for i in _rows.size():
		_style_row(_rows[i], i == _selected_index)
	_refresh_detail()


func _refresh_detail() -> void:
	if _selected_index >= RECIPES.size():
		return
	var recipe: Dictionary = RECIPES[_selected_index]

	detail_icon.texture = load(_recipe_icon_path(recipe))
	detail_name.text = recipe.name
	detail_cost.text = "(Plastic %d, Wood %d)" % [recipe.plastic, recipe.wood]
	detail_desc.text = recipe.desc

	for child in materials_list.get_children():
		materials_list.remove_child(child)
		child.queue_free()
	_add_material_row("Plastic", PLASTIC_ICON, _owned("plastic"), recipe.plastic)
	_add_material_row("Wood", WOOD_ICON, _owned("wood"), recipe.wood)

	_refresh_craft_button(recipe)


func _owned(kind: String) -> int:
	if player == null:
		return 0
	return player.plastic_count if kind == "plastic" else player.wood_count


func _add_material_row(label_text: String, icon_path: String, have: int, need: int) -> void:
	var row := PanelContainer.new()
	row.add_theme_stylebox_override(
		"panel", _box(Color(0.157, 0.18, 0.212), Color(0.239, 0.271, 0.31), 2, 6, 12, 8)
	)
	materials_list.add_child(row)

	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 12)
	row.add_child(hbox)

	hbox.add_child(_icon_rect(icon_path, 26))

	var name_label := Label.new()
	name_label.text = label_text
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.add_theme_font_size_override("font_size", 19)
	name_label.add_theme_color_override("font_color", Color(0.941, 0.957, 0.969))
	hbox.add_child(name_label)

	var count := Label.new()
	count.text = "%d / %d" % [mini(have, need), need]
	count.add_theme_font_size_override("font_size", 19)
	count.add_theme_color_override("font_color", C_OK if have >= need else C_SHORT)
	hbox.add_child(count)


func _refresh_craft_button(recipe: Dictionary) -> void:
	var built := _is_built(recipe)
	var affordable := _is_affordable(recipe)
	if built:
		craft_button.text = "BUILT"
		craft_button.disabled = true
	elif not affordable:
		craft_button.text = "NEED MATERIALS"
		craft_button.disabled = true
	else:
		craft_button.text = "CRAFT"
		craft_button.disabled = false


func _is_built(recipe: Dictionary) -> bool:
	if player == null:
		return false
	return player.crafted_ids.has(recipe.id) and not recipe.get("repeatable", true)


func _is_affordable(recipe: Dictionary) -> bool:
	if player == null:
		return false
	return player.plastic_count >= recipe.plastic and player.wood_count >= recipe.wood


# -------------------------------------------------------------------- craft

func _on_craft_pressed(recipe) -> void:
	if player == null:
		return
	# The big button crafts whatever is selected; row buttons pass their own recipe.
	var target: Dictionary = recipe if recipe is Dictionary else RECIPES[_selected_index]
	if recipe is Dictionary:
		_select(RECIPES.find(target))
	if player.craft(target):
		craft_sfx.play()
		# Close the menu so you can watch the shelter / barrier being built.
		if target.id == "beach_shelter" or target.id == "flood_barrier":
			_close()
	_refresh()


func _refresh() -> void:
	if player == null:
		return
	for recipe in RECIPES:
		var button: Button = _row_buttons.get(recipe.id)
		if button == null:
			continue
		if _is_built(recipe):
			button.text = "Built"
			button.disabled = true
		else:
			button.text = "Craft"
			button.disabled = not _is_affordable(recipe)
	_refresh_detail()
