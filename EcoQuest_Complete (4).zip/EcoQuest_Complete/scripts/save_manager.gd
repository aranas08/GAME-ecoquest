extends Node
## save_manager.gd (Autoload: SaveManager)
## Persistent save/load to disk (design doc technical requirement:
## "Save/load if possible"). Previously progress only lived in the
## IslandManager/QuestManager/GameBoot autoloads, which reset the moment the
## game process closed. This writes a single JSON save file to the user's
## save directory and can restore it into those same autoloads before the
## game scene loads, so "Continue" on the main menu works across separate
## play sessions, not just within one.

const SAVE_PATH := "user://ecoquest_save.json"

## Bumped if the save format ever changes shape; load_into_autoloads() checks
## this so an old/corrupt save can't be force-fed into a newer game version.
const SAVE_VERSION := 1


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


## Snapshots GameBoot/IslandManager/QuestManager to disk. Pass the live
## player node when one exists so the save reflects current HP/resources
## instead of whatever was captured at the last island transition.
func save_game(player: Node = null) -> bool:
	if player != null:
		IslandManager.save_player_state(player)

	var data: Dictionary = {
		"version": SAVE_VERSION,
		"player_name": GameBoot.player_name,
		"island": IslandManager.serialize(),
		"quests": QuestManager.serialize(),
	}

	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		push_warning("save_manager.gd: could not open save file for writing (%s)." % [
			error_string(FileAccess.get_open_error())
		])
		return false
	file.store_string(JSON.stringify(data))
	file.close()
	return true


## Reads the save file and pushes its contents into the GameBoot /
## IslandManager / QuestManager autoloads. Call this BEFORE changing to the
## game scene — the level and player read their starting state from those
## autoloads in their own _ready().
func load_into_autoloads() -> bool:
	if not has_save():
		return false

	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		push_warning("save_manager.gd: could not open save file for reading.")
		return false
	var text := file.get_as_text()
	file.close()

	var parsed = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY:
		push_warning("save_manager.gd: save file was not valid JSON, ignoring it.")
		return false

	var data: Dictionary = parsed
	if int(data.get("version", 0)) != SAVE_VERSION:
		push_warning("save_manager.gd: save file is from a different game version, ignoring it.")
		return false

	GameBoot.player_name = data.get("player_name", GameBoot.DEFAULT_PLAYER_NAME)
	IslandManager.restore(data.get("island", {}))
	QuestManager.restore(data.get("quests", {}))
	return true


## Wipes the save file. Called when the player deliberately starts a new run
## so a leftover old save can't bleed into it.
func clear_save() -> void:
	if has_save():
		DirAccess.remove_absolute(SAVE_PATH)
