extends CanvasLayer
## dialogue_box.gd
## A two-way conversation box (portrait, speaker name, typewriter text) used
## for the talks between the player and Maya. The game is paused while it is
## open and resumes when the conversation ends.
##
## Lines are Dictionaries in a queue:
##   {"who": "maya" | "player", "text": "..."}     one spoken line
##   {"choices": [ {"text": "...", "then": [lines...], "exit": false}, ... ],
##    "loop": true, "prompt": "What do you ask?"}  the player picks a reply
## With "loop": true the remaining topics are offered again after each answer,
## until the player picks a choice marked "exit": true. "{name}" in any text is
## replaced with the player's survivor name.
##
## Controls: E / Enter / Space / click = next line (finishes typing first),
## 1-4 or click = pick a reply, Esc = close the conversation.

signal finished

const MAYA_PORTRAIT := "res://assets/images/npc/maya.png"
const PLAYER_SHEET := "res://assets/images/player/Player_Backpack.png"
const PLAYER_SHEET_FALLBACK := "res://assets/images/player/Player.png"
const CHARS_PER_SEC := 48.0
const MAYA_COLOR := Color(0.62, 1.0, 0.6)
const PLAYER_COLOR := Color(1.0, 0.86, 0.45)

var _queue: Array = []
var _player_name: String = "Survivor"
var _typing: bool = false
var _char_pos: float = 0.0
var _total_chars: int = 0
var _waiting_choice: bool = false
var _current_choices: Array = []
var _current_loop: bool = false
var _was_paused: bool = false
var _closed: bool = false

var _panel: PanelContainer
var _portrait: TextureRect
var _name_label: Label
var _text_label: Label
var _hint: Label
var _choices_box: VBoxContainer
var _maya_tex: Texture2D
var _player_tex: Texture2D


func _init() -> void:
	# Keeps running while the tree is paused, and draws above the HUD.
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 30


## Opens the conversation. Call right after adding this node to the tree.
func start(lines: Array, player_name: String) -> void:
	_player_name = player_name
	_queue = lines.duplicate(true)
	_was_paused = get_tree().paused
	get_tree().paused = true
	_load_portraits()
	_build_ui()
	_next()


func _load_portraits() -> void:
	_maya_tex = load(MAYA_PORTRAIT) as Texture2D
	var sheet := load(PLAYER_SHEET) as Texture2D
	if sheet == null:
		sheet = load(PLAYER_SHEET_FALLBACK) as Texture2D
	if sheet != null:
		var atlas := AtlasTexture.new()
		atlas.atlas = sheet
		atlas.region = Rect2(0, 0, 32, 32)  # idle, facing the camera
		_player_tex = atlas


func _build_ui() -> void:
	var root := Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.35)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_panel = PanelContainer.new()
	_panel.add_theme_stylebox_override("panel", _style(Color(0.16, 0.09, 0.04, 0.96), Color(0.62, 0.42, 0.2, 1), 22))
	root.add_child(_panel)
	_panel.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_panel.offset_left = 60.0
	_panel.offset_right = -60.0
	_panel.offset_top = -310.0
	_panel.offset_bottom = -30.0

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 24)
	_panel.add_child(row)

	_portrait = TextureRect.new()
	_portrait.custom_minimum_size = Vector2(170, 200)
	_portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(_portrait)

	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 8)
	row.add_child(col)

	_name_label = Label.new()
	_name_label.add_theme_font_size_override("font_size", 30)
	_name_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	_name_label.add_theme_constant_override("outline_size", 6)
	col.add_child(_name_label)

	_text_label = Label.new()
	_text_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_text_label.custom_minimum_size = Vector2(0, 96)
	_text_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_text_label.add_theme_font_size_override("font_size", 27)
	_text_label.add_theme_color_override("font_color", Color(1, 1, 1, 1))
	col.add_child(_text_label)

	_choices_box = VBoxContainer.new()
	_choices_box.add_theme_constant_override("separation", 6)
	_choices_box.visible = false
	col.add_child(_choices_box)

	_hint = Label.new()
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_hint.add_theme_font_size_override("font_size", 17)
	_hint.add_theme_color_override("font_color", Color(1, 1, 1, 0.6))
	col.add_child(_hint)


func _style(fill: Color, border: Color, margin: float) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = fill
	sb.border_color = border
	sb.set_border_width_all(4)
	sb.set_corner_radius_all(16)
	sb.content_margin_left = margin
	sb.content_margin_right = margin
	sb.content_margin_top = margin * 0.7
	sb.content_margin_bottom = margin * 0.7
	return sb


# ---------- flow ----------

func _next() -> void:
	if _closed:
		return
	_clear_choices()
	if _queue.is_empty():
		_close()
		return
	var entry: Dictionary = _queue.pop_front()
	if entry.has("choices"):
		_show_choices(entry)
		return
	_show_line(String(entry.get("who", "maya")), String(entry.get("text", "")))


func _show_line(who: String, text: String) -> void:
	_set_speaker(who == "maya")
	text = text.replace("{name}", _player_name)
	_text_label.text = text
	_text_label.visible_characters = 0
	_total_chars = text.length()
	_char_pos = 0.0
	_typing = true
	_waiting_choice = false
	_hint.text = "E / Enter / click: continue      Esc: close"


func _set_speaker(is_maya: bool) -> void:
	_name_label.text = "Maya" if is_maya else _player_name
	_name_label.add_theme_color_override("font_color", MAYA_COLOR if is_maya else PLAYER_COLOR)
	_portrait.texture = _maya_tex if is_maya else _player_tex
	_portrait.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR if is_maya else CanvasItem.TEXTURE_FILTER_NEAREST


func _show_choices(entry: Dictionary) -> void:
	_typing = false
	_waiting_choice = true
	_current_choices = entry.get("choices", [])
	_current_loop = bool(entry.get("loop", false))
	_set_speaker(false)
	_text_label.text = String(entry.get("prompt", "How do you reply?"))
	_text_label.visible_characters = -1
	_hint.text = "Click a reply or press 1-%d      Esc: close" % _current_choices.size()
	for i in _current_choices.size():
		var choice: Dictionary = _current_choices[i]
		var btn := Button.new()
		btn.text = "%d.  %s" % [i + 1, String(choice.get("text", "..."))]
		btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		btn.add_theme_font_size_override("font_size", 23)
		btn.add_theme_color_override("font_color", Color(1, 1, 1, 1))
		btn.add_theme_color_override("font_hover_color", Color(1, 1, 1, 1))
		btn.add_theme_stylebox_override("normal", _style(Color(0.29, 0.17, 0.08, 0.9), Color(0.62, 0.42, 0.2, 1), 12))
		btn.add_theme_stylebox_override("hover", _style(Color(0.22, 0.47, 0.13, 0.95), Color(0.68, 0.96, 0.42, 1), 12))
		btn.add_theme_stylebox_override("focus", _style(Color(0.22, 0.47, 0.13, 0.95), Color(0.68, 0.96, 0.42, 1), 12))
		btn.add_theme_stylebox_override("pressed", _style(Color(0.15, 0.33, 0.09, 0.97), Color(0.5, 0.78, 0.3, 1), 12))
		btn.pressed.connect(_choose.bind(i))
		_choices_box.add_child(btn)
	_choices_box.visible = true
	if _choices_box.get_child_count() > 0:
		(_choices_box.get_child(0) as Button).grab_focus()


func _choose(index: int) -> void:
	if _closed or not _waiting_choice:
		return
	_waiting_choice = false
	var picked: Dictionary = _current_choices[index]
	var insert: Array = [{"who": "player", "text": String(picked.get("text", ""))}]
	insert.append_array(picked.get("then", []))
	# Offer the other topics again until the player picks an "exit" reply.
	if _current_loop and not bool(picked.get("exit", false)):
		var remaining: Array = []
		var has_topic: bool = false
		for j in _current_choices.size():
			if j == index:
				continue
			remaining.append(_current_choices[j])
			if not bool((_current_choices[j] as Dictionary).get("exit", false)):
				has_topic = true
		if has_topic:
			insert.append({"choices": remaining, "loop": true, "prompt": "Anything else?"})
	for k in range(insert.size() - 1, -1, -1):
		_queue.push_front(insert[k])
	_next()


func _clear_choices() -> void:
	for child in _choices_box.get_children():
		_choices_box.remove_child(child)  # removed now, so new buttons are child 0
		child.queue_free()
	_choices_box.visible = false
	_current_choices = []


func _process(delta: float) -> void:
	if not _typing:
		return
	_char_pos += CHARS_PER_SEC * delta
	if int(_char_pos) >= _total_chars:
		_typing = false
		_text_label.visible_characters = -1
	else:
		_text_label.visible_characters = int(_char_pos)


func _advance() -> void:
	if _typing:
		_typing = false
		_text_label.visible_characters = -1
		return
	_next()


func _input(event: InputEvent) -> void:
	if _closed:
		return
	if event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		_close()
		return
	if _waiting_choice:
		var key := event as InputEventKey
		if key != null and key.pressed and not key.echo:
			var idx: int = int(key.keycode) - int(KEY_1)
			if idx >= 0 and idx < _current_choices.size():
				get_viewport().set_input_as_handled()
				_choose(idx)
		return
	var advance: bool = event.is_action_pressed("interact") or event.is_action_pressed("ui_accept")
	var mouse := event as InputEventMouseButton
	if mouse != null and mouse.pressed and mouse.button_index == MOUSE_BUTTON_LEFT:
		advance = true
	if advance:
		get_viewport().set_input_as_handled()
		_advance()


func _close() -> void:
	if _closed:
		return
	_closed = true
	get_tree().paused = _was_paused
	finished.emit()
	queue_free()
