extends Control
## loading_screen.gd
## Boot scene (see Project Settings > Application > Run > Main Scene).
## Shows loading_screen.jpg with a progress bar while the real game scene
## (main.tscn) loads on a background thread, then fades into the main menu.
## The loaded scene is handed to GameBoot so that pressing "New Game" on the
## menu starts instantly instead of loading main.tscn all over again.
##
## Note: island changes and "Retry Island" use reload_current_scene() on
## main.tscn, so they skip this screen and reload instantly.

## The heavy scene that is preloaded in the background while the bar fills.
const GAME_SCENE_PATH := "res://main.tscn"

## Where the player is sent once the bar is full.
const MENU_SCENE_PATH := "res://Scenes/main_menu.tscn"

## The bar never fills faster than this, even if the game loads instantly,
## so the player actually gets to see the loading screen. If the game takes
## longer than this to load, the bar simply follows the real progress.
const MIN_DISPLAY_TIME := 3.0

## Fastest the bar is allowed to move (fraction of the bar per second).
const MAX_FILL_SPEED := 1.5

## Fade in from black at start / fade to black before entering the game.
const FADE_TIME := 0.5

## Short pause on a full bar before fading out.
const HOLD_AT_FULL := 0.35

## How much of the vertical crop comes off the TOP of the image when the
## screen is wider than the image (0 = keep the very top, 1 = keep the bottom).
## The logo lives near the top, so we crop mostly from the bottom.
const CROP_FROM_TOP := 0.25

## Flavour text shown as the bar fills: [minimum progress, message].
const STATUS_MESSAGES: Array = [
	[0.00, "Sweeping the shoreline"],
	[0.30, "Planting new trees"],
	[0.60, "Gathering supplies"],
	[0.90, "Almost there"],
]

@onready var background: TextureRect = %Background
@onready var progress_bar: ProgressBar = %ProgressBar
@onready var percent_label: Label = %PercentLabel
@onready var status_label: Label = %StatusLabel
@onready var fade: ColorRect = %Fade

var _elapsed: float = 0.0
var _shown: float = 0.0  # what the bar is currently displaying (0..1)
var _loaded: bool = false
var _finishing: bool = false
var _failed: bool = false
var _game_scene: PackedScene


func _ready() -> void:
	progress_bar.min_value = 0.0
	progress_bar.max_value = 1.0
	progress_bar.value = 0.0
	_update_labels()

	_fit_background()
	resized.connect(_fit_background)

	# Fade in from black.
	fade.color.a = 1.0
	create_tween().tween_property(fade, "color:a", 0.0, FADE_TIME)

	# Start loading the game on a background thread.
	var err := ResourceLoader.load_threaded_request(GAME_SCENE_PATH)
	if err != OK:
		_fail("Could not start loading the game (error %d)." % err)


func _process(delta: float) -> void:
	if _finishing or _failed:
		return
	_elapsed += delta

	# 1) Ask the engine how far along the real load is.
	var real_progress: float = 1.0
	if not _loaded:
		var progress: Array = []
		var status := ResourceLoader.load_threaded_get_status(GAME_SCENE_PATH, progress)
		match status:
			ResourceLoader.THREAD_LOAD_IN_PROGRESS:
				real_progress = progress[0] if progress.size() > 0 else 0.0
			ResourceLoader.THREAD_LOAD_LOADED:
				_game_scene = ResourceLoader.load_threaded_get(GAME_SCENE_PATH) as PackedScene
				if _game_scene == null:
					_fail("The game scene loaded, but it isn't a valid scene.")
					return
				GameBoot.game_scene = _game_scene
				_loaded = true
			_:
				_fail("Could not load %s." % GAME_SCENE_PATH)
				return

	# 2) The bar shows whichever is slower: real progress, or the minimum-time pace.
	var paced: float = clampf(_elapsed / MIN_DISPLAY_TIME, 0.0, 1.0)
	var target: float = minf(real_progress, paced)
	_shown = move_toward(_shown, target, delta * MAX_FILL_SPEED)
	_update_labels()

	# 3) Full bar + game ready = go.
	if _loaded and _shown >= 1.0:
		_finish()


func _update_labels() -> void:
	progress_bar.value = _shown
	percent_label.text = "%d%%" % int(round(_shown * 100.0))
	if _finishing:
		status_label.text = "Ready!"
		return
	var message: String = STATUS_MESSAGES[0][1]
	for entry in STATUS_MESSAGES:
		if _shown >= entry[0]:
			message = entry[1]
	# Animated dots: "", ".", "..", "..." cycling ~3 times a second.
	var dots := ".".repeat(int(_elapsed * 3.0) % 4)
	status_label.text = message + dots


func _finish() -> void:
	_finishing = true
	_update_labels()
	var tween := create_tween()
	tween.tween_interval(HOLD_AT_FULL)
	tween.tween_property(fade, "color:a", 1.0, FADE_TIME)
	tween.tween_callback(_enter_menu)


func _enter_menu() -> void:
	var err := get_tree().change_scene_to_file(MENU_SCENE_PATH)
	if err != OK:
		_fail("Could not open the main menu (error %d)." % err)


func _fail(message: String) -> void:
	_failed = true
	push_error("loading_screen.gd: " + message)
	status_label.text = message
	status_label.add_theme_color_override("font_color", Color(1.0, 0.55, 0.5))
	# Make sure the message is visible even if we failed mid-fade.
	fade.color.a = 0.0


## Scales the background image to cover the whole screen (like CSS
## "object-fit: cover"), so it never shows empty edges at any window shape.
func _fit_background() -> void:
	var tex := background.texture
	if tex == null:
		return
	var tex_size: Vector2 = tex.get_size()
	var scale_factor: float = maxf(size.x / tex_size.x, size.y / tex_size.y)
	var scaled: Vector2 = tex_size * scale_factor
	var extra: Vector2 = scaled - size
	background.size = scaled
	background.position = Vector2(-extra.x * 0.5, -extra.y * CROP_FROM_TOP)
