extends Node2D
## base_level.gd
## Attached to LevelRoot. Runs the island's environmental-quest loop:
##   Explore -> Collect -> Survive -> Complete Quests -> Craft -> Progress
##
## Generalized hazard system covers all three hazard types from the doc
## ("floods, extreme heat, strong storms") using the same timed-challenge
## shape as the original Flood Warning storyboard (Panels 4-10):
##   Panel 4  -> _start_warning()        (banner appears)
##   Panel 5  -> CHALLENGE_ACTIVE state  (timed collection)
##   Panel 7  -> success path            ("ENVIRONMENTAL QUEST COMPLETED!")
##   Panel 8-9-> failure path            (hazard damage + environment FX + "prepare better next time")
##   Panel 10 -> new quest prompt, and — every few successes — island progression

signal banner_shown(text: String)
signal banner_hidden
signal dialogue_shown(text: String)
signal timer_updated(seconds_left: float)
signal challenge_progress(collected: int, required: int)
signal hazard_resolved(hazard_type: String, success: bool, is_climax: bool)
signal island_progress_ready
## Fired after IslandManager has counted a survived hazard (so autosaves and the
## HUD see the up-to-date island progress).
signal hazard_success_registered

enum State { EXPLORING, WARNING_ISSUED, CHALLENGE_ACTIVE, RESOLVED, GAME_OVER }

const PLASTIC_SCENES: Array[PackedScene] = [
	preload("res://Scenes/plastic_bottle.tscn"),
	preload("res://Scenes/plastic_bag.tscn"),
]
const WOOD_SCENES: Array[PackedScene] = [
	preload("res://Scenes/wood_log.tscn"),
]

## Hazard definitions — one entry per environmental hazard from the doc.
## `material` is which resource the timed challenge asks the player to
## collect; damage/required/time are scaled by the current island's
## difficulty multiplier in _get_hazard_def().
const HAZARD_DEFS: Dictionary = {
	"flood": {
		"warning_banner": "FLOOD WARNING!",
		"challenge_banner": "Collect %d Plastic!",
		"material": "plastic", "required": 20, "time": 45.0, "damage": 30,
		"warn_line": "I need to collect %d plastic before the flood hits!",
		"success_banner": "ENVIRONMENTAL QUEST COMPLETED!", "success_line": "I made it.",
		"fail_banner": "THE FLOOD HAS ARRIVED", "fail_line": "I need to prepare better next time.",
	},
	"storm": {
		"warning_banner": "STORM WARNING!",
		"challenge_banner": "Gather %d Wood for Shelter!",
		"material": "wood", "required": 12, "time": 40.0, "damage": 25,
		"warn_line": "I need %d wood to reinforce shelter before the storm hits!",
		"success_banner": "SHELTER SECURED!", "success_line": "That should hold.",
		"fail_banner": "THE STORM HIT HARD", "fail_line": "That storm really did a number on me.",
	},
	"heat": {
		"warning_banner": "EXTREME HEAT WARNING!",
		"challenge_banner": "Collect %d Plastic for Shade Cover!",
		"material": "plastic", "required": 18, "time": 45.0, "damage": 20,
		"warn_line": "I need %d plastic sheets for shade before the heat wave hits!",
		"success_banner": "SHADE COVER BUILT!", "success_line": "Phew. That's better.",
		"fail_banner": "THE HEAT WAVE HIT", "fail_line": "I should've prepared more shade.",
	},
}

## Storyboard Panel 6 ("Final Collection"): once the player crosses this
## fraction of the required amount during a timed challenge, show one
## "Almost there!" bark. Reset per-challenge in _start_warning().
const ALMOST_THERE_THRESHOLD := 0.75

## Fallback spawn rectangle, only used if an island has no usable land cells
## (normally items are placed on reachable land tiles - see _build_spawn_cells).
@export var spawn_top_left: Vector2 = Vector2(80, 500)
@export var spawn_bottom_right: Vector2 = Vector2(2200, 1580)

## 16px tiles x the TileMapLayer's scale of 4.
const ISLAND_CELL_SIZE := 64.0
## Shoreline (beach) tiles carry a thin strip of sea as a collider but can still
## be walked on; anything else with a collider (water, cliff walls) blocks.
const BEACH_SOURCE_ID := 4
const PASSABLE_MAX_AREA := 0.55

@export var initial_plastic_count: int = 40
@export var initial_wood_count: int = 14
@export var time_until_first_warning: float = 30.0
@export var next_warning_delay_range: Vector2 = Vector2(35.0, 55.0)

## Materials trickle back in over time so crafting/challenges stay possible
## after the first sweep of the island (Story Beat 3: "Rising Conflict").
@export var wood_respawn_interval: float = 12.0
@export var wood_respawn_amount: int = 2
@export var plastic_respawn_interval: float = 10.0
@export var plastic_respawn_amount: int = 4
## Stops the island filling up with uncollected items.
@export var max_items_per_container: int = 90

var state: State = State.EXPLORING
var warning_countdown: float = 0.0
var challenge_time_left: float = 0.0
var wood_respawn_timer: float = 0.0
var plastic_respawn_timer: float = 0.0

var current_hazard_id: String = "flood"
var current_hazard_def: Dictionary = {}
var quest_id: String = ""
var _almost_there_shown: bool = false

var player: CharacterBody2D
var plastic_container: Node2D
var wood_container: Node2D
## Land cells (TileMapLayer coordinates) where pickups may appear: no collider
## and reachable on foot from the player's start.
var _spawn_cells: Array[Vector2i] = []

@onready var tilemap: TileMapLayer = get_node_or_null("TileMapLayer") as TileMapLayer
@onready var sfx_warning: AudioStreamPlayer = $SFX_Warning
@onready var sfx_success: AudioStreamPlayer = $SFX_Success
@onready var sfx_fail: AudioStreamPlayer = $SFX_Fail


func _ready() -> void:
	randomize()
	add_to_group("level")

	player = get_tree().get_first_node_in_group("player")
	if player == null:
		push_warning("base_level.gd: no node in group 'player' found under LevelRoot.")
		return
	player.defeated.connect(_on_player_defeated)

	# Any leftover timed-hazard quest (e.g. from a run that ended mid-warning)
	# is stale now: the countdown that owned it no longer exists.
	QuestManager.clear_active_kind("hazard")

	# Forward pickups/crafts to the quest system, and pay out finished quests.
	player.item_collected.connect(QuestManager.report_collected)
	player.item_crafted.connect(func(recipe_id: String, _n: String) -> void: QuestManager.report_crafted(recipe_id))
	QuestManager.quest_completed.connect(_on_quest_completed)

	_apply_island_theme(IslandManager.current_island())
	_spawn_decorations(IslandManager.current_island().id)
	_spawn_maya_house()
	_setup_land_wildlife()
	_setup_water_hazard()
	_setup_water_life()
	_setup_disaster_director()

	plastic_container = Node2D.new()
	plastic_container.name = "PlasticContainer"
	add_child(plastic_container)

	wood_container = Node2D.new()
	wood_container.name = "WoodContainer"
	add_child(wood_container)

	for i in initial_plastic_count:
		_spawn_item_at_random(PLASTIC_SCENES, plastic_container)
	for i in initial_wood_count:
		_spawn_item_at_random(WOOD_SCENES, wood_container)

	wood_respawn_timer = wood_respawn_interval
	plastic_respawn_timer = plastic_respawn_interval

	var island: Dictionary = IslandManager.current_island()
	dialogue_shown.emit(island.intro)
	warning_countdown = time_until_first_warning

	_retire_old_side_quests()
	var offered: Array[String] = _offer_side_quests()
	if not offered.is_empty():
		_announce_new_quests_later(offered)


func _apply_island_theme(island: Dictionary) -> void:
	current_hazard_id = island.hazard
	_load_island_terrain(island)
	if tilemap:
		tilemap.modulate = island.tint


## Swaps in the map for the current island. Each island's terrain lives in its
## own scene (IslandManager.ISLANDS[i].terrain_scene) with a TileMapLayer named
## "TileMapLayer" and Marker2D nodes "PlayerStart" and "MayaSpot".
func _load_island_terrain(island: Dictionary) -> void:
	var scene_path: String = island.get("terrain_scene", "")
	var packed: PackedScene = null
	if scene_path != "" and ResourceLoader.exists(scene_path):
		packed = load(scene_path) as PackedScene
	if packed == null:
		push_warning("base_level.gd: no terrain scene for island '%s'; keeping the default tilemap." % island.id)
		_build_spawn_cells()
		return

	var terrain: Node = packed.instantiate()
	var new_layer: TileMapLayer = terrain.get_node_or_null("TileMapLayer") as TileMapLayer
	if new_layer == null:
		push_warning("base_level.gd: %s has no TileMapLayer node." % scene_path)
		terrain.free()
		_build_spawn_cells()
		return

	# Replace the placeholder tilemap with this island's.
	var old_layer: Node = get_node_or_null("TileMapLayer")
	if old_layer:
		remove_child(old_layer)
		old_layer.free()
	terrain.remove_child(new_layer)
	new_layer.owner = null
	add_child(new_layer)
	move_child(new_layer, 0)
	tilemap = new_layer

	# Put the player and Maya where this island's map says.
	var start: Marker2D = terrain.get_node_or_null("PlayerStart") as Marker2D
	if start and player:
		var body_offset: Vector2 = Vector2.ZERO
		var body_shape: CollisionShape2D = player.get_node_or_null("CollisionShape2D") as CollisionShape2D
		if body_shape:
			body_offset = body_shape.position * player.scale
		player.position = start.position - body_offset
	var maya_spot: Marker2D = terrain.get_node_or_null("MayaSpot") as Marker2D
	var maya: Node2D = get_node_or_null("Maya") as Node2D
	if maya_spot and maya:
		maya.position = maya_spot.position
	terrain.free()

	_build_spawn_cells()


func _is_clear_land(cell: Vector2i) -> bool:
	var data: TileData = tilemap.get_cell_tile_data(cell)
	return data != null and data.get_collision_polygons_count(0) == 0


func _is_passable(cell: Vector2i) -> bool:
	var data: TileData = tilemap.get_cell_tile_data(cell)
	if data == null:
		return false
	if data.get_collision_polygons_count(0) == 0:
		return true
	if tilemap.get_cell_source_id(cell) != BEACH_SOURCE_ID:
		return false
	var points: PackedVector2Array = data.get_collision_polygon_points(0, 0)
	var doubled_area: float = 0.0
	for i in points.size():
		var a: Vector2 = points[i]
		var b: Vector2 = points[(i + 1) % points.size()]
		doubled_area += a.x * b.y - b.x * a.y
	return absf(doubled_area) * 0.5 < PASSABLE_MAX_AREA * 256.0


## Flood-fills outwards from the player's start over walkable tiles so pickups
## never spawn in the sea, inside cliff pits, or on land the player can't reach.
func _build_spawn_cells() -> void:
	_spawn_cells.clear()
	if tilemap == null or player == null:
		return
	var probe: Vector2 = player.global_position
	var body_shape: CollisionShape2D = player.get_node_or_null("CollisionShape2D") as CollisionShape2D
	if body_shape:
		probe = body_shape.global_position
	var start_cell: Vector2i = tilemap.local_to_map(tilemap.to_local(probe))
	if not _is_passable(start_cell):
		push_warning("base_level.gd: player start (%s) is not on walkable land." % start_cell)
		return

	var seen: Dictionary = {start_cell: true}
	var queue: Array[Vector2i] = [start_cell]
	var head: int = 0
	var steps: Array[Vector2i] = [Vector2i.RIGHT, Vector2i.LEFT, Vector2i.DOWN, Vector2i.UP]
	while head < queue.size():
		var cell: Vector2i = queue[head]
		head += 1
		if _is_clear_land(cell):
			_spawn_cells.append(cell)
		for step in steps:
			var next_cell: Vector2i = cell + step
			if not seen.has(next_cell) and _is_passable(next_cell):
				seen[next_cell] = true
				queue.append(next_cell)


# --- Island scenery ------------------------------------------------------------
# Built in three layers so every island feels hand-dressed rather than evenly
# sprinkled:
#   1. LANDMARKS   - a few signature props per island (boat wreck, well, arch...)
#   2. GROVES      - clusters of trees / rocks that grow together
#   3. SCATTER     - lone pieces filling in the gaps
# plus walk-through GROUND cover (grass, flowers, shells...). Sprites live in
# assets/images/decor/. Entry format: [sprite name, weight, solid].
const DECOR_BY_ISLAND := {
	"beach": [["tree_palm", 4, true], ["tree_banana", 2, true], ["rock_small", 2, true], ["rock_cluster", 2, true], ["rock_slab", 1, true], ["driftwood", 2, false], ["bush", 2, false], ["bush_dry", 1, false]],
	"forest": [["tree_oak", 3, true], ["tree_orange", 2, true], ["tree_lemon", 2, true], ["tree_cherry", 3, true], ["tree_grand", 2, true], ["tree_pine", 1, true], ["stump", 1, true], ["bush_berry", 3, false], ["bush_blue", 2, false], ["mushrooms", 3, false], ["rock_mossy", 2, true], ["rock_cluster", 1, true], ["fallen_log", 1, true], ["ground_patch_wild", 2, false]],
	"river": [["reeds", 3, false], ["tree_banana", 2, true], ["tree_oak", 2, true], ["tree_cherry", 1, true], ["rock_mossy", 3, true], ["rock_slab", 2, true], ["rock_cluster", 2, true], ["bush_blue", 2, false], ["bush_berry", 1, false]],
	"village": [["tree_cherry", 2, true], ["tree_orange", 2, true], ["tree_oak", 2, true], ["tree_dead", 1, true], ["hay_bale", 2, true], ["fence", 2, true], ["crate", 2, true], ["barrel", 2, true], ["rock_small", 1, true], ["bush_dry", 1, false]],
	"mountain": [["rock_spire", 3, true], ["rock_columns", 2, true], ["rock_cluster", 3, true], ["boulder", 2, true], ["boulder_red", 2, true], ["rock_ore", 2, true], ["rock_slab", 2, true], ["rock_stack", 1, true], ["tree_dead", 2, true], ["dry_bush", 2, false]],
}
## Signature props: [sprite, how many, solid]. Placed first, well apart.
const LANDMARKS_BY_ISLAND := {
	"beach": [["boat_wreck", 1, true], ["umbrella", 2, true], ["campfire", 1, false], ["rock_arch", 1, true]],
	"forest": [["fallen_log", 2, true], ["signpost", 1, true], ["tree_grand", 3, true], ["campfire", 1, false], ["rock_arch", 1, true], ["fence", 3, true], ["lamppost", 2, true]],
	"river": [["fence", 2, true], ["signpost", 1, true], ["rock_arch", 1, true], ["tree_grand", 1, true]],
	"village": [["well", 1, true], ["ruin_wall", 3, true], ["scarecrow", 1, true], ["lamppost", 2, true], ["campfire", 1, false]],
	"mountain": [["rock_arch", 2, true], ["rock_columns", 1, true], ["rock_stack", 2, true], ["campfire", 1, false], ["signpost", 1, true]],
}
## Collider width as a fraction of the sprite width (default 0.55). Wide
## pieces (walls, logs, slabs) need to block their whole length.
const DECOR_COLLIDER_WIDTH := {
	"ruin_wall": 0.9, "fence": 0.9, "fallen_log": 0.9, "rock_slab": 0.85, "boat_wreck": 0.8,
	"rock_arch": 0.8, "rock_columns": 0.75, "rock_cluster": 0.8, "driftwood": 0.7, "hay_bale": 0.8,
}

# Ground cover per island: chance (per open land cell) of a grass tuft and of
# a flower on grass tiles, of dry scrub / pebbles on sand and path tiles, and
# of an "extra" themed sprite (shells and starfish on the beach...).
const GROUND_BY_ISLAND := {
	"beach": {"grass": 0.35, "flower": 0.10, "dry": 0.22, "extra": ["ground_shell", "ground_starfish"], "extra_chance": 0.07},
	"forest": {"grass": 0.95, "flower": 0.48, "dry": 0.02, "extra": ["ground_patch_wild", "ground_patch_pink", "ground_pebbles"], "extra_chance": 0.16},
	"river": {"grass": 0.80, "flower": 0.30, "dry": 0.05, "extra": ["ground_shell"], "extra_chance": 0.03},
	"village": {"grass": 0.55, "flower": 0.18, "dry": 0.20, "extra": [], "extra_chance": 0.0},
	"mountain": {"grass": 0.12, "flower": 0.03, "dry": 0.35, "extra": ["ground_pebbles"], "extra_chance": 0.10},
}
const GRASS_TUFTS := ["ground_tuft_a", "ground_tuft_b", "ground_tuft_c"]
const DRY_TUFTS := ["ground_dry_a", "ground_dry_b", "ground_dry_a", "ground_pebbles"]
const FLOWERS := ["ground_flower_red", "ground_flower_yellow", "ground_flower_white", "ground_flower_purple",
	"ground_flower_pink", "ground_flower_blue", "ground_patch_wild", "ground_patch_pink"]
## Tile source ids in eco_tileset.tres that count as grassy ground.
const GRASS_SOURCE_IDS := [1, 6]
const GROUND_Z := -8

const WaterHazardScript := preload("res://scripts/water_hazard.gd")
const DisasterDirectorScript := preload("res://scripts/disaster_director.gd")
const WaterLifeScript := preload("res://scripts/water_life.gd")
const LandWildlifeScript := preload("res://scripts/land_wildlife.gd")
const EcoHouseScript := preload("res://scripts/eco_house.gd")
const SHORE_SIGN_COUNT := 5
const SHORE_SIGN_SPACING := 520.0
const DECOR_SCALE := 4.0
const DECOR_MIN_SPACING := 165.0
const GROVE_SPACING := 112.0
const LANDMARK_SPACING := 350.0
const DECOR_PLAYER_CLEARANCE := 300.0
const DECOR_Z_BEHIND := -5
const DECOR_Z_FRONT := 1

## [{node: Node2D, base_y: float}] - used to draw each piece in front of or
## behind the player depending on who is "lower" on screen.
var _decor: Array[Dictionary] = []
var _decor_shape: CollisionShape2D
var _decor_open: Dictionary = {}
var _decor_used: Dictionary = {}
var _decor_placed: Array[Vector2] = []
var _decor_avoid: Array[Vector2] = []


func _spawn_decorations(island_id: String) -> void:
	_decor.clear()
	_decor_placed.clear()
	_decor_used.clear()
	_decor_avoid.clear()
	_decor_open.clear()
	if tilemap == null or not DECOR_BY_ISLAND.has(island_id) or _spawn_cells.is_empty():
		return
	# Ground always renders underneath everything else.
	tilemap.z_index = -10
	_spawn_ground_cover(island_id)
	_decor_shape = player.get_node_or_null("CollisionShape2D") as CollisionShape2D

	for c in _spawn_cells:
		_decor_open[c] = true

	var container := Node2D.new()
	container.name = "Decorations"
	add_child(container)
	move_child(container, 2)

	_decor_avoid.append(player.position)
	var maya: Node2D = get_node_or_null("Maya") as Node2D
	if maya:
		_decor_avoid.append(maya.position)

	var cells: Array[Vector2i] = _spawn_cells.duplicate()
	cells.shuffle()
	var table: Array = DECOR_BY_ISLAND[island_id]

	# 1. Landmarks, well spread out.
	var landmark_spots: Array[Vector2] = []
	for entry in LANDMARKS_BY_ISLAND.get(island_id, []):
		for i in int(entry[1]):
			for cell in cells:
				var base := _decor_cell_base(cell)
				if not _decor_cell_ok(cell, base, LANDMARK_SPACING, landmark_spots):
					continue
				if _add_decoration(container, entry[0], bool(entry[2]), base):
					landmark_spots.append(base)
					_decor_mark(cell, base)
					break

	# 2. Groves: clusters of 4-7 pieces around a random centre.
	var groves: int = clampi(cells.size() / 55, 3, 10)
	var tries := 0
	while groves > 0 and tries < 400:
		tries += 1
		var centre_cell: Vector2i = cells[randi() % cells.size()]
		var centre := _decor_cell_base(centre_cell)
		if not _decor_cell_ok(centre_cell, centre, DECOR_MIN_SPACING, []):
			continue
		groves -= 1
		var members := randi_range(4, 7)
		for m in members:
			for attempt in 8:
				var angle := randf() * TAU
				var pos := centre + Vector2.from_angle(angle) * randf_range(0.0, 300.0)
				var cell: Vector2i = tilemap.local_to_map(tilemap.to_local(to_global(pos)))
				if not _decor_cell_ok(cell, pos, GROVE_SPACING, []):
					continue
				var pick := _pick_weighted(table)
				if _add_decoration(container, pick[0], bool(pick[2]), pos):
					_decor_mark(cell, pos)
					break

	# 3. Scatter lone pieces to fill the gaps.
	var target: int = clampi(cells.size() / 16, 8, 60)
	var scattered := 0
	for cell in cells:
		if scattered >= target:
			break
		var base := _decor_cell_base(cell)
		if not _decor_cell_ok(cell, base, DECOR_MIN_SPACING, []):
			continue
		var pick := _pick_weighted(table)
		if _add_decoration(container, pick[0], bool(pick[2]), base):
			_decor_mark(cell, base)
			scattered += 1

	_spawn_shore_signs(container, cells)

	# Pickups shouldn't spawn underneath scenery.
	var free_cells: Array[Vector2i] = []
	for c in _spawn_cells:
		if not _decor_used.has(c):
			free_cells.append(c)
	_spawn_cells = free_cells


## Wooden warning signs along the shoreline so players learn the water hurts
## before they wade in.
func _spawn_shore_signs(container: Node2D, cells: Array[Vector2i]) -> void:
	var placed_signs: Array[Vector2] = []
	for cell in cells:
		if placed_signs.size() >= SHORE_SIGN_COUNT:
			break
		if _decor_used.has(cell):
			continue
		var touches_water := false
		for n in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var sid: int = tilemap.get_cell_source_id(cell + n)
			if sid == 2 or sid == 3 or sid == -1:
				touches_water = true
		if not touches_water:
			continue
		var base := _decor_cell_base(cell)
		var too_close := false
		for a in _decor_avoid:
			if base.distance_to(a) < DECOR_PLAYER_CLEARANCE:
				too_close = true
		for p in _decor_placed:
			if base.distance_to(p) < 130.0:
				too_close = true
		for p in placed_signs:
			if base.distance_to(p) < SHORE_SIGN_SPACING:
				too_close = true
		if too_close:
			continue
		if _add_decoration(container, "shore_sign", false, base):
			placed_signs.append(base)
			_decor_used[cell] = true


## Plays the failed-warning disaster (tidal wave, lightning, heat): see disaster_director.gd.
var _disaster = null   # disaster_director.gd instance


func _setup_disaster_director() -> void:
	_disaster = DisasterDirectorScript.new()
	_disaster.name = "DisasterDirector"
	add_child(_disaster)
	_disaster.message.connect(func(banner: String, line: String) -> void:
		banner_shown.emit(banner)
		dialogue_shown.emit(line))


## The island's footprint in this node's local coordinates.
func _island_world_rect() -> Rect2:
	if tilemap == null or tilemap.tile_set == null:
		return Rect2(0.0, 0.0, 2304.0, 1664.0)
	var used: Rect2i = tilemap.get_used_rect()
	if used.size.x <= 0 or used.size.y <= 0:
		return Rect2(0.0, 0.0, 2304.0, 1664.0)
	var cell: float = float(tilemap.tile_set.tile_size.x) * tilemap.scale.x
	var top_left: Vector2 = to_local(tilemap.to_global(tilemap.map_to_local(used.position)))
	var bottom_right: Vector2 = to_local(tilemap.to_global(tilemap.map_to_local(used.end - Vector2i.ONE)))
	var half: Vector2 = Vector2(cell, cell) * 0.5
	return Rect2(top_left - half, (bottom_right - top_left) + Vector2(cell, cell))


## Water is walkable but harmful: see water_hazard.gd.
func _setup_water_hazard() -> void:
	if tilemap == null or player == null:
		return
	var hazard: Node2D = WaterHazardScript.new()
	hazard.name = "WaterHazard"
	add_child(hazard)
	hazard.setup(self, tilemap, player)


## Land animals are placed on reachable open ground, away from the starting
## character and scenery. Harmless rabbits/birds add life; marked snakes and
## scorpions deal 10 HP on contact.

func _spawn_maya_house() -> void:
	# Place Maya's home on a clear land cell, not over water or scenery.
	if tilemap == null or _spawn_cells.is_empty():
		return
	var maya: Node2D = get_node_or_null("Maya") as Node2D
	var desired: Vector2 = (maya.position if maya else player.position) + Vector2(210.0, 10.0)
	var best_pos: Vector2 = desired
	var best_distance: float = INF
	for cell in _spawn_cells:
		var candidate: Vector2 = _decor_cell_base(cell)
		if candidate.distance_to(player.position) < 170.0:
			continue
		if maya and candidate.distance_to(maya.position) < 125.0:
			continue
		var distance: float = candidate.distance_to(desired)
		if distance < best_distance:
			best_distance = distance
			best_pos = candidate
	var home := Node2D.new()
	home.name = "MayaHome"
	home.set_script(EcoHouseScript)
	home.position = best_pos
	home.z_index = int(best_pos.y / 100.0)
	add_child(home)

func _setup_land_wildlife() -> void:
	if tilemap == null or player == null or _spawn_cells.is_empty():
		return
	var wildlife: Node2D = LandWildlifeScript.new()
	wildlife.name = "LandWildlife"
	add_child(wildlife)
	wildlife.setup(player, tilemap, _spawn_cells, String(IslandManager.current_island().id))


## Boats and stepping-stone rocks you can stand on, plus fish, turtles and
## jellyfish: see water_life.gd.
func _setup_water_life() -> void:
	if tilemap == null or player == null:
		return
	var life: Node2D = WaterLifeScript.new()
	life.name = "WaterLife"
	add_child(life)
	life.setup(self, tilemap, player)


func _decor_cell_base(cell: Vector2i) -> Vector2:
	return to_local(tilemap.to_global(tilemap.map_to_local(cell))) + Vector2(0, ISLAND_CELL_SIZE * 0.3)


## A spot is usable when its cell and all 8 neighbours are open land (keeps
## scenery off shorelines and narrow paths), it is clear of the player / Maya,
## and it keeps `spacing` pixels from everything already placed.
func _decor_cell_ok(cell: Vector2i, pos: Vector2, spacing: float, extra_points: Array[Vector2]) -> bool:
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			if not _decor_open.has(cell + Vector2i(dx, dy)):
				return false
	for a in _decor_avoid:
		if pos.distance_to(a) < DECOR_PLAYER_CLEARANCE:
			return false
	for p in _decor_placed:
		if pos.distance_to(p) < minf(spacing, DECOR_MIN_SPACING):
			return false
	for p in extra_points:
		if pos.distance_to(p) < spacing:
			return false
	return true


func _decor_mark(cell: Vector2i, pos: Vector2) -> void:
	_decor_placed.append(pos)
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			_decor_used[cell + Vector2i(dx, dy)] = true


func _pick_weighted(table: Array) -> Array:
	var total := 0
	for entry in table:
		total += int(entry[1])
	var roll := randi() % total
	for entry in table:
		roll -= int(entry[1])
		if roll < 0:
			return entry
	return table[0]


## Walk-through grass tufts, flowers, shells and pebbles scattered over open
## land. Purely visual: drawn above the ground tiles but below everything else.
func _spawn_ground_cover(island_id: String) -> void:
	var cfg: Dictionary = GROUND_BY_ISLAND.get(island_id, {})
	if cfg.is_empty():
		return
	var container := Node2D.new()
	container.name = "Ground"
	container.z_index = GROUND_Z
	container.y_sort_enabled = true
	add_child(container)
	move_child(container, 1)
	var extras: Array = cfg.get("extra", [])
	for cell in _spawn_cells:
		var grassy: bool = tilemap.get_cell_source_id(cell) in GRASS_SOURCE_IDS
		var centre: Vector2 = to_local(tilemap.to_global(tilemap.map_to_local(cell)))
		var half: float = ISLAND_CELL_SIZE * 0.42
		if grassy:
			if randf() < float(cfg.grass):
				_add_ground_sprite(container, GRASS_TUFTS.pick_random(), centre + _ground_jitter(half))
			if randf() < float(cfg.flower):
				_add_ground_sprite(container, FLOWERS.pick_random(), centre + _ground_jitter(half))
			# Arid islands: the few grass tiles they have are dry and patchy.
			if randf() < float(cfg.dry) * 0.5:
				_add_ground_sprite(container, DRY_TUFTS.pick_random(), centre + _ground_jitter(half))
		else:
			if randf() < float(cfg.dry) * 0.5:
				_add_ground_sprite(container, DRY_TUFTS.pick_random(), centre + _ground_jitter(half))
			if not extras.is_empty() and randf() < float(cfg.get("extra_chance", 0.0)):
				_add_ground_sprite(container, extras.pick_random(), centre + _ground_jitter(half))


func _ground_jitter(half: float) -> Vector2:
	return Vector2(randf_range(-half, half), randf_range(-half, half) + 14.0)


func _add_ground_sprite(container: Node2D, sprite_name: String, pos: Vector2) -> void:
	var path := "res://assets/images/decor/%s.png" % sprite_name
	if not ResourceLoader.exists(path):
		return
	var tex := load(path) as Texture2D
	if tex == null:
		return
	var sprite := Sprite2D.new()
	sprite.texture = tex
	sprite.centered = false
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.scale = Vector2(DECOR_SCALE, DECOR_SCALE)
	sprite.offset = Vector2(-tex.get_width() * 0.5, -tex.get_height() + 1)
	sprite.flip_h = randf() < 0.5
	sprite.position = pos
	container.add_child(sprite)


func _add_decoration(container: Node2D, sprite_name: String, solid: bool, base: Vector2) -> bool:
	var path := "res://assets/images/decor/%s.png" % sprite_name
	if not ResourceLoader.exists(path):
		return false
	var tex := load(path) as Texture2D
	if tex == null:
		return false
	var node := Node2D.new()
	node.position = base
	var sprite := Sprite2D.new()
	sprite.texture = tex
	sprite.centered = false
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.scale = Vector2(DECOR_SCALE, DECOR_SCALE)
	# Origin sits at the object's base (the sprite has 1px of padding).
	sprite.offset = Vector2(-tex.get_width() * 0.5, -tex.get_height() + 1)
	node.add_child(sprite)
	# Trees, rocks and ruins cast shade that protects you from the heat wave.
	if sprite_name.begins_with("tree") or sprite_name.begins_with("rock") \
			or sprite_name.begins_with("boulder") or sprite_name == "ruin_wall" \
			or sprite_name == "umbrella" or sprite_name == "hay_bale":
		node.add_to_group("shade")
	if solid:
		var body := StaticBody2D.new()
		var shape := CollisionShape2D.new()
		var rect := RectangleShape2D.new()
		var frac: float = float(DECOR_COLLIDER_WIDTH.get(sprite_name, 0.55))
		rect.size = Vector2(minf(tex.get_width() * DECOR_SCALE * frac, 170.0), 26.0)
		shape.shape = rect
		shape.position = Vector2(0, -12)
		body.add_child(shape)
		node.add_child(body)
	container.add_child(node)
	_decor.append({"node": node, "base_y": base.y})
	return true


## Draws each decoration behind the player when the player is lower on screen
## (walking in front of it), and in front when the player is above it.
func _update_decoration_depth() -> void:
	if _decor.is_empty() or player == null:
		return
	var feet_y: float = to_local(player.global_position).y
	if _decor_shape:
		feet_y = to_local(_decor_shape.global_position).y + 28.0
	for d in _decor:
		var n: Node2D = d.node
		n.z_index = DECOR_Z_BEHIND if feet_y > float(d.base_y) else DECOR_Z_FRONT


func _random_spawn_position() -> Vector2:
	if _spawn_cells.is_empty():
		return Vector2(
			randf_range(spawn_top_left.x, spawn_bottom_right.x),
			randf_range(spawn_top_left.y, spawn_bottom_right.y)
		)
	var cell: Vector2i = _spawn_cells[randi() % _spawn_cells.size()]
	var centre: Vector2 = to_local(tilemap.to_global(tilemap.map_to_local(cell)))
	var jitter: float = ISLAND_CELL_SIZE * 0.3
	return centre + Vector2(randf_range(-jitter, jitter), randf_range(-jitter, jitter))


## Extra scaling applied only to the LAST hazard challenge required to
## stabilize an island (Story Beat 5, "Climax": "the environmental challenges
## become more difficult... a major disaster warning appears"). Every other
## challenge on the island uses the island's normal difficulty.
const CLIMAX_REQUIRED_MULT := 1.4
const CLIMAX_TIME_MULT := 0.85
const CLIMAX_DAMAGE_MULT := 1.5


func _is_climax_challenge() -> bool:
	## True if the challenge about to start is the one that stabilizes the
	## island, i.e. IslandManager.register_success() will return true for it.
	var island := IslandManager.current_island()
	return IslandManager.quests_completed_this_island + 1 >= island.quests_to_unlock


func _get_hazard_def() -> Dictionary:
	var base: Dictionary = HAZARD_DEFS[current_hazard_id].duplicate(true)
	var difficulty: float = IslandManager.current_island().get("difficulty", 1.0)
	base.required = int(ceil(base.required * difficulty))
	base.damage = int(ceil(base.damage * difficulty))
	base.time = max(10.0, base.time - (difficulty - 1.0) * 6.0)  # slightly less time on harder islands

	base.is_climax = _is_climax_challenge()
	if base.is_climax:
		base.required = int(ceil(base.required * CLIMAX_REQUIRED_MULT))
		base.time = max(8.0, base.time * CLIMAX_TIME_MULT)
		base.damage = int(ceil(base.damage * CLIMAX_DAMAGE_MULT))
		base.warning_banner = "MAJOR DISASTER WARNING!"
		base.warn_line = "This is the big one. I need %d before it hits."
	return base


func _process(delta: float) -> void:
	if player == null or state == State.GAME_OVER:
		return
	_update_decoration_depth()

	match state:
		State.EXPLORING:
			# Once the island is stabilized the hazards stop; the player is
			# free to finish side quests and move on with N.
			if not IslandManager.is_current_island_stabilized():
				warning_countdown -= delta
				if warning_countdown <= 0.0:
					_start_warning()
			_process_material_respawn(delta)

		State.CHALLENGE_ACTIVE:
			challenge_time_left -= delta
			timer_updated.emit(challenge_time_left)
			# Progress is what the player is carrying: stockpiling before the
			# warning counts (Maya: "Stockpile plastic before the warning").
			var required: int = current_hazard_def.required
			var have: int = _get_player_material(current_hazard_def.material)
			QuestManager.set_progress(quest_id, have)
			challenge_progress.emit(have, required)
			if have >= required:
				_resolve_challenge(true)
			elif challenge_time_left <= 0.0:
				_resolve_challenge(false)
			elif not _almost_there_shown and have >= required * ALMOST_THERE_THRESHOLD:
				# Storyboard Panel 6 ("Final Collection"): "Almost there!"
				_almost_there_shown = true
				dialogue_shown.emit("Almost there!")


func _get_player_material(material_type: String) -> int:
	match material_type:
		"plastic":
			return player.plastic_count
		"wood":
			return player.wood_count
		_:
			return 0


func _process_material_respawn(delta: float) -> void:
	wood_respawn_timer -= delta
	if wood_respawn_timer <= 0.0:
		wood_respawn_timer = wood_respawn_interval
		for i in wood_respawn_amount:
			_spawn_item_at_random(WOOD_SCENES, wood_container)

	plastic_respawn_timer -= delta
	if plastic_respawn_timer <= 0.0:
		plastic_respawn_timer = plastic_respawn_interval
		for i in plastic_respawn_amount:
			_spawn_item_at_random(PLASTIC_SCENES, plastic_container)


func _spawn_item_at_random(pool: Array[PackedScene], container: Node2D) -> void:
	if container.get_child_count() >= max_items_per_container:
		return
	var scene: PackedScene = pool[randi() % pool.size()]
	var item: Node2D = scene.instantiate() as Node2D
	item.position = _random_spawn_position()
	container.add_child(item)


# --- Environmental Warning Challenge (Panels 4-10, any hazard type) ---

func _start_warning() -> void:
	state = State.WARNING_ISSUED
	current_hazard_def = _get_hazard_def()
	sfx_warning.play()
	banner_shown.emit(current_hazard_def.warning_banner)
	dialogue_shown.emit(current_hazard_def.warn_line % current_hazard_def.required)

	# Only ever one timed-hazard quest in the log at a time.
	QuestManager.clear_active_kind("hazard")
	quest_id = "hazard_%s_%d" % [current_hazard_id, Time.get_ticks_msec()]
	var quest_title: String = current_hazard_def.warning_banner.capitalize()
	if current_hazard_def.get("is_climax", false):
		quest_title = "CLIMAX: " + quest_title
	QuestManager.add_goal(
		quest_id,
		quest_title,
		"Collect %d %s before time runs out! What you're already carrying counts." % [
			current_hazard_def.required, current_hazard_def.material
		],
		"hazard",
		current_hazard_def.material,
		current_hazard_def.required,
		{"icon": "quest_%s" % current_hazard_id}
	)
	QuestManager.set_progress(quest_id, _get_player_material(current_hazard_def.material))

	await get_tree().create_timer(1.5).timeout
	if state == State.GAME_OVER:
		return

	state = State.CHALLENGE_ACTIVE
	_almost_there_shown = false
	challenge_time_left = current_hazard_def.time
	banner_shown.emit(current_hazard_def.challenge_banner % current_hazard_def.required)

	# Make sure there's enough material on the island to actually hit the goal.
	if current_hazard_def.material == "plastic":
		var shortfall: int = int(current_hazard_def.required) - player.plastic_count - plastic_container.get_child_count()
		for i in max(shortfall, 0):
			_spawn_item_at_random(PLASTIC_SCENES, plastic_container)
	else:
		var shortfall2: int = int(current_hazard_def.required) - player.wood_count - wood_container.get_child_count()
		for i in max(shortfall2, 0):
			_spawn_item_at_random(WOOD_SCENES, wood_container)


func _resolve_challenge(success: bool) -> void:
	state = State.RESOLVED
	timer_updated.emit(-1.0)
	hazard_resolved.emit(current_hazard_id, success, current_hazard_def.get("is_climax", false))

	if success:
		sfx_success.play()
		banner_shown.emit(current_hazard_def.success_banner)
		dialogue_shown.emit(current_hazard_def.success_line)
		QuestManager.complete_quest(quest_id)
		QuestManager.complete_quest("maya_intro")
		await get_tree().create_timer(2.0).timeout

		var unlocked: bool = IslandManager.register_success()
		hazard_success_registered.emit()
		if unlocked:
			island_progress_ready.emit()
			if IslandManager.has_next_island():
				dialogue_shown.emit("This island is stabilized! Press N to sail to the next island.")
		else:
			dialogue_shown.emit("Well done. Keep going - check your quest log (Q) for what's next.")
	else:
		sfx_fail.play()
		IslandManager.register_failure()
		# A failed warning is over: take it out of the log instead of leaving
		# it "active" forever (this is what filled the log with duplicates).
		QuestManager.fail_quest(quest_id)
		banner_shown.emit(current_hazard_def.fail_banner)
		dialogue_shown.emit(current_hazard_def.fail_line)
		if _disaster != null:
			# A real, visible disaster plays out in the world (tidal wave /
			# lightning / scorching sun) instead of a flat HP deduction.
			await get_tree().create_timer(1.2).timeout
			await _disaster.play(current_hazard_id, current_hazard_def, player, _island_world_rect())
		else:
			player.take_damage(current_hazard_def.damage)
			await get_tree().create_timer(2.5).timeout

	await get_tree().create_timer(1.0).timeout
	banner_hidden.emit()

	if state != State.GAME_OVER:
		state = State.EXPLORING
		warning_countdown = randf_range(next_warning_delay_range.x, next_warning_delay_range.y)


func _on_player_defeated() -> void:
	state = State.GAME_OVER
	QuestManager.clear_active_kind("hazard")
	banner_hidden.emit()


# --- Side quests: collect 25 bottles/bags, craft something, etc. ---

const MAX_ACTIVE_SIDE_QUESTS := 3


## Every side quest this island can offer, in the order they are handed out.
## Ids include the island id, so each island has its own finite set and the
## same quest can never be added twice.
func _side_quest_templates() -> Array[Dictionary]:
	var idx: int = IslandManager.current_index
	var island_id: String = IslandManager.current_island().id
	var pickups: int = 25 + 5 * idx
	var logs: int = 15 + 3 * idx
	var list: Array[Dictionary] = []
	list.append({
		"id": "side_%s_bottles" % island_id, "title": "Bottle Sweep",
		"desc": "Collect %d plastic bottles." % pickups,
		"kind": "collect", "track": "bottle", "target": pickups,
		"reward": {"wood": 6, "heal": 10}, "icon": "leaf",
	})
	list.append({
		"id": "side_%s_bags" % island_id, "title": "Bag Patrol",
		"desc": "Collect %d plastic bags." % pickups,
		"kind": "collect", "track": "bag", "target": pickups,
		"reward": {"wood": 6, "heal": 10}, "icon": "leaf",
	})
	list.append({
		"id": "side_%s_filter" % island_id, "title": "Clean Water",
		"desc": "Craft a Water Filter (press C).",
		"kind": "craft", "track": "water_filter", "target": 1, "repeatable": true,
		"reward": {"plastic": 8}, "icon": "hammer",
	})
	list.append({
		"id": "side_%s_wood" % island_id, "title": "Timber Run",
		"desc": "Collect %d wood logs." % logs,
		"kind": "collect", "track": "wood", "target": logs,
		"reward": {"plastic": 10, "heal": 10}, "icon": "leaf",
	})
	list.append({
		"id": "side_%s_shelter" % island_id, "title": "Build a Shelter",
		"desc": "Craft a Beach Shelter (press C).",
		"kind": "craft", "track": "beach_shelter", "target": 1, "repeatable": false,
		"reward": {"plastic": 10, "wood": 5}, "icon": "home",
	})
	list.append({
		"id": "side_%s_barrier" % island_id, "title": "Flood Defences",
		"desc": "Craft a Flood Barrier (press C).",
		"kind": "craft", "track": "flood_barrier", "target": 1, "repeatable": false,
		"reward": {"plastic": 10, "wood": 5}, "icon": "wave",
	})
	return list


## Side quests left over from a previous island are dropped when you arrive
## on a new one, so they can't fill the 3 active slots and block new quests.
func _retire_old_side_quests() -> void:
	var prefix: String = "side_%s_" % IslandManager.current_island().id
	for quest in QuestManager.get_active():
		if quest.get("side", false) and not String(quest.id).begins_with(prefix):
			QuestManager.fail_quest(quest.id)


## Tops the log up to MAX_ACTIVE_SIDE_QUESTS active side quests. Returns the
## titles of quests that were newly added.
func _offer_side_quests() -> Array[String]:
	var added: Array[String] = []
	var active_count: int = 0
	for quest in QuestManager.get_active():
		if quest.get("side", false):
			active_count += 1

	for tmpl in _side_quest_templates():
		if active_count >= MAX_ACTIVE_SIDE_QUESTS:
			break
		if QuestManager.has_quest(tmpl.id):
			continue  # already offered (active or done) - never duplicate
		# One-time recipes the player already owns can't be crafted again.
		if tmpl.kind == "craft" and not tmpl.repeatable and player.crafted_ids.has(tmpl.track):
			continue
		QuestManager.add_goal(
			tmpl.id, tmpl.title, tmpl.desc, tmpl.kind, tmpl.track, tmpl.target,
			{"reward": tmpl.reward, "icon": tmpl.icon, "side": true}
		)
		active_count += 1
		added.append(tmpl.title)
	return added


func _announce_new_quests_later(titles: Array[String]) -> void:
	await get_tree().create_timer(5.0).timeout
	if state == State.GAME_OVER:
		return
	dialogue_shown.emit("New quests: %s. Press Q to view your quest log." % ", ".join(PackedStringArray(titles)))


func _on_quest_completed(quest: Dictionary) -> void:
	if not quest.get("side", false) or player == null:
		return
	var reward: Dictionary = quest.get("reward", {})
	var parts: Array[String] = []
	var plastic: int = int(reward.get("plastic", 0))
	var wood: int = int(reward.get("wood", 0))
	var heal_amount: int = int(reward.get("heal", 0))
	if plastic > 0:
		player.collect_material("plastic", plastic)
		parts.append("+%d plastic" % plastic)
	if wood > 0:
		player.collect_material("wood", wood)
		parts.append("+%d wood" % wood)
	if heal_amount > 0:
		player.heal(heal_amount)
		parts.append("+%d HP" % heal_amount)
	sfx_success.play()
	dialogue_shown.emit("Quest complete: %s!  %s" % [quest.title, "  ".join(PackedStringArray(parts))])

	# Hand out the next quest from this island's list after a short breather.
	await get_tree().create_timer(4.0).timeout
	if state == State.GAME_OVER:
		return
	var offered: Array[String] = _offer_side_quests()
	if not offered.is_empty():
		dialogue_shown.emit("New quest: %s. Press Q to view your quest log." % ", ".join(PackedStringArray(offered)))
