extends CanvasLayer
## boat_voyage.gd
## Shown when the player has stabilized an island and presses N: the character
## walks along the pier, boards a boat, casts off and DRIVES it across the sea
## to the next island, which grows out of the horizon until the boat pulls in.
##
## While sailing you steer a little: hold W / Up or S / Down (or the arrow keys)
## to move the boat up and down the screen; the wheel turns with you.
## Press Space / Enter / Esc to skip. `finished` is emitted at the end.

signal finished

const DURATION := 10.0
const PLAYER_SHEET := "res://assets/images/player/Player_Backpack.png"
const PLAYER_SHEET_FALLBACK := "res://assets/images/player/Player.png"
var SFX_START: AudioStream = load("res://assets/audio/island_unlocked.wav") as AudioStream  # runtime load: a missing file no longer stops the game from starting
var SFX_ARRIVE: AudioStream = load("res://assets/audio/success_chime.wav") as AudioStream  # runtime load: a missing file no longer stops the game from starting

## Colours of the destination island, by island id.
const ISLAND_LOOK := {
	"beach": {"sand": Color(0.96, 0.86, 0.58), "hill": Color(0.36, 0.72, 0.36), "tree": Color(0.2, 0.55, 0.28)},
	"forest": {"sand": Color(0.78, 0.7, 0.46), "hill": Color(0.14, 0.5, 0.22), "tree": Color(0.08, 0.38, 0.16)},
	"river": {"sand": Color(0.8, 0.78, 0.6), "hill": Color(0.26, 0.62, 0.52), "tree": Color(0.14, 0.48, 0.4)},
	"village": {"sand": Color(0.82, 0.7, 0.5), "hill": Color(0.58, 0.64, 0.3), "tree": Color(0.4, 0.5, 0.2)},
	"mountain": {"sand": Color(0.72, 0.64, 0.52), "hill": Color(0.55, 0.5, 0.47), "tree": Color(0.4, 0.37, 0.36)},
}

var _from_island: Dictionary = {}
var _to_island: Dictionary = {}
var _art: Node2D
var _fade: ColorRect
var _caption: Label
var _sub_caption: Label
var _skip_label: Label
var _sfx: AudioStreamPlayer
var _sheet: Texture2D
var _time := 0.0
var _scroll := 0.0
var _steer := 0.0          # -1 .. 1 smoothed
var _steer_y := 0.0
var _wheel := 0.0
var _ended := false
var _arrive_sound_played := false


func start(from_island: Dictionary, to_island: Dictionary) -> void:
	_from_island = from_island
	_to_island = to_island


func _ready() -> void:
	layer = 90
	process_mode = Node.PROCESS_MODE_ALWAYS
	_sheet = load(PLAYER_SHEET) as Texture2D
	if _sheet == null:
		_sheet = load(PLAYER_SHEET_FALLBACK) as Texture2D

	_art = Node2D.new()
	_art.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_art.draw.connect(_draw_scene)
	add_child(_art)

	_caption = _make_label(44, Color(1.0, 0.95, 0.75))
	_caption.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_caption.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_caption.offset_top = 46.0
	add_child(_caption)

	_sub_caption = _make_label(26, Color(0.85, 0.95, 1.0))
	_sub_caption.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_sub_caption.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_sub_caption.offset_top = 104.0
	add_child(_sub_caption)

	_skip_label = _make_label(20, Color(1, 1, 1, 0.8))
	_skip_label.text = "W / S to steer     Space to skip >>"
	_skip_label.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	_skip_label.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_skip_label.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_skip_label.offset_right = -28.0
	_skip_label.offset_bottom = -20.0
	add_child(_skip_label)

	_fade = ColorRect.new()
	_fade.color = Color(0, 0, 0, 1)
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_fade)

	_sfx = AudioStreamPlayer.new()
	_sfx.stream = SFX_START
	add_child(_sfx)
	_sfx.play()


func _make_label(size: int, color: Color) -> Label:
	var label := Label.new()
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_outline_color", Color(0.05, 0.1, 0.2))
	label.add_theme_constant_override("outline_size", 8)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label


func _unhandled_input(event: InputEvent) -> void:
	if _ended:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_SPACE or event.keycode == KEY_ENTER or event.keycode == KEY_ESCAPE:
			_finish()
			get_viewport().set_input_as_handled()


func _process(delta: float) -> void:
	if _ended:
		return
	_time += delta

	# Scroll speed: stationary at the dock, ramps up, cruises, eases in to land.
	var speed: float = 0.0
	if _time > 2.2:
		speed = lerpf(0.0, 560.0, smoothstep(2.2, 4.0, _time))
	if _time > 7.2:
		speed = lerpf(560.0, 60.0, smoothstep(7.2, 9.4, _time))
	_scroll += speed * delta

	# Steering (only while actually sailing).
	var target_steer: float = 0.0
	if _time > 2.6 and _time < 8.6:
		target_steer = Input.get_axis("up", "down")
	_steer = lerpf(_steer, target_steer, clampf(delta * 5.0, 0.0, 1.0))
	_steer_y = clampf(_steer_y + _steer * 130.0 * delta, -90.0, 110.0)
	_wheel = lerpf(_wheel, _steer * 1.2, clampf(delta * 6.0, 0.0, 1.0))

	# Captions per stage.
	if _time < 1.8:
		_caption.text = "Boarding the boat"
		_sub_caption.text = "Leaving %s" % String(_from_island.get("name", "the island"))
	elif _time < 2.6:
		_caption.text = "Casting off!"
		_sub_caption.text = ""
	elif _time < 7.4:
		_caption.text = "Sailing to %s" % String(_to_island.get("name", "the next island"))
		_sub_caption.text = "Steer with W / S"
	else:
		_caption.text = "Land ahoy!"
		_sub_caption.text = String(_to_island.get("name", ""))

	# Fade in at the start, fade out at the end.
	var a: float = 0.0
	if _time < 0.8:
		a = 1.0 - _time / 0.8
	elif _time > DURATION - 0.9:
		a = clampf((_time - (DURATION - 0.9)) / 0.9, 0.0, 1.0)
	_fade.color.a = a

	if _time > 8.2 and not _arrive_sound_played:
		_arrive_sound_played = true
		_sfx.stream = SFX_ARRIVE
		_sfx.play()

	_art.queue_redraw()
	if _time >= DURATION:
		_finish()


func _finish() -> void:
	if _ended:
		return
	_ended = true
	_fade.color.a = 1.0
	finished.emit()
	queue_free()


# --- Drawing ------------------------------------------------------------------------------------

func _hash(i: float) -> float:
	return fposmod(sin(i * 12.9898) * 43758.5453, 1.0)


func _draw_scene() -> void:
	var vp: Vector2 = get_viewport().get_visible_rect().size
	var w: float = vp.x
	var h: float = vp.y
	var horizon: float = h * 0.40
	var boat_x: float = w * 0.42 + smoothstep(2.2, 4.0, _time) * 40.0 - smoothstep(7.4, 9.6, _time) * 60.0
	var boat_base_y: float = h * 0.66
	var bob: float = sin(_time * 2.4) * 7.0 + sin(_time * 4.1) * 2.0
	var boat_y: float = boat_base_y + _steer_y + bob
	var roll: float = sin(_time * 1.9) * 0.025 + _steer * 0.05

	_draw_sky(w, h, horizon)
	_draw_destination(w, horizon)
	_draw_sea(w, h, horizon)
	_draw_pier(w, boat_base_y)
	_draw_wake(boat_x, boat_y)
	_draw_boat(boat_x, boat_y, roll)
	_draw_foreground_waves(w, h, boat_y)
	_draw_gulls(w, horizon)


func _draw_sky(w: float, h: float, horizon: float) -> void:
	var bands := 22
	for i in bands:
		var t: float = float(i) / float(bands - 1)
		var c: Color = Color(0.99, 0.84, 0.62).lerp(Color(0.38, 0.68, 0.94), pow(1.0 - t, 0.8))
		_art.draw_rect(Rect2(0.0, horizon * t, w, horizon / float(bands) + 2.0), c)
	# Sun with a soft glow.
	var sun := Vector2(w * 0.78, horizon * 0.55)
	for k in 6:
		_art.draw_circle(sun, 120.0 - float(k) * 16.0, Color(1.0, 0.92, 0.6, 0.10 + 0.05 * float(k)))
	_art.draw_circle(sun, 40.0, Color(1.0, 0.97, 0.8))
	# Drifting clouds.
	for i in 7:
		var cx: float = fposmod(_hash(float(i)) * w * 1.7 - _scroll * 0.04 - _time * 9.0, w * 1.7) - 250.0
		var cy: float = horizon * (0.15 + 0.5 * _hash(float(i) + 40.0))
		var sc: float = 0.7 + _hash(float(i) + 80.0) * 0.8
		for j in 4:
			var off := Vector2(float(j - 1) * 46.0 * sc, sin(float(j) * 1.7) * 9.0 * sc)
			_art.draw_circle(Vector2(cx, cy) + off, (34.0 - absf(float(j) - 1.5) * 6.0) * sc, Color(1, 1, 1, 0.82))


func _draw_destination(w: float, horizon: float) -> void:
	var k: float = smoothstep(3.0, 8.4, _time)
	if k <= 0.0:
		return
	var look: Dictionary = ISLAND_LOOK.get(String(_to_island.get("id", "beach")), ISLAND_LOOK["beach"])
	var sc: float = lerpf(0.25, 1.7, k)
	var cx: float = lerpf(w * 1.2, w * 0.78, k)
	var by: float = horizon + 6.0
	var sand: Color = look["sand"]
	var hill: Color = look["hill"]
	var tree: Color = look["tree"]
	var is_mountain: bool = String(_to_island.get("id", "")) == "mountain"
	# Distant haze makes it look far away at first.
	var haze: float = 1.0 - k * 0.6
	var hazy_hill: Color = hill.lerp(Color(0.62, 0.74, 0.88), haze * 0.6)
	var hazy_sand: Color = sand.lerp(Color(0.8, 0.85, 0.9), haze * 0.5)
	_art.draw_set_transform(Vector2(cx, by), 0.0, Vector2(1.0, 0.16))
	_art.draw_circle(Vector2.ZERO, 330.0 * sc, hazy_sand)
	_art.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if is_mountain:
		var peaks := PackedVector2Array([
			Vector2(cx - 280.0 * sc, by - 4.0), Vector2(cx - 120.0 * sc, by - 190.0 * sc),
			Vector2(cx - 40.0 * sc, by - 90.0 * sc), Vector2(cx + 80.0 * sc, by - 260.0 * sc),
			Vector2(cx + 200.0 * sc, by - 100.0 * sc), Vector2(cx + 290.0 * sc, by - 4.0)])
		_art.draw_colored_polygon(peaks, hazy_hill)
		_art.draw_polyline(PackedVector2Array([Vector2(cx + 50.0 * sc, by - 215.0 * sc), Vector2(cx + 80.0 * sc, by - 260.0 * sc), Vector2(cx + 112.0 * sc, by - 205.0 * sc)]), Color(1, 1, 1, 0.8), 5.0 * sc)
	else:
		_art.draw_circle(Vector2(cx - 120.0 * sc, by - 26.0 * sc), 120.0 * sc, hazy_hill)
		_art.draw_circle(Vector2(cx + 60.0 * sc, by - 40.0 * sc), 150.0 * sc, hazy_hill)
		_art.draw_circle(Vector2(cx + 200.0 * sc, by - 18.0 * sc), 95.0 * sc, hazy_hill)
		_art.draw_rect(Rect2(cx - 330.0 * sc, by - 10.0 * sc, 660.0 * sc, 12.0 * sc), hazy_sand)
		for i in 7:
			var tx: float = cx - 230.0 * sc + float(i) * 78.0 * sc
			var ty: float = by - (30.0 + 40.0 * _hash(float(i) + 5.0)) * sc
			_art.draw_rect(Rect2(tx - 3.0 * sc, ty, 6.0 * sc, 30.0 * sc), Color(0.35, 0.24, 0.14))
			_art.draw_circle(Vector2(tx, ty - 6.0 * sc), 22.0 * sc, tree.lerp(Color(0.62, 0.74, 0.88), haze * 0.4))


func _draw_sea(w: float, h: float, horizon: float) -> void:
	var bands := 18
	for i in bands:
		var t: float = float(i) / float(bands - 1)
		var c: Color = Color(0.36, 0.76, 0.92).lerp(Color(0.04, 0.28, 0.56), t)
		_art.draw_rect(Rect2(0.0, horizon + (h - horizon) * t, w, (h - horizon) / float(bands) + 2.0), c)
	# Sun glitter on the water.
	for i in 26:
		var gx: float = w * 0.78 + (_hash(float(i)) - 0.5) * 360.0 * (0.3 + float(i) / 26.0)
		var gy: float = horizon + 14.0 + float(i) * 9.0
		var wid: float = 12.0 + _hash(float(i) + 9.0) * 40.0
		var tw: float = 0.35 + 0.35 * sin(_time * 4.0 + float(i))
		_art.draw_rect(Rect2(gx - wid * 0.5, gy, wid, 3.0), Color(1, 0.95, 0.75, tw))
	# Wave crests scrolling past, faster the closer they are.
	for row in 9:
		var depth: float = float(row) / 8.0
		var y: float = horizon + 26.0 + depth * (h - horizon - 60.0)
		var sf: float = 0.25 + depth * 1.3
		var amp: float = 2.0 + depth * 6.0
		for col in 12:
			var bx: float = fposmod(float(col) * 230.0 + float(row) * 61.0 - _scroll * sf - _time * 14.0 * sf, w + 320.0) - 160.0
			var pts := PackedVector2Array()
			for j in 7:
				pts.append(Vector2(bx + float(j) * (10.0 + depth * 8.0), y + sin(float(j) * 0.9 + _time * 3.0 + float(row)) * amp))
			_art.draw_polyline(pts, Color(1, 1, 1, 0.22 + depth * 0.2), 2.0 + depth * 2.5)


func _draw_pier(w: float, y_top: float) -> void:
	var left: float = -200.0 - _scroll
	var right: float = w * 0.335 - _scroll
	if right < -80.0:
		return
	var top: float = y_top + 36.0
	# Planks.
	_art.draw_rect(Rect2(left, top, right - left, 26.0), Color(0.56, 0.38, 0.22))
	var px: float = left
	while px < right:
		_art.draw_line(Vector2(px, top), Vector2(px, top + 26.0), Color(0.33, 0.21, 0.12), 3.0)
		px += 48.0
	_art.draw_rect(Rect2(left, top, right - left, 5.0), Color(0.75, 0.55, 0.34))
	# Posts going down into the water.
	var post: float = right - 16.0
	while post > left:
		_art.draw_rect(Rect2(post - 8.0, top + 26.0, 16.0, 70.0), Color(0.34, 0.22, 0.13))
		_art.draw_rect(Rect2(post - 8.0, top - 34.0, 16.0, 34.0), Color(0.46, 0.3, 0.17))
		post -= 190.0
	# Little lantern at the end of the pier.
	_art.draw_circle(Vector2(right - 16.0, top - 42.0), 9.0, Color(1.0, 0.85, 0.4, 0.9))
	# Mooring rope until we cast off.
	if _time < 2.3:
		var rope_sag: float = 14.0 * (1.0 - smoothstep(1.6, 2.3, _time))
		_art.draw_polyline(PackedVector2Array([
			Vector2(right - 16.0, top - 10.0),
			Vector2(right + 30.0, top + 6.0 + rope_sag),
			Vector2(right + 76.0, top + 4.0)]), Color(0.85, 0.75, 0.5), 4.0)


func _draw_wake(bx: float, by: float) -> void:
	var speed01: float = clampf(smoothstep(2.2, 4.0, _time) * (1.0 - smoothstep(8.2, 9.8, _time) * 0.8), 0.0, 1.0)
	if speed01 <= 0.02:
		return
	var y: float = by + 92.0
	# White foam fanning out behind the stern.
	var tri := PackedVector2Array([
		Vector2(bx - 150.0, y - 6.0), Vector2(bx - 150.0 - 520.0 * speed01, y - 30.0),
		Vector2(bx - 150.0 - 640.0 * speed01, y + 4.0), Vector2(bx - 150.0 - 520.0 * speed01, y + 36.0),
		Vector2(bx - 150.0, y + 12.0)])
	_art.draw_colored_polygon(tri, Color(1, 1, 1, 0.40 * speed01))
	for i in 18:
		var t: float = fposmod(float(i) * 0.137 + _time * 0.9, 1.0)
		var px: float = bx - 160.0 - t * 560.0 * speed01
		var py: float = y + (_hash(float(i)) - 0.5) * 50.0 * t + 8.0
		_art.draw_circle(Vector2(px, py), 5.0 + 9.0 * (1.0 - t), Color(1, 1, 1, 0.55 * (1.0 - t) * speed01))
	# Spray at the bow.
	for i in 10:
		var t2: float = fposmod(float(i) * 0.19 + _time * 2.2, 1.0)
		var sx: float = bx + 220.0 + t2 * 60.0
		var sy: float = y - 12.0 - sin(t2 * PI) * 40.0
		_art.draw_circle(Vector2(sx, sy), 4.0, Color(1, 1, 1, 0.8 * (1.0 - t2) * speed01))


func _draw_boat(bx: float, by: float, roll: float) -> void:
	_art.draw_set_transform(Vector2(bx, by + 40.0), roll, Vector2.ONE)
	# Hull.
	var hull := PackedVector2Array([
		Vector2(-165.0, 0.0), Vector2(175.0, 0.0), Vector2(240.0, -36.0),
		Vector2(160.0, 62.0), Vector2(-125.0, 62.0), Vector2(-170.0, 30.0)])
	_art.draw_colored_polygon(hull, Color(0.62, 0.38, 0.2))
	_art.draw_polyline(PackedVector2Array([hull[0], hull[1], hull[2], hull[3], hull[4], hull[5], hull[0]]), Color(0.28, 0.16, 0.08), 5.0)
	# Planks and the red stripe.
	_art.draw_line(Vector2(-150.0, 18.0), Vector2(205.0, 18.0), Color(0.45, 0.27, 0.14), 3.0)
	_art.draw_line(Vector2(-140.0, 40.0), Vector2(180.0, 40.0), Color(0.45, 0.27, 0.14), 3.0)
	_art.draw_line(Vector2(-165.0, 6.0), Vector2(190.0, 6.0), Color(0.82, 0.22, 0.2), 8.0)
	# Cabin.
	_art.draw_rect(Rect2(-130.0, -78.0, 86.0, 78.0), Color(0.93, 0.88, 0.76))
	_art.draw_rect(Rect2(-130.0, -78.0, 86.0, 78.0), Color(0.3, 0.2, 0.12), false, 4.0)
	_art.draw_rect(Rect2(-142.0, -92.0, 110.0, 16.0), Color(0.7, 0.2, 0.18))
	_art.draw_rect(Rect2(-112.0, -58.0, 28.0, 26.0), Color(0.55, 0.82, 0.95))
	_art.draw_rect(Rect2(-112.0, -58.0, 28.0, 26.0), Color(0.3, 0.2, 0.12), false, 3.0)
	# Mast, sail and flag.
	_art.draw_line(Vector2(70.0, 0.0), Vector2(70.0, -250.0), Color(0.35, 0.22, 0.12), 8.0)
	var billow: float = 14.0 + 8.0 * sin(_time * 3.0)
	var sail := PackedVector2Array([
		Vector2(76.0, -240.0), Vector2(76.0 + 120.0 + billow, -150.0),
		Vector2(76.0 + 150.0 + billow, -52.0), Vector2(76.0, -34.0)])
	_art.draw_colored_polygon(sail, Color(0.98, 0.96, 0.9))
	_art.draw_polyline(PackedVector2Array([sail[0], sail[1], sail[2], sail[3], sail[0]]), Color(0.45, 0.4, 0.34), 3.0)
	_art.draw_line(Vector2(76.0, -150.0), Vector2(76.0 + 134.0 + billow, -102.0), Color(0.8, 0.76, 0.68), 2.0)
	var flag_wave: float = sin(_time * 7.0) * 6.0
	_art.draw_colored_polygon(PackedVector2Array([
		Vector2(70.0, -250.0), Vector2(30.0, -240.0 + flag_wave), Vector2(70.0, -226.0)]), Color(0.2, 0.75, 0.4))
	# Steering wheel in front of the cabin.
	var wheel_c := Vector2(-20.0, -34.0)
	_art.draw_line(wheel_c, wheel_c + Vector2(0.0, 34.0), Color(0.3, 0.18, 0.1), 6.0)
	_art.draw_circle(wheel_c, 20.0, Color(0.3, 0.18, 0.1))
	_art.draw_circle(wheel_c, 15.0, Color(0.62, 0.38, 0.2))
	for s in 4:
		var ang: float = _wheel + float(s) * PI * 0.5
		_art.draw_line(wheel_c - Vector2(cos(ang), sin(ang)) * 24.0, wheel_c + Vector2(cos(ang), sin(ang)) * 24.0, Color(0.3, 0.18, 0.1), 4.0)
	# The survivor: walks along the pier, steps aboard, then stands at the wheel.
	_draw_survivor(bx, by, roll)
	_art.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_survivor(bx: float, _by: float, _roll: float) -> void:
	if _sheet == null:
		return
	var vp: Vector2 = get_viewport().get_visible_rect().size
	var board_t: float = smoothstep(0.5, 1.7, _time)
	var start_x: float = vp.x * 0.20 - _scroll
	var deck_x: float = bx - 4.0
	var world_x: float = lerpf(start_x, deck_x, board_t)
	# Boat-space position (the transform already includes the boat's position + roll).
	var local_x: float = world_x - bx
	var walking: bool = board_t > 0.0 and board_t < 1.0
	var row: int = 128 if walking else 32
	var col: int = int(_time * 10.0) % 6 if walking else int(_time * 5.0) % 6
	var region := Rect2(float(col * 32), float(row), 32.0, 32.0)
	var size := Vector2(160.0, 160.0)
	# Feet stand on the deck line (y = 0 in boat space) once aboard, on the pier before.
	var feet_y: float = 0.0 if board_t > 0.6 else -6.0
	var hop: float = 0.0
	if walking:
		hop = -absf(sin(_time * 10.0)) * 6.0
	_art.draw_texture_rect_region(_sheet, Rect2(Vector2(local_x - 80.0, feet_y - 118.0 + hop), size), region)


func _draw_foreground_waves(w: float, h: float, boat_y: float) -> void:
	# A band of water in front of the hull so the boat really sits IN the sea.
	var y0: float = boat_y + 78.0
	var pts := PackedVector2Array()
	var x: float = 0.0
	while x <= w + 40.0:
		pts.append(Vector2(x, y0 + sin(x * 0.02 + _time * 3.2) * 5.0))
		x += 40.0
	var poly := PackedVector2Array(pts)
	poly.append(Vector2(w + 40.0, h + 10.0))
	poly.append(Vector2(0.0, h + 10.0))
	_art.draw_colored_polygon(poly, Color(0.1, 0.4, 0.68, 0.55))
	_art.draw_polyline(pts, Color(1, 1, 1, 0.5), 4.0)


func _draw_gulls(w: float, horizon: float) -> void:
	for i in 3:
		var gx: float = fposmod(w * (0.2 + 0.3 * float(i)) + _time * (40.0 + 14.0 * float(i)) - _scroll * 0.08, w + 200.0) - 100.0
		var gy: float = horizon * (0.35 + 0.15 * float(i)) + sin(_time * 1.3 + float(i)) * 16.0
		var flap: float = sin(_time * 8.0 + float(i) * 2.0) * 6.0
		_art.draw_polyline(PackedVector2Array([Vector2(gx - 14.0, gy - flap), Vector2(gx, gy), Vector2(gx + 14.0, gy - flap)]), Color(1, 1, 1, 0.9), 3.0)
