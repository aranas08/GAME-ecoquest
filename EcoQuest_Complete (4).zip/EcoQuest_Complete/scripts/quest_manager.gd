extends Node
## quest_manager.gd (Autoload: QuestManager)
## Tracks multiple concurrent quests so the HUD/quest log can list them.
##
## A quest is a Dictionary:
##   id, title, desc          - identity + text
##   status                   - "active" or "completed"
##   kind                     - "collect" | "craft" | "hazard" | "story"
##   track                    - what it counts: "bottle" / "bag" / "wood" for
##                              collect quests, a recipe id for craft quests,
##                              a material for hazard quests
##   target, progress         - counter (target == 0 means "no counter")
##   reward                   - { "plastic": int, "wood": int, "heal": int }
##   icon                     - icon file name in assets/images/UI/icons/
##   side                     - true for side quests handed out by the level
##
## Collect/craft quests advance themselves: the level forwards the player's
## pickups and crafts to report_collected() / report_crafted(), and the quest
## completes the moment progress reaches target. Hazard (timed) quests are
## transient: they are completed on success and REMOVED on failure, so a
## failed warning can never pile up in the log.

signal quest_added(quest: Dictionary)
signal quest_updated(quest: Dictionary)
signal quest_completed(quest: Dictionary)
signal quest_failed(quest: Dictionary)

var quests: Dictionary = {}  # id -> quest dict
var _order: Array[String] = []


func has_quest(id: String) -> bool:
	return quests.has(id)


func add_quest(id: String, title: String, desc: String, extra: Dictionary = {}) -> void:
	if quests.has(id):
		return
	var quest: Dictionary = {
		"id": id, "title": title, "desc": desc, "status": "active",
		"kind": "story", "track": "", "target": 0, "progress": 0,
		"reward": {}, "icon": "", "side": false,
	}
	quest.merge(extra, true)
	quests[id] = quest
	_order.append(id)
	quest_added.emit(quest)


## Convenience for counter quests (collect X / craft X / timed hazards).
func add_goal(id: String, title: String, desc: String, kind: String, track: String,
		target: int, extra: Dictionary = {}) -> void:
	var data: Dictionary = {"kind": kind, "track": track, "target": target}
	data.merge(extra, true)
	add_quest(id, title, desc, data)


func update_quest_desc(id: String, desc: String) -> void:
	if not quests.has(id):
		return
	quests[id].desc = desc
	quest_updated.emit(quests[id])


## Sets progress directly (used by timed hazard quests, which mirror the
## player's stockpile). Does not auto-complete.
func set_progress(id: String, value: int) -> void:
	if not quests.has(id) or quests[id].status != "active":
		return
	var clamped: int = clampi(value, 0, int(quests[id].target))
	if clamped == int(quests[id].progress):
		return
	quests[id].progress = clamped
	quest_updated.emit(quests[id])


func complete_quest(id: String) -> void:
	if not quests.has(id) or quests[id].status == "completed":
		return
	quests[id].status = "completed"
	if int(quests[id].target) > 0:
		quests[id].progress = quests[id].target
	quest_completed.emit(quests[id])


## Removes a quest that was failed/abandoned so it doesn't sit in the
## active list forever.
func fail_quest(id: String) -> void:
	if not quests.has(id):
		return
	var quest: Dictionary = quests[id]
	quests.erase(id)
	_order.erase(id)
	quest_failed.emit(quest)


## Removes every ACTIVE quest of a kind (safety net for leftover hazards).
func clear_active_kind(kind: String) -> void:
	for id in _order.duplicate():
		var quest: Dictionary = quests[id]
		if quest.status == "active" and quest.get("kind", "") == kind:
			fail_quest(id)


func is_completed(id: String) -> bool:
	return quests.has(id) and quests[id].status == "completed"


# --- Progress reporting (called by the level) ---

## A world pickup happened. `item_kind` is "bottle" / "bag" / "wood".
func report_collected(material: String, item_kind: String, amount: int) -> void:
	for id in _order.duplicate():
		var quest: Dictionary = quests[id]
		if quest.status != "active" or quest.get("kind", "") != "collect":
			continue
		var track: String = quest.get("track", "")
		if track == item_kind or track == material:
			_advance(id, amount)


## The player crafted something.
func report_crafted(recipe_id: String) -> void:
	for id in _order.duplicate():
		var quest: Dictionary = quests[id]
		if quest.status != "active" or quest.get("kind", "") != "craft":
			continue
		if quest.get("track", "") == recipe_id:
			_advance(id, 1)


func _advance(id: String, amount: int) -> void:
	var quest: Dictionary = quests[id]
	quest.progress = mini(int(quest.progress) + amount, int(quest.target))
	if int(quest.progress) >= int(quest.target):
		complete_quest(id)
	else:
		quest_updated.emit(quest)


func get_all_in_order() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for id in _order:
		result.append(quests[id])
	return result


func get_active() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for quest in get_all_in_order():
		if quest.status == "active":
			result.append(quest)
	return result


func get_completed() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for quest in get_all_in_order():
		if quest.status == "completed":
			result.append(quest)
	return result


func reset() -> void:
	quests.clear()
	_order.clear()


## Plain-data snapshot for SaveManager. `_order` is included so
## get_all_in_order() comes back in the same order after a reload.
func serialize() -> Dictionary:
	return {
		"quests": quests.duplicate(true),
		"order": _order.duplicate(),
	}


func restore(data: Dictionary) -> void:
	reset()
	var restored_quests: Dictionary = data.get("quests", {})
	var restored_order: Array = data.get("order", [])
	for id in restored_order:
		_restore_one(String(id), restored_quests)
	# Catch anything present in `quests` but missing from `order` (keeps a
	# hand-edited save file from losing quests).
	for id in restored_quests.keys():
		if not _order.has(String(id)):
			_restore_one(String(id), restored_quests)


func _restore_one(id: String, source: Dictionary) -> void:
	if not source.has(id) or quests.has(id):
		return
	var quest: Dictionary = source[id]
	# Timed hazard quests only make sense while their countdown is running,
	# which is never saved. Older builds also stored them as ordinary quests
	# (id "<hazard>_warning_<ticks>") and never closed failed ones, which is
	# where the pile of duplicate "Flood Warning!" entries came from. Drop both.
	if quest.get("kind", "") == "hazard" or "_warning_" in id:
		return
	# JSON turns every number into a float; put the counters back to ints and
	# fill in fields that saves from older builds don't have.
	var fixed: Dictionary = {
		"id": id, "title": "", "desc": "", "status": "active",
		"kind": "story", "track": "", "target": 0, "progress": 0,
		"reward": {}, "icon": "", "side": false,
	}
	fixed.merge(quest, true)
	fixed.target = int(fixed.target)
	fixed.progress = int(fixed.progress)
	var reward: Dictionary = {}
	for key in fixed.reward:
		reward[key] = int(fixed.reward[key])
	fixed.reward = reward
	quests[id] = fixed
	_order.append(id)
