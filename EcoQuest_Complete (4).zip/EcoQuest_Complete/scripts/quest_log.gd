extends CanvasLayer
## quest_log.gd
## Displays multiple concurrent quests (active + completed) from the
## QuestManager autoload. Toggle with the "toggle_quest_log" action (Q).

const ICON_DIR := "res://assets/images/UI/icons/"

# Quests don't carry their own icon, but hazard quests embed the hazard id
# in their generated id ("flood_warning_172..."), so we can sniff it out.
const HAZARD_ICONS := {
	"flood": "quest_flood",
	"storm": "quest_storm",
	"heat": "quest_heat",
}

const C_TITLE := Color(1, 0.988, 0.965)
const C_DESC := Color(0.784, 0.812, 0.839)
const C_DONE_TITLE := Color(0.68, 0.85, 0.68)
const C_DONE_DESC := Color(0.58, 0.65, 0.58)

@onready var panel: Panel = %QuestPanel
@onready var frame: PanelContainer = %Frame
@onready var active_list: VBoxContainer = %ActiveList
@onready var completed_list: VBoxContainer = %CompletedList
@onready var completed_divider: HBoxContainer = %CompletedDivider
@onready var count_label: Label = %QuestCountLabel
@onready var close_button: Button = %CloseButton


func _ready() -> void:
	panel.visible = false
	close_button.pressed.connect(_close)
	# Only rebuild while the log is open; _open() refreshes it anyway.
	QuestManager.quest_added.connect(func(_q): _refresh_if_open())
	QuestManager.quest_updated.connect(func(_q): _refresh_if_open())
	QuestManager.quest_completed.connect(func(_q): _refresh_if_open())
	QuestManager.quest_failed.connect(func(_q): _refresh_if_open())


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("toggle_quest_log"):
		if panel.visible:
			_close()
		else:
			_open()
		get_viewport().set_input_as_handled()
		return
	if panel.visible and event.is_action_pressed("ui_cancel"):
		_close()
		get_viewport().set_input_as_handled()


func open_log() -> void:
	_refresh()
	panel.visible = true
	_play_intro()


func _open() -> void:
	open_log()


func _close() -> void:
	panel.visible = false


func _play_intro() -> void:
	frame.modulate.a = 0.0
	await get_tree().process_frame
	frame.pivot_offset = frame.size / 2.0
	frame.scale = Vector2(0.94, 0.94)
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(frame, "modulate:a", 1.0, 0.16)
	tween.tween_property(frame, "scale", Vector2.ONE, 0.22) \
		.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


# ---------------------------------------------------------------- style utils

func _box(bg: Color, border: Color, border_width: int = 2, radius: int = 8,
		pad_x: int = 14, pad_y: int = 10) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_border_width_all(border_width)
	sb.border_color = border
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = pad_x
	sb.content_margin_right = pad_x
	sb.content_margin_top = pad_y
	sb.content_margin_bottom = pad_y
	return sb


func _refresh_if_open() -> void:
	if panel.visible:
		_refresh()


func _icon_for(quest: Dictionary) -> String:
	var explicit_icon: String = str(quest.get("icon", ""))
	if explicit_icon != "":
		return explicit_icon
	for hazard_id in HAZARD_ICONS:
		if str(quest.id).begins_with(hazard_id):
			return HAZARD_ICONS[hazard_id]
	return "quest_generic"


func _icon_rect(path: String, px: float) -> TextureRect:
	var tex := TextureRect.new()
	tex.texture = load(path)
	tex.custom_minimum_size = Vector2(px, px)
	tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tex.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return tex


# ------------------------------------------------------------------ refresh

func _refresh() -> void:
	for child in active_list.get_children():
		active_list.remove_child(child)
		child.queue_free()
	for child in completed_list.get_children():
		completed_list.remove_child(child)
		child.queue_free()

	var active := QuestManager.get_active()
	count_label.text = "%d active" % active.size()
	if active.is_empty():
		active_list.add_child(_make_empty_label("No active quests right now."))
	for quest in active:
		active_list.add_child(_make_quest_row(quest, false))

	var completed := QuestManager.get_completed()
	completed_divider.visible = true
	if completed.is_empty():
		completed_list.add_child(_make_empty_label("Nothing completed yet."))
	for quest in completed:
		completed_list.add_child(_make_quest_row(quest, true))


func _make_quest_row(quest: Dictionary, done: bool) -> Control:
	var row := PanelContainer.new()
	var bg := Color(0.114, 0.157, 0.212) if not done else Color(0.098, 0.129, 0.106)
	var border := Color(0.267, 0.322, 0.388) if not done else Color(0.216, 0.29, 0.216)
	row.add_theme_stylebox_override("panel", _box(bg, border, 2, 8))

	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 16)
	row.add_child(hbox)

	# Icon with a small exclaim/check badge overlapping the top-left corner.
	var icon_slot := Control.new()
	icon_slot.custom_minimum_size = Vector2(60, 60)
	icon_slot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hbox.add_child(icon_slot)

	var icon_frame := PanelContainer.new()
	icon_frame.set_anchors_preset(Control.PRESET_FULL_RECT)
	icon_frame.add_theme_stylebox_override(
		"panel", _box(Color(0.086, 0.1, 0.129), Color(0.667, 0.412, 0.176), 2, 7, 6, 6)
	)
	icon_frame.add_child(_icon_rect("%s%s.png" % [ICON_DIR, _icon_for(quest)], 40))
	icon_slot.add_child(icon_frame)

	var badge := _icon_rect(
		"%scheck_badge.png" % ICON_DIR if done else "%sexclaim_badge.png" % ICON_DIR,
		18 if done else 16
	)
	badge.set_anchors_preset(Control.PRESET_TOP_LEFT)
	badge.position = Vector2(-6, -6)
	icon_slot.add_child(badge)

	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	texts.add_theme_constant_override("separation", 4)
	hbox.add_child(texts)

	var title := Label.new()
	title.text = quest.title
	title.add_theme_font_size_override("font_size", 21)
	title.add_theme_color_override("font_color", C_DONE_TITLE if done else C_TITLE)
	texts.add_child(title)

	var desc := Label.new()
	desc.text = quest.desc
	desc.add_theme_font_size_override("font_size", 16)
	desc.add_theme_color_override("font_color", C_DONE_DESC if done else C_DESC)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD
	texts.add_child(desc)

	# Counter quests ("collect 25 bottles", "craft a filter") show progress.
	var target: int = int(quest.get("target", 0))
	if target > 0:
		var progress: int = int(quest.get("progress", 0))
		desc.text = "%s  (%d/%d)" % [quest.desc, progress, target]
		if not done:
			var bar := ProgressBar.new()
			bar.min_value = 0
			bar.max_value = target
			bar.value = progress
			bar.show_percentage = false
			bar.custom_minimum_size = Vector2(0, 10)
			bar.add_theme_stylebox_override(
				"background", _box(Color(0.086, 0.1, 0.129), Color(0.267, 0.322, 0.388), 1, 4, 0, 0))
			bar.add_theme_stylebox_override(
				"fill", _box(Color(0.945, 0.647, 0.204), Color(0.945, 0.647, 0.204), 0, 4, 0, 0))
			texts.add_child(bar)

	if not done:
		var chevron := _icon_rect("%schevron.png" % ICON_DIR, 22)
		chevron.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		hbox.add_child(chevron)
	else:
		var spacer := Control.new()
		spacer.custom_minimum_size = Vector2(22, 0)
		hbox.add_child(spacer)

	return row


func _make_empty_label(text: String) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 16)
	l.add_theme_color_override("font_color", Color(0.55, 0.58, 0.6))
	return l
