extends Node2D
## main.gd
## Wires the HUD, environment FX, and game-over screen up to whichever
## level/player are currently in the scene, and handles island progression.

@onready var level_root: Node2D = $LevelRoot
@onready var hud: CanvasLayer = $HUD
@onready var environment_fx: CanvasLayer = $EnvironmentFX
@onready var game_over: CanvasLayer = $GameOver
@onready var victory: CanvasLayer = $Victory

const BoatVoyageScript := preload("res://scripts/boat_voyage.gd")

var _can_advance_island: bool = false


func _ready() -> void:
	hud.connect_to_level(level_root)
	level_root.hazard_resolved.connect(_on_hazard_resolved)
	level_root.island_progress_ready.connect(_on_island_progress_ready)
	level_root.hazard_success_registered.connect(_on_hazard_success_registered)

	# The player is created inside LevelRoot's _ready(); base_level.gd runs
	# its own _ready() before this one in the same frame, so the player
	# group is already populated by the time we get here.
	var player := get_tree().get_first_node_in_group("player")
	if player:
		hud.connect_to_player(player)
		player.defeated.connect(_on_player_defeated)
	else:
		push_warning("main.gd: no player found in group 'player'.")

	# Continuing a save on an island that was already stabilized: the N prompt
	# (or the ending) has to come back, since the flag below isn't saved.
	if IslandManager.is_current_island_stabilized():
		_on_island_progress_ready()


func _unhandled_input(event: InputEvent) -> void:
	if _can_advance_island and event.is_action_pressed("advance_island"):
		_can_advance_island = false
		get_viewport().set_input_as_handled()
		var player := get_tree().get_first_node_in_group("player")
		if player:
			IslandManager.save_player_state(player)
		_sail_to_next_island(player)


## Mission done: the survivor boards a boat and drives it to the next island
## (boat_voyage.gd), then the next island loads.
func _sail_to_next_island(player) -> void:
	hud.set_advance_hint(false)
	if player:
		player.set_physics_process(false)
		player.velocity = Vector2.ZERO
	var next_index: int = mini(IslandManager.current_index + 1, IslandManager.ISLANDS.size() - 1)
	var voyage = BoatVoyageScript.new()
	add_child(voyage)
	voyage.start(IslandManager.current_island(), IslandManager.ISLANDS[next_index])
	await voyage.finished
	IslandManager.advance_island()
	SaveManager.save_game()
	get_tree().reload_current_scene()


func _on_hazard_resolved(hazard_type: String, success: bool, is_climax: bool) -> void:
	environment_fx.play_effect(hazard_type, success, is_climax)


## Runs after IslandManager has counted the survived hazard, so the autosave
## (and the HUD's island progress) include it. Saving earlier - as the
## original hazard_resolved handler did - stored a count that was one behind.
func _on_hazard_success_registered() -> void:
	hud.refresh_island_progress()
	var player := get_tree().get_first_node_in_group("player")
	if player:
		SaveManager.save_game(player)


func _on_island_progress_ready() -> void:
	_can_advance_island = IslandManager.has_next_island()
	hud.set_advance_hint(_can_advance_island)
	if _can_advance_island:
		return
	# No islands left: this is the end of the run (Story Beat 6).
	level_root.dialogue_shown.emit(
		"You've stabilized every island on the map. Well done, %s." % GameBoot.player_name
	)
	var player := get_tree().get_first_node_in_group("player")
	SaveManager.save_game(player)
	await get_tree().create_timer(2.0).timeout
	victory.show_victory(player)


func _on_player_defeated() -> void:
	var island_name: String = IslandManager.current_island().name
	var message: String = "The environmental hazards on %s were too much this time, %s." % [
		island_name, GameBoot.player_name
	]
	var cause: String = ""
	var player := get_tree().get_first_node_in_group("player")
	if player:
		cause = String(player.get("death_cause"))
	if cause == "flood":
		message = "The tidal wave swept over you on %s, %s. Next time, run for Maya's house!" % [
			island_name, GameBoot.player_name
		]
	# A short beat so you can see the character go down before the screen appears.
	await get_tree().create_timer(1.3).timeout
	game_over.show_game_over(message)
