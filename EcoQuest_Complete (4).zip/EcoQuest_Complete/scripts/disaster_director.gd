extends Node2D
## disaster_director.gd
## Plays the three hazards as real, in-world disasters when the player fails a
## warning challenge. Everything is drawn in world space, so the disaster is
## something you can see coming and run from:
##
##  FLOOD  - a tidal wave. A wall of foaming water sweeps across the whole island
##           from one shore. The exact moment its edge touches the player's feet
##           the player dies (same wavy edge for drawing and for the kill test).
##           Maya's house is the one shelter: indoors you are safe, and an arrow
##           points the way. Leave the house before the water drains and you die.
##  STORM  - lightning. Glowing target rings mark where bolts are about to land;
##           get out of the ring before the bolt hits. Rain, flashes, scorch marks.
##  HEAT   - scorching sun pulses. Each pulse burns you unless you stand in shade
##           (under a tree / rock / the house) or indoors. Safe spots are ringed.
##
## base_level.gd calls `await play(...)` and carries on when it returns.

signal message(banner: String, line: String)

var ALARM_SFX: AudioStream = load("res://assets/audio/warning_alarm.wav") as AudioStream  # runtime load: a missing file no longer stops the game from starting
var THUD_SFX: AudioStream = load("res://assets/audio/fail_thud.wav") as AudioStream  # runtime load: a missing file no longer stops the game from starting

# --- Flood tuning ---------------------------------------------------------------------
const FLOOD_START_SPEED := 150.0   # px/s when the wave first appears (far offshore)
const FLOOD_SPEED := 400.0         # px/s at full speed (faster than the player's 300)
const FLOOD_RAMP_TIME := 3.5       # seconds to build up to full speed
const FLOOD_MARGIN := 700.0        # offshore distance the wave starts from
const FLOOD_BACK := 2600.0         # how far behind the front the water is drawn
const FLOOD_HOLD_TIME := 2.5       # the island stays under water this long
const FLOOD_RECEDE_TIME := 3.5     # then the water drains away
const FOAM_STEP := 28.0
const HOUSE_IS_SHELTER := true     # set false to make the flood lethal even indoors

# --- Storm tuning ---------------------------------------------------------------------------
const STRIKE_RADIUS := 95.0
const STRIKE_WARN_TIME := 1.15
const STRIKE_GAP := 0.65

# --- Heat tuning ---------------------------------------------------------------------------------
const HEAT_PULSES := 5
const HEAT_PULSE_GAP := 1.7
const HEAT_WARN_TIME := 0.9
const SHADE_DEFAULT_RADIUS := 150.0

var _player: CharacterBody2D
var _bounds := Rect2(0, 0, 2304, 1664)
var _mode := ""
var _time := 0.0
var _phase_t := 0.0
var _alarm: AudioStreamPlayer
var _thud: AudioStreamPlayer

# flood state
var _flood_phase := ""
var _flood_dir := Vector2.RIGHT
var _flood_perp := Vector2.DOWN
var _flood_origin := Vector2.ZERO
var _flood_total := 0.0
var _flood_front := 0.0
var _flood_q_half := 1500.0
var _flood_alpha := 1.0
var _flood_lethal := false
var _flood_killed := false

# storm state
var _strikes: Array[Dictionary] = []
var _scorches: Array[Dictionary] = []
var _rain := 0.0
var _rain_target := 0.0
var _flash := 0.0

# heat state
var _heat_level := 0.0
var _heat_warn := 0.0
var _heat_pulse_flash := 0.0
var _heat_active := false


func _ready() -> void:
	z_index = 60
	_alarm = AudioStreamPlayer.new()
	_alarm.stream = ALARM_SFX
	add_child(_alarm)
	_thud = AudioStreamPlayer.new()
	_thud.stream = THUD_SFX
	add_child(_thud)


## Runs one disaster to the end. `def` is the hazard definition from base_level.
func play(hazard_id: String, def: Dictionary, player: CharacterBody2D, bounds: Rect2) -> void:
	_player = player
	_bounds = bounds
	match hazard_id:
		"flood":
			await _run_flood(def)
		"storm":
			await _run_storm(def)
		"heat":
			await _run_heat(def)
		_:
			await get_tree().create_timer(1.5).timeout
	_mode = ""
	queue_redraw()


func _physics_process(delta: float) -> void:
	_time += delta
	match _mode:
		"flood":
			_step_flood(delta)
		"storm":
			_step_storm(delta)
		"heat":
			_step_heat(delta)
	_flash = maxf(_flash - delta * 2.4, 0.0)
	_rain = move_toward(_rain, _rain_target, delta * 0.8)
	if _mode != "" or _flash > 0.0 or not _scorches.is_empty():
		queue_redraw()


func _player_alive() -> bool:
	return _player != null and is_instance_valid(_player) and not _player.is_defeated


func _player_feet() -> Vector2:
	return to_local(_player.global_position + Vector2(0.0, 5.5) * _player.scale)


func _player_safe_indoors() -> bool:
	return _player.indoors


# =====================================================================================
#  FLOOD
# =====================================================================================

func _run_flood(_def: Dictionary) -> void:
	_setup_flood()
	_mode = "flood"
	_flood_phase = "surge"
	_phase_t = 0.0
	_flood_alpha = 1.0
	_flood_lethal = true
	_flood_killed = false
	_alarm.play()
	while _flood_phase != "done" and _player_alive():
		await get_tree().process_frame
	if not _player_alive():
		# Let the water finish its run over the island for a moment.
		await get_tree().create_timer(1.2).timeout


func _setup_flood() -> void:
	var dirs: Array[Vector2] = [Vector2.RIGHT, Vector2.LEFT, Vector2.DOWN, Vector2.UP]
	var player_pos: Vector2 = to_local(_player.global_position)
	var house := get_tree().get_first_node_in_group("maya_home") as Node2D
	var scored: Array[Dictionary] = []
	for d in dirs:
		var perp := Vector2(-d.y, d.x)
		var extent: float = absf(d.x) * _bounds.size.x + absf(d.y) * _bounds.size.y
		var origin: Vector2 = _bounds.get_center() - d * (extent * 0.5 + FLOOD_MARGIN)
		var head_start: float = (player_pos - origin).dot(d)   # more = more time to react
		var ok := true
		if house != null:
			var to_house: Vector2 = (to_local(house.global_position) - player_pos)
			if to_house.length() > 1.0 and to_house.normalized().dot(d) < -0.2:
				ok = false   # never make the player run INTO the wave to reach shelter
		scored.append({"dir": d, "head": head_start, "ok": ok, "perp": perp})
	scored.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a.head) > float(b.head))
	var pool: Array[Dictionary] = []
	for s in scored:
		if bool(s.ok):
			pool.append(s)
	if pool.is_empty():
		pool = scored
	var pick: Dictionary = pool[randi() % mini(2, pool.size())]
	_flood_dir = pick.dir
	_flood_perp = Vector2(-_flood_dir.y, _flood_dir.x)
	var ext: float = absf(_flood_dir.x) * _bounds.size.x + absf(_flood_dir.y) * _bounds.size.y
	var perp_ext: float = absf(_flood_perp.x) * _bounds.size.x + absf(_flood_perp.y) * _bounds.size.y
	_flood_origin = _bounds.get_center() - _flood_dir * (ext * 0.5 + FLOOD_MARGIN)
	_flood_total = ext + FLOOD_MARGIN * 2.0
	_flood_q_half = perp_ext * 0.5 + 600.0
	_flood_front = 0.0
	var side: String = "WEST"
	if _flood_dir == Vector2.LEFT:
		side = "EAST"
	elif _flood_dir == Vector2.DOWN:
		side = "NORTH"
	elif _flood_dir == Vector2.UP:
		side = "SOUTH"
	message.emit("TIDAL WAVE FROM THE %s!" % side,
		"RUN to Maya's house! It's the only shelter. The wave kills on touch!")


func _wobble(q: float) -> float:
	return sin(q * 0.011 + _time * 2.1) * 26.0 \
		+ sin(q * 0.027 - _time * 3.3) * 12.0 \
		+ sin(q * 0.05 + _time * 5.0) * 5.0


func _edge_point(q: float, offset: float) -> Vector2:
	return _flood_origin + _flood_dir * (_flood_front + _wobble(q) + offset) + _flood_perp * q


func _is_flooded(p: Vector2) -> bool:
	var rel: Vector2 = p - _flood_origin
	var s: float = rel.dot(_flood_dir)
	var q: float = rel.dot(_flood_perp)
	return s <= _flood_front + _wobble(q)


func _step_flood(delta: float) -> void:
	match _flood_phase:
		"surge":
			_phase_t += delta
			var speed: float = lerpf(FLOOD_START_SPEED, FLOOD_SPEED,
				clampf(_phase_t / FLOOD_RAMP_TIME, 0.0, 1.0))
			_flood_front += speed * delta
			if _flood_front >= _flood_total:
				_flood_front = _flood_total
				_flood_phase = "hold"
				_phase_t = 0.0
			_check_flood_kill()
		"hold":
			_phase_t += delta
			_check_flood_kill()
			if _phase_t >= FLOOD_HOLD_TIME:
				_flood_phase = "recede"
				_flood_lethal = false
				_phase_t = 0.0
		"recede":
			_phase_t += delta
			_flood_alpha = clampf(1.0 - _phase_t / FLOOD_RECEDE_TIME, 0.0, 1.0)
			if _phase_t >= FLOOD_RECEDE_TIME:
				_flood_phase = "done"
				_flood_alpha = 0.0


## The kill test uses the same wavy edge that is drawn, so the player dies at the
## exact moment the visible foam line reaches their feet.
func _check_flood_kill() -> void:
	if not _flood_lethal or _flood_killed or not _player_alive():
		return
	if HOUSE_IS_SHELTER and _player_safe_indoors():
		return
	if _is_flooded(_player_feet()):
		_flood_killed = true
		_thud.play()
		_flash = 0.6
		_player.die_instantly("flood")


func _draw_flood() -> void:
	if _flood_front <= 0.0 or _flood_alpha <= 0.0:
		return
	var a: float = _flood_alpha
	var edge := PackedVector2Array()
	var deep := PackedVector2Array()
	var foam_in := PackedVector2Array()
	var foam_out := PackedVector2Array()
	var q: float = -_flood_q_half
	while q <= _flood_q_half:
		edge.append(_edge_point(q, 0.0))
		deep.append(_edge_point(q, -190.0))
		foam_in.append(_edge_point(q, -18.0 + sin(q * 0.04 + _time * 4.0) * 5.0))
		foam_out.append(_edge_point(q, 12.0 + sin(q * 0.06 - _time * 5.0) * 4.0))
		q += FOAM_STEP
	var back_a: Vector2 = _flood_origin - _flood_dir * FLOOD_BACK + _flood_perp * _flood_q_half
	var back_b: Vector2 = _flood_origin - _flood_dir * FLOOD_BACK - _flood_perp * _flood_q_half
	var body := PackedVector2Array(edge)
	body.append(back_a)
	body.append(back_b)
	draw_colored_polygon(body, Color(0.08, 0.42, 0.82, 0.50 * a))
	var deep_poly := PackedVector2Array(deep)
	deep_poly.append(back_a)
	deep_poly.append(back_b)
	draw_colored_polygon(deep_poly, Color(0.03, 0.22, 0.55, 0.38 * a))

	# Flow streaks and floating debris, concentrated around the player's view.
	var centre_q: float = (to_local(_player.global_position) - _flood_origin).dot(_flood_perp)
	for i in 70:
		var h1: float = _hash(float(i))
		var h2: float = _hash(float(i) + 91.0)
		var sq: float = centre_q + (h1 * 2.0 - 1.0) * 1300.0
		var back: float = fposmod(h2 * 1400.0 + _time * 260.0, 1400.0)
		var s: float = _flood_front + _wobble(sq) - 50.0 - back
		var p0: Vector2 = _flood_origin + _flood_dir * s + _flood_perp * sq
		var p1: Vector2 = p0 - _flood_dir * (40.0 + h1 * 40.0)
		draw_line(p0, p1, Color(1, 1, 1, 0.22 * a), 3.0)
	for i in 26:
		var h1: float = _hash(float(i) + 300.0)
		var h2: float = _hash(float(i) + 700.0)
		var dq: float = centre_q + (h1 * 2.0 - 1.0) * 1100.0
		var dback: float = fposmod(h2 * 1800.0 + _time * 90.0, 1800.0)
		var ds: float = _flood_front + _wobble(dq) - 110.0 - dback
		var dp: Vector2 = _flood_origin + _flood_dir * ds + _flood_perp * dq
		dp += _flood_perp * sin(_time * 2.0 + float(i)) * 8.0
		var kind: int = i % 3
		if kind == 0:
			draw_rect(Rect2(dp - Vector2(26, 6), Vector2(52, 12)), Color(0.36, 0.23, 0.13, 0.95 * a))
			draw_rect(Rect2(dp - Vector2(26, 6), Vector2(52, 12)), Color(0.2, 0.12, 0.07, a), false, 2.0)
		elif kind == 1:
			draw_rect(Rect2(dp - Vector2(5, 11), Vector2(10, 22)), Color(0.75, 0.92, 1.0, 0.9 * a))
			draw_rect(Rect2(dp - Vector2(3, 14), Vector2(6, 4)), Color(0.9, 0.3, 0.3, 0.9 * a))
		else:
			draw_circle(dp, 11.0, Color(0.95, 0.95, 0.98, 0.75 * a))
	draw_polyline(foam_in, Color(0.85, 0.96, 1.0, 0.55 * a), 6.0)
	draw_polyline(edge, Color(1, 1, 1, 0.95 * a), 10.0)
	draw_polyline(foam_out, Color(1, 1, 1, 0.55 * a), 4.0)

	# Arrow to Maya's house while there is still time to run.
	if _flood_phase == "surge" and _player_alive() and not _player.indoors:
		var house := get_tree().get_first_node_in_group("maya_home") as Node2D
		if house != null:
			var ppos: Vector2 = to_local(_player.global_position)
			var target: Vector2 = to_local(house.global_position) + Vector2(0, 60)
			var dir: Vector2 = (target - ppos)
			if dir.length() > 160.0:
				dir = dir.normalized()
				var tip: Vector2 = ppos + dir * 170.0
				var side: Vector2 = Vector2(-dir.y, dir.x)
				var pulse: float = 0.75 + 0.25 * sin(_time * 8.0)
				var tri := PackedVector2Array([tip + dir * 26.0, tip - dir * 10.0 + side * 20.0, tip - dir * 10.0 - side * 20.0])
				draw_colored_polygon(tri, Color(1.0, 0.86, 0.25, pulse))
				var font: Font = ThemeDB.fallback_font
				draw_string(font, tip + Vector2(-79, -29), "MAYA'S HOUSE", HORIZONTAL_ALIGNMENT_CENTER, 160.0, 20, Color(0, 0, 0, 0.8))
				draw_string(font, tip + Vector2(-80, -30), "MAYA'S HOUSE", HORIZONTAL_ALIGNMENT_CENTER, 160.0, 20, Color(1.0, 0.92, 0.45, 1.0))


# =====================================================================================
#  STORM
# =====================================================================================

func _run_storm(def: Dictionary) -> void:
	_mode = "storm"
	_strikes.clear()
	_rain_target = 1.0
	_alarm.play()
	message.emit("LIGHTNING STORM!",
		"Watch the glowing rings on the ground and get out before the bolt lands!")
	var count: int = 5 + int(float(def.get("damage", 25)) / 12.0)
	var bolt_damage: int = maxi(int(ceil(float(def.get("damage", 25)) * 0.8)), 12)
	for i in count:
		if not _player_alive():
			break
		_spawn_strike(bolt_damage, i)
		await get_tree().create_timer(STRIKE_GAP).timeout
	# Wait for the last bolt to land.
	var guard := 0
	while not _strikes.is_empty() and _player_alive() and guard < 600:
		guard += 1
		await get_tree().process_frame
	_rain_target = 0.0
	await get_tree().create_timer(1.0).timeout
	_scorches.clear()


func _spawn_strike(damage: int, index: int) -> void:
	var ppos: Vector2 = to_local(_player.global_position) + Vector2(0, 20)
	var pos: Vector2
	if index % 3 != 2:
		# Aim near the player so they have to move.
		var ang: float = randf() * TAU
		pos = ppos + Vector2(cos(ang), sin(ang)) * randf_range(40.0, 260.0)
	else:
		pos = Vector2(
			randf_range(_bounds.position.x + 100.0, _bounds.end.x - 100.0),
			randf_range(_bounds.position.y + 100.0, _bounds.end.y - 100.0))
	_strikes.append({"pos": pos, "t": 0.0, "damage": damage, "bolt": -1.0, "seed": randf() * 100.0})


func _step_storm(delta: float) -> void:
	var finished: Array[Dictionary] = []
	for s in _strikes:
		if float(s.bolt) < 0.0:
			s.t = float(s.t) + delta
			if float(s.t) >= STRIKE_WARN_TIME:
				s.bolt = 0.0
				_flash = 0.55
				_thud.play()
				_shake_camera(14.0, 0.35)
				_scorches.append({"pos": s.pos, "life": 6.0})
				if _player_alive() and not _player.indoors:
					if _player_feet().distance_to(s.pos) <= STRIKE_RADIUS:
						_player.take_damage(int(s.damage))
		else:
			s.bolt = float(s.bolt) + delta
			if float(s.bolt) > 0.28:
				finished.append(s)
	for s in finished:
		_strikes.erase(s)
	var alive: Array[Dictionary] = []
	for sc in _scorches:
		sc.life = float(sc.life) - delta
		if float(sc.life) > 0.0:
			alive.append(sc)
	_scorches = alive


func _draw_storm() -> void:
	var ppos: Vector2 = to_local(_player.global_position) if _player != null else Vector2.ZERO
	# Dark, rainy air.
	if _rain > 0.0:
		draw_rect(Rect2(ppos - Vector2(2400, 1500), Vector2(4800, 3000)), Color(0.04, 0.05, 0.12, 0.30 * _rain))
		for i in 90:
			var x: float = fposmod(float(i) * 173.1 + _time * 140.0, 2600.0) - 1300.0
			var y: float = fposmod(float(i) * 97.7 + _time * 950.0, 1700.0) - 850.0
			var p: Vector2 = ppos + Vector2(x, y)
			draw_line(p, p + Vector2(-12, 32), Color(0.78, 0.88, 1.0, 0.45 * _rain), 2.0)
	# Scorch marks left by earlier bolts.
	for sc in _scorches:
		var life: float = clampf(float(sc.life) / 6.0, 0.0, 1.0)
		draw_set_transform(sc.pos, 0.0, Vector2(1.0, 0.55))
		draw_circle(Vector2.ZERO, 62.0, Color(0.05, 0.04, 0.04, 0.55 * life))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	# Warning rings and bolts.
	for s in _strikes:
		var pos: Vector2 = s.pos
		if float(s.bolt) < 0.0:
			var k: float = clampf(float(s.t) / STRIKE_WARN_TIME, 0.0, 1.0)
			var blink: float = 0.55 + 0.45 * sin(_time * (10.0 + 18.0 * k))
			draw_set_transform(pos, 0.0, Vector2(1.0, 0.6))
			draw_circle(Vector2.ZERO, STRIKE_RADIUS, Color(1.0, 0.25, 0.15, 0.10 + 0.18 * k))
			draw_arc(Vector2.ZERO, STRIKE_RADIUS, 0.0, TAU, 48, Color(1.0, 0.85, 0.3, blink), 5.0)
			draw_arc(Vector2.ZERO, STRIKE_RADIUS * k, 0.0, TAU, 40, Color(1.0, 0.4, 0.2, 0.9), 4.0)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			draw_string(ThemeDB.fallback_font, pos + Vector2(-8, -40), "!", HORIZONTAL_ALIGNMENT_CENTER, 24.0, 38, Color(1.0, 0.9, 0.3, blink))
		else:
			var pts := PackedVector2Array()
			var top: Vector2 = pos + Vector2(sin(float(s.seed)) * 160.0, -1100.0)
			var steps := 12
			for j in steps + 1:
				var t: float = float(j) / float(steps)
				var base: Vector2 = top.lerp(pos, t)
				var jag: float = 0.0 if j == 0 or j == steps else (_hash(float(j) + float(s.seed)) * 2.0 - 1.0) * 55.0
				pts.append(base + Vector2(jag, 0.0))
			draw_polyline(pts, Color(0.6, 0.8, 1.0, 0.35), 18.0)
			draw_polyline(pts, Color(1, 1, 1, 0.95), 6.0)
			draw_circle(pos, 46.0, Color(1, 1, 0.8, 0.6))
	if _flash > 0.0:
		draw_rect(Rect2(ppos - Vector2(2600, 1600), Vector2(5200, 3200)), Color(1, 1, 1, 0.5 * clampf(_flash, 0.0, 1.0)))


# =====================================================================================
#  HEAT
# =====================================================================================

func _run_heat(def: Dictionary) -> void:
	_mode = "heat"
	_heat_active = true
	_heat_level = 0.0
	_alarm.play()
	message.emit("SCORCHING SUN!",
		"Stand in shade (trees, rocks, Maya's house) or go indoors before each pulse!")
	var pulse_damage: int = maxi(int(ceil(float(def.get("damage", 20)) * 0.45)), 8)
	for i in HEAT_PULSES:
		if not _player_alive():
			break
		_heat_warn = 0.0
		var t: float = 0.0
		while t < HEAT_WARN_TIME and _player_alive():
			await get_tree().process_frame
			t += get_process_delta_time()
			_heat_warn = clampf(t / HEAT_WARN_TIME, 0.0, 1.0)
		if not _player_alive():
			break
		# The pulse itself.
		_heat_pulse_flash = 1.0
		if not _player.indoors and not _is_shaded(_player_feet()):
			_player.take_damage(pulse_damage)
			_thud.play()
		_heat_warn = 0.0
		await get_tree().create_timer(HEAT_PULSE_GAP - HEAT_WARN_TIME).timeout
	_heat_active = false
	var fade: float = 1.0
	while fade > 0.0:
		await get_tree().process_frame
		fade -= get_process_delta_time() * 0.8
		_heat_level = maxf(fade, 0.0)


func _shade_nodes_near(pos: Vector2, max_dist: float) -> Array[Dictionary]:
	var found: Array[Dictionary] = []
	for n in get_tree().get_nodes_in_group("shade"):
		var node := n as Node2D
		if node == null or not node.is_inside_tree():
			continue
		var p: Vector2 = to_local(node.global_position)
		var radius: float = float(node.get_meta("shade_radius", SHADE_DEFAULT_RADIUS))
		if p.distance_to(pos) <= max_dist + radius:
			found.append({"pos": p, "radius": radius})
	return found


func _is_shaded(feet: Vector2) -> bool:
	for sh in _shade_nodes_near(feet, 0.0):
		if feet.distance_to(sh.pos) <= float(sh.radius):
			return true
	return false


func _step_heat(delta: float) -> void:
	if _heat_active:
		_heat_level = move_toward(_heat_level, 1.0, delta * 1.2)
	_heat_pulse_flash = maxf(_heat_pulse_flash - delta * 2.0, 0.0)


func _draw_heat() -> void:
	if _player == null:
		return
	var ppos: Vector2 = to_local(_player.global_position)
	var lvl: float = _heat_level
	# Orange haze that deepens as each pulse winds up.
	var haze: float = lvl * (0.10 + 0.16 * _heat_warn) + 0.35 * _heat_pulse_flash
	draw_rect(Rect2(ppos - Vector2(2400, 1500), Vector2(4800, 3000)), Color(1.0, 0.55, 0.12, haze))
	# Wobbling heat-shimmer bands.
	for i in 9:
		var y: float = ppos.y - 520.0 + float(i) * 130.0
		var pts := PackedVector2Array()
		var x: float = ppos.x - 1300.0
		while x <= ppos.x + 1300.0:
			pts.append(Vector2(x, y + sin(x * 0.012 + _time * 3.0 + float(i)) * 9.0))
			x += 60.0
		draw_polyline(pts, Color(1.0, 0.85, 0.5, 0.10 * lvl), 8.0)
	# Safe spots: soft blue rings around shade so the player can find them.
	if lvl > 0.1:
		for sh in _shade_nodes_near(ppos, 1500.0):
			var pos: Vector2 = sh.pos
			var r: float = float(sh.radius)
			draw_set_transform(pos, 0.0, Vector2(1.0, 0.6))
			draw_circle(Vector2.ZERO, r, Color(0.2, 0.45, 0.85, 0.16 * lvl))
			draw_arc(Vector2.ZERO, r, 0.0, TAU, 40, Color(0.55, 0.85, 1.0, 0.6 * lvl), 3.0)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			draw_string(ThemeDB.fallback_font, pos + Vector2(-30, -r * 0.6 - 6.0), "SHADE", HORIZONTAL_ALIGNMENT_CENTER, 60.0, 16, Color(0.7, 0.92, 1.0, 0.9 * lvl))
	# A scorching ring that tightens just before the pulse hits unshaded ground.
	if _heat_warn > 0.0 and not _player.indoors and not _is_shaded(_player_feet()):
		var rr: float = lerpf(260.0, 40.0, _heat_warn)
		draw_set_transform(ppos + Vector2(0, 20), 0.0, Vector2(1.0, 0.6))
		draw_arc(Vector2.ZERO, rr, 0.0, TAU, 48, Color(1.0, 0.45, 0.1, 0.8), 5.0)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# =====================================================================================
#  Shared
# =====================================================================================

func _draw() -> void:
	match _mode:
		"flood":
			_draw_flood()
		"storm":
			_draw_storm()
		"heat":
			_draw_heat()
		_:
			# Lingering effects after a disaster ended (flash / scorches).
			if _flash > 0.0 or not _scorches.is_empty() or _rain > 0.0:
				_draw_storm()


func _hash(i: float) -> float:
	return fposmod(sin(i * 12.9898) * 43758.5453, 1.0)


func _shake_camera(strength: float, duration: float) -> void:
	var camera := get_viewport().get_camera_2d()
	if camera == null:
		return
	var original: Vector2 = camera.offset
	var tw := create_tween()
	var steps := 8
	for i in steps:
		var k: float = strength * (1.0 - float(i) / float(steps))
		tw.tween_property(camera, "offset", original + Vector2(randf_range(-k, k), randf_range(-k, k)), duration / float(steps))
	tw.tween_property(camera, "offset", original, 0.05)
