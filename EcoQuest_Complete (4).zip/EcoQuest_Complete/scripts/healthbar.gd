extends Node2D
## healthbar.gd
## Drives the existing Healthbar scene (HealthUnder + Health sprites).
## Call set_hp(current, max) whenever the player's HP changes.

@onready var health_sprite: Sprite2D = $Health

const FULL_WIDTH: float = 18.0
const BAR_HEIGHT: float = 4.0


func set_hp(current: int, max_hp: int) -> void:
	var pct: float = clampf(float(current) / float(max(max_hp, 1)), 0.0, 1.0)
	var rect := health_sprite.region_rect
	rect.size.x = FULL_WIDTH * pct
	health_sprite.region_rect = rect
